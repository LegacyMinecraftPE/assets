<?php

/*
__PocketMine Plugin__
name=Nightpvp
description=PVP only happensa at night :-)
version=1.0
author=Falk
class=tPVP
apiversion=10,11,12
*/

class tPVP implements Plugin{
	private $api, $path, $config;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->api->addHandler("entity.health.change", array($this, "eventHandler"));
}
	
	public function __destruct() {}

	public function eventHandler($data, $event) {
		if ($data['entity']->class !== ENTITY_PLAYER || !is_numeric($data['cause'])) return true;
		if ($this->api->time->getPhase() == "night") return true;
		else return false;
	}
	
}