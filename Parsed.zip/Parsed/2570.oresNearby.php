<?php
/*
__PocketMine Plugin__
name=OreFind
description=Quickly locate ores around you
version=0.1
author=Falk
class=oreFind
apiversion=10,11,12,13
*/
class oreFind implements Plugin{
private $api, $path;
public function __construct(ServerAPI $api, $server = false){
$this->api = $api;
}

public function init(){
$this->api->console->register("ores", "Do an ore scan", array($this, "command"));

}

public function __destruct(){}
public function command($cmd, $params, $issuer, $alias, $args, $issuer){
if(!($issuer instanceof Player)) return "Please run this command in game.";
for ($y = $issuer->entity->y+8; $y >= $issuer->entity->y-8; $y--)
 for ($x = round($issuer->entity->x)+8; $x >= round($issuer->entity->x)-8; $x--)
  for ($z = round($issuer->entity->z)+8; $z >= round($issuer->entity->z)-8; $z--)
  	$blocks[] = $issuer->level->getBlock(new Vector3($x, $y, $z))->getID();
$blocks = array_count_values($blocks);
$issuer->sendChat("---ORE REPORT---");
$issuer->sendChat((isset($blocks[16]) ? $blocks[16] : 0)  . " coal");
$issuer->sendChat((isset($blocks[15]) ? $blocks[15] : 0) . " iron");
$issuer->sendChat((isset($blocks[14]) ? $blocks[14] : 0) . " gold");
$issuer->sendChat((isset($blocks[56]) ? $blocks[56] : 0) . " diamond");
$issuer->sendChat((isset($blocks[21]) ? $blocks[21] : 0) . " lapis");
$issuer->sendChat((isset($blocks[73]) ? $blocks[73] : 0) . " redstone");
}
}
