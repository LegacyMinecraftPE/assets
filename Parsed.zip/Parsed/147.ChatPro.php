<?php

/*
__PocketMine Plugin__
name=ChatPro
description=Adds new commands for handling the chat
version=3.0
author=Glitchmaster_PE
class=ChatPro
apiversion=10
*/

class ChatPro implements Plugin{
	private $api, $lang, $prefix0, $prefix, $path, $config, $user;
	
	public function __construct (ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->api->console->register("stafflist","Gives a list of this server's staff", array($this, "StaffListPro"));
		$this->api->console->register("prefix","Set a users prefix. Usage: /prefix <username> [prefix]", array($this, "Prefix"));
		$this->api->ban->cmdwhitelist("stafflist");
		$this->readConfig();
		$this->api->addHandler("player.join", array($this, "handler"), 5);
		$this->api->addHandler("player.chat", array($this, "handler"), 5);
		$this->path = $this->api->plugin->configPath($this);
		$this->staffmsgs = new Config($this->path. "staff.yml", CONFIG_YAML, array(
			"  [ChatPro]
---Owner---
(INSERT HERE)
---Admins---
(INSERT HERE)
---Moderators---
(INSERT HERE)
---Trusted---
(INSERT HERE)",
		));
		$this->staffmsgs = $this->api->plugin->readYAML($this->path . "staff.yml");
		$this->api->console->register("announce","Gives server announcements", array($this, "Announce"));
		$this->api->ban->cmdwhitelist("announce");
		$this->path = $this->api->plugin->configPath($this);
		$this->announcemsgs = new Config($this->path. "announcements.yml", CONFIG_YAML, array("Announcements" => "[ChatPro] YOUR ANNOUNCEMENTS HERE"));
		$this->announcemsgs = $this->api->plugin->readYAML($this->path . "announcements.yml");
		$this->api->console->register("/cphelp","Displays ChatPro commands", array($this, "Help"));
		$this->api->ban->cmdwhitelist("/cphelp");
		$this->helpmsgs = new Config($this->path. "DO-NOT-TOUCH.yml", CONFIG_YAML, array("Commands" => "[ChatPro] Commands: /announce, /stafflist, /rules, 
		/prefix <op only>"));
		$this->helpmsgs = $this->api->plugin->readYAML($this->path . "DO-NOT-TOUCH.yml");
		$this->api->console->register("rules","Gives server's rules", array($this, "Rules"));
		$this->api->ban->cmdwhitelist("rules");
		$this->rulesmsgs = new Config($this->path. "rules.yml", CONFIG_YAML, array("Rules" => "[ChatPro]
		1. Do not grief!
		2. Do not abuse OP!
		3. Do not troll!
		4. Have fun!"));
		$this->rulesmsgs = $this->api->plugin->readYAML($this->path . "rules.yml");
		$this->api->console->register("griefwarn","Warn a griefer", array($this, "Grief"));
		$this->api->console->register("trollwarn","Warn a troller", array($this, "Troll"));
		$this->api->console->register("swearwarn","Warn a person swearing", array($this, "Swear"));
		$this->griefmsgs = new Config($this->path. "griefwarn.yml", CONFIG_YAML, array("Grief Warning" => "[ChatPro] Griefing is not allowed!"));
		$this->griefmsgs = $this->api->plugin->readYAML($this->path . "griefwarn.yml");
		$this->trollmsgs = new Config($this->path. "trollwarn.yml", CONFIG_YAML, array("Troll Warning" => "[ChatPro] Trolling is not allowed!"));
		$this->trollmsgs = $this->api->plugin->readYAML($this->path . "trollwarn.yml");
		$this->swearmsgs = new Config($this->path. "swearwarn.yml", CONFIG_YAML, array("Swear Warning" => "[ChatPro] Swearing is not allowed!"));
		$this->swearmsgs = $this->api->plugin->readYAML($this->path . "swearwarn.yml");
	}
	
	public function StaffListPro($cmd, $args, $issuer){
		$username = $issuer->username;
		foreach($this->staffmsgs as $staffmsg){
			$this->api->chat->sendTo(false, $staffmsg, $username);
		}
	}
	
	public function Announce($cmd, $args, $issuer){
		$username = $issuer->username;
		foreach($this->announcemsgs as $announcemsg){
			$this->api->chat->sendTo(false, $announcemsg, $username);
		}
	}
	
	public function Help($cmd, $args, $issuer){
		$username = $issuer->username;
		foreach($this->helpmsgs as $helpmsg){
			$this->api->chat->sendTo (false, $helpmsg, $username);
		}
	}
	
	public function Rules($cmd, $args, $issuer){
		$username = $issuer->username;
		foreach($this->rulesmsgs as $rulesmsg){
			$this->api->chat->sendTo (false, $rulesmsg, $username);
		}
	}
	
	public function Grief($cmd, $args, $issuer, $target){
		$target = $args[0];
		foreach($this->griefmsgs as $griefmsg){
			$this->api->chat->sendTo (false, $griefmsg, $target);
		}
	}
	
	public function Troll($cmd, $args, $issuer, $target){
		$target = $args[0];
		foreach($this->trollmsgs as $trollmsg){
			$this->api->chat->sendTo (false, $trollmsg, $target);
		}
	}
	
	public function Swear($cmd, $args, $issuer, $target){
		$target = $args[0];
		foreach($this->swearmsgs as $swearmsg){
			$this->api->chat->sendTo (false, $swearmsg, $target);
		}
	}
	
	public function __destruct(){
	}
	
	public function readConfig(){
		$this->path = $this->api->plugin->createConfig($this, array(
			"format" => "[{prefix}]<{DISPLAYNAME}> {MESSAGE}",
		));
		$this->config = $this->api->plugin->readYAML($this->path."config.yml");
	}

	
	public function Prefix($cmd, $args){
	switch($cmd){
	    case "prefix":
	      $player = $args[0];
		  $pref = $args[1];
        
		$this->config['player'][$player] =$pref;
        $this->api->plugin->writeYAML($this->path."config.yml", $this->config);
         $output .= "[ChatPro] Gave ".$pref." to ".$player.".";
         $this->api->chat->sendTo(false, "[ChatPro] Your prefix is now ".$pref." !", $player);
          break;
	  
	  default:		$output .= 'ChatPro by Glitchmaster_PE';
	  break;
	  }
	  }
	  
	public function handler(&$data, $event){
		switch($event){
				case "player.join":
				$user = $data->username;
				if (!isset($this->config['player'][$user])) {
					$this->config['player'][$user] ='Player';
					$this->api->plugin->writeYAML($this->path."config.yml", $this->config);
				}
			break;
			case "player.chat":
			    $prefix = $data["player"]->username;
                $this->config = $this->api->plugin->readYAML($this->path."config.yml");
				$data = array("player" => $data["player"], "message" => str_replace(array("{DISPLAYNAME}", "{MESSAGE}", "{prefix}"), array($data["player"]->username, $data["message"], $this->config["player"][$prefix]), $this->config["format"]));
				if($this->api->handle("ChatPro.".$event, $data) !== false){
					$this->api->chat->broadcast($data["message"]);
				}
				return false;
				break;
		}
	}	
}
?>
