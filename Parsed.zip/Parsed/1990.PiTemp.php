<?php

/*
__PocketMine Plugin__
name=PiTemperature
description=Shutdown your Pi when it gets too hot
version=1.0
author=SuperChipsLP
class=PiTemp
apiversion=10,11,12
*/

    class PiTemp implements plugin{

    private $api;
    private $time = 60;
    private $max = 55;
    private $sutdown_serv = true;
    private $sutdown_pi = false;  

    public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}

	public function init(){
	    //Warning users   
        console(FORMAT_RED."[PITEMP] Remember that this Plugin is just for the Raspberry Pi.");
        console(FORMAT_RED."[PITEMP] This is only tested with Raspbian wheezy, which most of the Raspberrys use.");
        console(FORMAT_RED."[PITEMP] It can corrupt your server! So remove it if you're not using a Raspberry Pi!");
        
        //Setting scheduler
        $this->api->schedule(20 * $this->time, array($this, "getTemp"), array(), true);
        
        //Creating config
        $this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array(
        "auto_stop_server" => true,
        "auto_reboot_pi" => false,
        "seconds" => 60,
        "max_temperature" => 55
        ));
        
        //Reloading config
        $this->config->reload();
        
        //Taking over settings to the plugin
        $this->shutdown_serv = $this->config->get('auto_stop_server');
        $this->shutdown_pi = $this->config->get('auto_reboot_pi');
        $this->max = $this->config->get('max_temperature');
        $this->time = $this->config->get('seconds'); 
        
    }
    
    public function getTemp(){
    
        //See how the temperature of the Pi is
        $temp = exec("vcgencmd measure_temp");
        $temp = str_replace("temp=", "", $temp);
        $temp = str_replace("'C", "", $temp);
        $temp = round($temp);
        
        if($this->max < $temp){
            if($this->sutdown_serv === true){
                //Stopping the server
                ConsoleAPI::run("stop");    
            } elseif ($this->sutdown_pi === true){
                //Rebooting the Pi
                exec("sudo reboot");
            } else {
            
            //Color console text
            //depends on how the temperature is
            
                if($temp < $this->max){
                    console(FORMAT_GREEN."The Pis Temperature is: ".$temp);
                } elseif ($temp > $this->max){
                    console(FORMAT_RED."The Pis Temperature is: ".$temp);
                }
            }
        }
        
    }

    public function __destruct(){

    }

}
