<?php

/*
__PocketMine Plugin__
name=ItemSpawn
description=
version=1.1
author=DarkN3ss
class=ItemSpawn
apiversion=10, 11, 12
*/


class ItemSpawn implements Plugin{
	private $api;
   
	private $config;


	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}

	public function init(){
		$this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array(
            "SpawnItems" => array(
                "Items" => array(
                    array(
                        298,
                        0,
                        1
                    ), // id , meta, count
                    array(
                        299,
                        0,
                        1
                    ),
					array(
                        300,
                        0,
                        1
                    ),
					array(
                        301,
                        0,
                        1
                    ),
					array(
                        268,
                        0,
                        1
                    ),
					array(
                        270,
                        0,
                        1
                    ),
                )
            ),
        ));
          
        $this->config = $this->api->plugin->readYAML($this->api->plugin->configPath($this) . "config.yml");
		$this->api->addHandler("player.respawn", array($this, "eventHandler"), 50);
		
	}
   
	public function eventHandler($data, $event){
		switch($event){
			case "player.respawn":
				$playerName = $this->api->player->get($data->username);
				$items = $this -> config["SpawnItems"];
				$this->giveItems($items, $playerName);
				break;
		}
		return;
	}
	
	public function giveItems($items, $player)
    {
        foreach ($items['Items'] as $val)
        {
			if($player instanceof Player) 
			{ 
				$player->addItem($val[0], $val[1], $val[2]); 
			}
        }
    }
  
	public function __destruct(){
	}
}
?>