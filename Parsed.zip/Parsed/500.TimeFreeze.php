<?php

/*
__PocketMine Plugin__
name=TimeFreeze
version=0.1
author=Junyi00
class=TimeFreeze
apiversion=10
*/

class TimeFreeze implements Plugin{
	private $api, $path, $config;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
		$this->ticks = 0;
		$this->shouldChange = true;
	}
	
	public function init(){
		$this->path = $this->api->plugin->configPath($this); 
		$this->config = new Config($this->path."config.yml", CONFIG_YAML, array(
			"General" => array(
				"Mins for each update" => 10,
				"Ticks" => "DAY")));
				
		$this->api->console->register("tfreeze", "<day/night/sunset/sunrise/[tick]", array($this, "ChangeConfig"));
		
		$mins = 10;
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		if (ARRAY_KEY_EXISTS("Mins for each update", $cfg["General"])) {
			$mins = round($cfg["General"]["Mins for each update"]);
		}
		$this->api->schedule(1200* $mins, array($this, "ChangeTime"), array(), false);
	}
	
	public function __destruct() {}
	
	public function ChangeConfig($cmd, $arg, $issuer) {
		$ms = "";
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		$type = $arg[0];
		$cfg["General"]["Ticks"] = $type;
		$ms = "Ticks set to $type!";
		
		return $ms;
	}
	
	public function ChangeTime() {
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		$tickDat = $cfg["General"]["Ticks"];
		
		$this->shouldChange = true;
		
		if (preg_match('/[A-Za-z]/', $tickDat) && !preg_match('/[0-9]/', $tickDat)) {
			$tickDat = strtoupper($tickDat);	
		}
		elseif (preg_match('/[0-9]/', $tickDat) && !preg_match('/[A-Za-z]/', $tickDat)) {
				
			$tickDat = (int) $tickDat;
		}
		
		if ($tickDat == "DAY") {
			$this->ticks = 0;	
		}
		elseif ($tickDat == "NIGHT") {
			$this->ticks = 10900;
		}
		elseif ($tickDat == "SUNSET") {
			$this->ticks = 9500;
		}
		elseif ($tickDat == "SUNRISE") {
			$this->ticks = 17800;
		}
		elseif (is_int($tickDat)) {
			$this->ticks = $tickDat;
		}
		else {
			console("[WARNING] 'Ticks' from config.yml must either be day/night/sunset/sunrise or an int");
			$this->shouldChange = false;
		}
		
		$this->api->time->set($this->ticks);
	}
	
	private function overwriteConfig($dat){
		$cfg = array();
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		$result = array_merge($cfg, $dat);
		$this->api->plugin->writeYAML($this->path."config.yml", $result);
	}

	
}