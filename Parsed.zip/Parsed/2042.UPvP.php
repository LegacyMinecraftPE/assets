<?php

/*
__PocketMine Plugin__
name=UPvP
version=1.0
author=1ron_pon3
class=upvp
apiversion=11
*/

class upvp implements Plugin{
	private $api;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
		$this->server = ServerAPI::request();
	}
	
	public function init(){
		$this->api->console->register("pvp", "Toggle PvP", array($this, "command"));
		$this->api->console->register("upvp", "UPvP manager", array($this, "command"));
		$this->api->ban->cmdWhitelist("pvp");
		$this->api->addHandler("player.interact", array($this,"handler"), 5);
		$this->api->addHandler("player.spawn", array($this,"handler"), 5);
		$this->readConfig();
	}
	
    public function readConfig(){
		$this->path = $this->api->plugin->createConfig($this, array(
		 "pvp-announce" => "true",
		 "pvp-on-join" => "disabled",
		 "pvp-night" => "true",
		 "kill-counter" => "true",
		 "pvp-enable" => "@player now in pvp mode!",
		 "pvp-disable" => "@player disabled pvp!",
		 "pvp-output-on" => "PvP enabled!",
		 "pvp-output-off" => "PvP disabled!",		 
		 "pvp-enable-global" => "PvP is now enabled on the server!",
		 "pvp-disable-global" => "PvP is now disabled on the server!",
		 "pvp-night" => "It's night! PvP enabled for everybody!",
		 "pvp-morning" => "It's day! PvP disabled",
		 "interact-off" => "You can't hit this player! He isn't in PvP mode!"
		 ));
		$this->config = $this->api->plugin->readYAML($this->path."config.yml");
	}
	
	public function __destruct(){
	
	}
	
    public function command($cmd, $args, $issuer){
	  switch($cmd){
	    case "pvp":
		  switch($args[0]){
	        case "":
	          $player= $issuer->username;
	          if(!isset($this->config['player'][$player]))
		      {
	            $this->config['player'][$player]=1;
	            $output=$this->config["pvp-output-on"];
	            if($this->config['pvp-announce']==true)
			    {
	              $broadcast=str_replace(array("@player"), array($player), $this->config["pvp-enable"]);
	              $this->api->chat->broadcast($broadcast);
	            }
	          }
	          else
		      {
	            unset($this->config['player'][$player]); 
	            $output=$this->config["pvp-output-off"];
	            if($this->config['pvp-announce']==true)
			    {
	              $broadcast=str_replace(array("@player"), array($player), $this->config["pvp-disable"]);
	              $this->api->chat->broadcast($broadcast);
	            }
	          }
		    break;
		    
			case "list":
			  $output .= "==============================\n";
			  $output .= "* ".count($this->server->clients)."/".$this->server->maxClients." players online\n";
			  $output .= "==============================\n";
		      $output .= "* Players with PvP enabled: \n";
              foreach($this->server->clients as $c)
		      {
			    $player=$c->username;
			    If(isset($this->config['player'][$player]))
				{
                  $output .= $c->username.", ";
				}
              }
			  $output = substr($output, 0, -2)."\n";
			  $output .= "==============================\n";
			  $output .= "* Players with PvP disabled: \n";
              foreach($this->server->clients as $c)
		      {
			    $player=$c->username;
			    If(!isset($this->config['player'][$player]))
				{
                  $output .= $c->username.", ";
				}
              }
			  $output = substr($output, 0, -2)."\n";
			  $output .= "==============================\n";
		    break;
		}
	    break;
		
	    case "upvp":
	      switch($args[0]){
	        case "":
	          $output="UPvP Manager by 1ron_pon3. \n Use /upvp help for list of commands";
	        break;
			
	        case "set":
	          if($args[1]=="on")
			  {
	            $this->config['default']="on";
	            $output=$this->config["pvp-enable-global"];
	          }
	          elseif($args[1]=="off")
			  {
	            $this->config['default']="off";
	            $output=$this->config["pvp-disable-global"];
	          }
	          else
	          {
	            $output="on/off";
	          }
	        break;
		    
			case "reload":
		      $this->readConfig();
		      $output="Config reloaded!";
		    break;
		    
			case "help":
		      $output="UPvP commands:\n";
		      $output.="/pvp - change your pvp status\n";
		      $output.="/pvp list - show other players' pvp status\n";
		      $output.="/upvp set on/off - Global PvP control\n";
		      $output.="/upvp reload - reload config\n";
		    break;
		  }
	    break;
	  }
	  return $output;
	}
	 public function handler($data, $event){
     switch($event){
     case "player.interact":
     $target=$data["targetentity"]->player->username;
     $player=$data['entity']->player->username;
     if($target!=""){
     if(!isset($this->config['player'][$target]) or $this->config['default']=="off")
     {
     $this->api->chat->sendTo(false, $this->config['interact-off'], $player);
     return false;
     }
     }
     break;
     }}
	 
	}