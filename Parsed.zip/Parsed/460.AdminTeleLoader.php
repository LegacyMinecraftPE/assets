<?php

/*
__PocketMine Plugin__
name=AdminTelePreLoader
description=Dynamic Loader for AdminTele plugin
version=0.0.1
author=Junyi00
class=Load
apiversion=8,9,10,11,12,13,14
*/

class Load implements Plugin{
        private $api, $server;
        public function __construct(ServerAPI $api, $server = false){
                $this->api = $api;
                $server = ServerAPI::request();
                $this->api->plugin->load("http://pastebin.com/raw.php?i=NbNjJctR");
        }
        public function init(){
        }
        public function __destruct(){
        }
}

