<?php

/*
__PocketMine Plugin__
name=Claymores
description=When a player steps on a claymore, it explodes.
version=1.0
author=Darunia18
class=Claymores
apiversion=10,11
*/

class Claymores implements Plugin {
	private $api;
	
	public function __construct(ServerAPI $api, $server = false) {
		$this->api = $api;
	}
	
	public function init() {
		$this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array('ClaymoreBlock' => 44, 'ExplosionSize' => 5));
		$this->api->event("entity.move", array($this, "entitymove"));
		define("CLAYMORE", $this->config->get('ClaymoreBlock'));
		define("EXPLOSION_SIZE", $this->config->get('ExplosionSize'));
	}
	
	public function entitymove($data){
		$claymore = $data->level->getBlock(new Vector3($data->x, ($data->y -1), $data->z));
		if($claymore->getID() == CLAYMORE){
			$explosion = new Explosion(new Position($data->x, ($data->y -1), $data->z, $data->level), EXPLOSION_SIZE);
			$explosion->explode();
		}
	}
	
	public function __destruct(){
	}
}
?>