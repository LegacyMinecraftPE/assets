<?php
/*
__PocketMine Plugin__
name=Tap to do
description=A simple plugin to automate commands
version=0.4
author=Falk
class=tapdo
apiversion=10,11
*/
/*
_Change Log_
0.1 - Intial release
0.2 - 
	*Added new /tapcmd command 
	*Added :user:
	*Code format improvements
0.3 -
	*Added multiple commands!
	*Removed support for setcmd
	*Chnaged :player: to @player
0.3.1 -
	*Fixed @player issues
0.4 -
	*Added new location variables
	*Changed :player: to %p
	*Added safe execution
	*API 11 support
0.4.1 -
	*Added ticker
	
*/
class tapdo implements Plugin{
private $api, $path;
public function __construct(ServerAPI $api, $server = false){
$this->api = $api;
}

public function init(){

$this->api->addHandler("player.block.touch", array($this,"eventHandle"),50);
$this->api->console->register("tapcmd", "Sets the tap cmd for the block you click", array($this, "command"));
$this->config = new Config($this->api->plugin->configPath($this)."blocks.yml", CONFIG_YAML, array());
$this->tick = array();
}

public function __destruct(){}
public function command($cmd, $params, $issuer, $alias, $args, $issuer){
switch ($cmd) {
	case "tapcmd": 
	$cmd = implode(" ", $params);
	$this->picked[$issuer->username] = $cmd;
	$issuer->sendChat("Tap a block to add the command!");
break;
		default:
	$issuer->sendChat("Invalid Command!");
}
}
public function eventHandle($data, $event) {
if (isset($this->picked[$data["player"]->username])) {
$block = $data["target"];
	$read = $this->api->plugin->readYAML($this->api->plugin->configPath($this). "blocks.yml");
    $x = $block->x;
	$y = $block->y;
	$z = $block->z;
	$level = $block->level->getName();
	$id = $x . "!" . $y . "!" . $z . "!" . $level;
	$read[$id][] = $this->picked[$data["player"]->username];
	
		$this->api->plugin->writeYAML($this->api->plugin->configPath($this)."blocks.yml", $read);
		
		unset($this->picked[$data["player"]->username]);
		$data["player"]->sendChat("Command added to block!");
		}
else {
$block = $data["target"];
$read = $this->api->plugin->readYAML($this->api->plugin->configPath($this). "blocks.yml");
    $x = $block->x;
	$y = $block->y;
	$z = $block->z;
	$level = $block->level->getName();
	$search = $x . "!" . $y . "!" . $z . "!" . $level;
	if (array_key_exists($search,$read)) {
	foreach ($read[$search] as $item) {
	//Variables
	$command = str_replace("%p", $data["player"]->username, $item);
	$command = str_replace("%x", $data["player"]->entity->x, $command);
	$command = str_replace("%y", $data["player"]->entity->y, $command);
	$command = str_replace("%z", $data["player"]->entity->z, $command);
	//Behaviour switches
	//Pre-Execution
	if (strpos($command, "%tick") != false) {
	//Create command/block ID
	if (!isset($this->tick[$search.$item])) {
		$this->tick[$search.$item] = 0;
	}
if ($this->tick[$search.$item] == substr($item, strpos($item,'%tick(')+6, strpos($item,")")-strpos($item,'%tick(')+4)) {
$data['player']->sendChat("Command reached ticker maximum");
$command = "";			
		}
		else {
			$command = str_replace("%tick(".substr( $item, strpos($item,'%tick(')+6, strpos($item,")")-strpos($item,'%tick(')+4).")", "", $command);
			$this->tick[$search.$item] = $this->tick[$search.$item]+1;
		}
	}
	//Execution
	if (strpos($command, "%safe") != false) {
	$command = str_replace("%safe", "", $command);
		$this->api->console->run($command, $data["player"]);
	}
	else {
		
	 $this->api->console->run($command);
	 }
	 }
		}
		}
	}
}