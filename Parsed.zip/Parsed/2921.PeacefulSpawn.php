<?php

/*
__PocketMine Plugin__
name=PeacefulSpawn
version=1.4
author=LDX
class=PeacefulSpawn
apiversion=10,11,12
*/

// Original code by wies

class PeacefulSpawn implements Plugin {
    private $api;
    private $server;
    public function __construct(ServerAPI $api,$server = false) {
        $this->api = $api;
        $this->server = ServerAPI::request();
    }

    public function init() {
        $this->api->addHandler("entity.health.change",array($this,"entityHurt"));
        $this->api->console->register("ps","Toggles PeacefulSpawn's protection.",array($this,"toggle"));
        $this->enabled = true;
    }

    public function toggle($cmd,$args,$issuer) {
        if($this->enabled == true) {
            $this->enabled = false;
            return "[PeacefulSpawn] Disabled!";
        } else {
            $this->enabled = true;
            return "[PeacefulSpawn] Enabled!";
        }
    }

    public function entityHurt($data) {
        $target = $data["entity"];
        if($this->api->player->get($data["entity"]->name) instanceof Player) {
            $t = new Vector2($target->x,$target->z);
            $s = new Vector2($this->server->spawn->x,$this->server->spawn->z);
            $r = $this->api->getProperty("spawn-protection");
            if($t->distance($s) <= $r && $this->enabled == true) {
                return false;
            }
        }
    }

    public function __destruct() { }
}
?>