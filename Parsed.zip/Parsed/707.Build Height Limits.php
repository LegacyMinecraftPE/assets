<?php

/*
__PocketMine Plugin__
name=Build Height Limits
description=Switches block with a similar type (flower to another flower)
version=0.1
author=Junyi00
class=BuildHeightLimits
apiversion=10
*/

class BuildHeightLimits implements Plugin{
	private $api, $path, $config;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->path = $this->api->plugin->configPath($this);
		$this->config = new Config($this->path."config.yml", CONFIG_YAML, array(
			"Building Limits" => array(
				"Minimum height" => 10,
				"Maximum height" => 180
				)));
		$this->api->addHandler("player.block.break", array($this, "handler"));
		$this->api->addHandler("player.block.place", array($this, "handler"));
	}
	
	public function __destruct() {}
	
	public function getLimits() {
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		$minimum = $cfg["Building Limits"]["Minimum height"];
		$maximum = $cfg["Building Limits"]["Maximum height"];
		
		$data = array( "Minimum" => $minimum, "Maximum" => $maximum);
		return $data;
	}
	
	public function handler($data, $event) {
		$limits = $this->getLimits();
		switch($event) {
			case "player.block.place";
			case "player.block.break";
				$y = $data['y'];
				if ($y >= $limits['Minimum']) {
					if ($y <= $limits['Maximum']) {
						return true;
					}
					else {
						return false;
					}
				}
				else {
					return false;
				}
				
		}
		
	}

}