<?php
/*
__PocketMine Plugin__
name=TouchHome
version=1.2
apiversion=12
author=LDX
class=TouchHome
*/
class TouchHome implements Plugin {
private $api;
public function __construct(ServerAPI $api,$server = false) {
$this->api  = $api;
}
public function init() {
$this->api->addHandler("player.block.touch",array($this,"touch"));
$this->api->addHandler("player.spawn",array($this,"spawn"));
$this->api->console->register("home","Teleports you to your home.",array($this,"home"));
$this->api->console->register("sethome","Sets your home.",array($this,"sethome"));
$this->api->ban->cmdWhitelist("home");
$this->api->ban->cmdWhitelist("sethome");
$this->path = $this->api->plugin->configPath($this);
$this->reloadConfig();
}
private function packet($raw) {
$p[0] = $raw;
$p[1] = strtolower($raw->username);
if(file_exists($this->path . "homes/" . $p[1] . ".home")) {
if(!isset($this->home[$p[1]])) {
$this->home[$p[1]] = yaml_parse(file_get_contents($this->path . "homes/" . $p[1] . ".home"));
}
$pk = new SetSpawnPositionPacket;
$pk->x = $this->home[$p[1]]["X"];
$pk->y = $this->home[$p[1]]["Y"];
$pk->z = $this->home[$p[1]]["Z"];
$p[0]->dataPacket($pk);
}
}
public function spawn($data) {
$this->packet($data);
}
private function reloadConfig() {
if(!file_exists($this->path . "config.yml")) {
file_put_contents($this->path . "config.yml",yaml_emit(array("TouchHome-Enabled" => true,"TouchHome-Item-ID" => 345,"Home-Message" => "Teleporting home...","Home-Set-Message" => "Home set!","No-Home-Message" => "You don't have a home set!")));
@mkdir($this->path . "homes/");
}
$config = yaml_parse(file_get_contents($this->path . "config.yml"));
$this->enabled = $config["TouchHome-Enabled"];
$this->item = $config["TouchHome-Item-ID"];
$this->homemsg = $config["Home-Message"];
$this->sethomemsg = $config["Home-Set-Message"];
$this->nohomemsg = $config["No-Home-Message"];
}
public function touch($data) {
if($this->enabled == true && $data["item"]->getID() == $this->item) {
$this->api->console->run("sudo " . $data["player"]->username . " home");
$this->packet($data["player"]);
return false;
}
}
private function update($n,$x,$y,$z,$w) {
file_put_contents($this->path . "homes/" . $n . ".home",yaml_emit(array("W" => $w,"X" => $x,"Y" => $y,"Z" => $z)));
$this->home[$n] = yaml_parse(file_get_contents($this->path . "homes/" . $n . ".home"));
}
public function home($cmd,$args,$issuer) {
if($issuer instanceof Player) {
$p = strtolower($issuer->username);
if(file_exists($this->path . "homes/" . $p . ".home")) {
if(!isset($this->home[$p])) {
$this->home[$p] = yaml_parse(file_get_contents($this->path . "homes/" . $p . ".home"));
}
if(!isset($home[$p]["W"])) {
$this->update($p,$this->home[$p]["X"],$this->home[$p]["Y"],$this->home[$p]["Z"],$issuer->entity->level->getName());
}
$coords = new Position($this->home[$p]["X"],$this->home[$p]["Y"],$this->home[$p]["Z"],$this->api->level->get($this->home[$p]["W"]));
$issuer->teleport($coords);
$this->packet($issuer);
return "[TouchHome] " . $this->homemsg;
} else {
return "[TouchHome] " . $this->nohomemsg;
}
} else {
return "[TouchHome] Command must be run in-game.";
}
}
public function sethome($cmd,$args,$issuer) {
if($issuer instanceof Player) {
$p = strtolower($issuer->username);
file_put_contents($this->path . "homes/" . $p . ".home",yaml_emit(array("W" => $issuer->entity->level->getName(),"X" => $issuer->entity->x,"Y" => $issuer->entity->y,"Z" => $issuer->entity->z)));
$this->home[$p] = yaml_parse(file_get_contents($this->path . "homes/" . $p . ".home"));
$this->packet($issuer);
return "[TouchHome] " . $this->sethomemsg;
} else {
return "[TouchHome] Command must be run in-game.";
}
}
public function __destruct() { }
}
?>
