<?php

/*
__PocketMine Plugin__
name=Kill Death Counter
version=0.3
author=Junyi00
class=KDCounter
apiversion=10
*/

class KDCounter implements Plugin{
	private $api, $path, $config;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->path = $this->api->plugin->configPath($this); 
		$this->config = new Config($this->path."config.yml", CONFIG_YAML, array(
			"Chat Layout" => array(
				"Layout" => "{KD} <USERNAME> (MS)")));
		$this->api->addHandler("player.death", array($this, "killDeathCount"), 15);
		$this->api->console->register("kd", "<[blank]/[player name]>  Get your kill death count", array($this, "getKD"));
		$this->api->addHandler("player.chat", array($this, "handler"), 5);
	}
    
    public function __destruct() {}
    
    private function getPlayerData($name) {
    	$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
    	if (!ARRAY_KEY_EXISTS("$name", $cfg)) {
    		return "[KD 0:0]";
    	}
    	else {
    		$kill = $cfg["$name"]["kill"];
    		$death = $cfg["$name"]["death"];
    		$str = "[KD ".$kill.":".$death."]";
    		return $str;
    	}
    	return;
    }
    
    public function handler($data, $event) {
    	$name = "<".$data['player']->username.">";
    	$message = $data['message'];
    	$kd = $this->getPlayerData($name);
    	
    	$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
    	$layout = $cfg["Chat Layout"]["Layout"];
    	
    	if (strpos($layout,'{KD}') !== false && strpos($layout,'<USERNAME>') !== false && strpos($layout,'(MS)') !== false) {
    		$layout = str_replace("{KD}", $kd, $layout);
    		$layout = str_replace("<USERNAME>", $name, $layout);
    		$layout = str_replace("(MS)", $message, $layout);
    		$this->api->chat->broadcast($layout);
    		return false;
    	}
    	else {
    		console("[KD Counter] Chat Layout must contain {KD}, <USERNAME>, (MS)");
    		return true;
    	}
    }
    
    public function getKD($cmd, $arg, $issuer) {
    	$ms = "";
    	$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
    	if (isset($arg[0])) { //the player request to get data of other players
    		$name = $arg[0];
    		if (!ARRAY_KEY_EXISTS("$name", $cfg)) {
    			$ms = "$name does not has any data stored!";
    			return $ms;
    		}
    		$kill = (int) $cfg["$name"]["kill"];
    		$death = (int) $cfg["$name"]["death"];
    		$ms = $name + "'s kill death count is ".$kill.":".$death;
    		return $ms;
    	}
    	else {
    		$name = $issuer->username;
    		if (!ARRAY_KEY_EXISTS("$name", $cfg)) {
    			$ms = "You do not has any data stored!";
    			return $ms;
    		}
    		$kill = (int) $cfg["$name"]["kill"];
    		$death = (int) $cfg["$name"]["death"];
    		$ms = "Your kill death count is ".$kill.":".$death;
    		return $ms;
    	}
    }
	
	public function killDeathCount($data, $event) {
		if(is_numeric($data["cause"])){
			$e = $this->server->api->entity->get($data["cause"]);
				if($e instanceof Entity){
					switch($e->class){
						case ENTITY_PLAYER:
							$name = $e->name;
							$this->increaseKill($name);
					}
				}
		}
		$this->increaseDeath($data["player"]->username);
	}
	
	public function increaseKill($name) {
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		$data = array();
		
		if (ARRAY_KEY_EXISTS("$name", $cfg)) {
			$kill = (int) $cfg["$name"]["kill"];	
			$kill += 1;
			$data = array( "$name"=> array("kill" => $count, "death" => $cfg["$name"]["death"]));
		}
		else {
			$kill = 1;
			$data = array( "$name"=>array("kill"=>$kill, "death" => 0 ));	
		}
		$player = $this->api->player->get($name);
		$player->sendChat("Your kill death count is now ".$kill.":".$cfg["$name"]["death"]);
		$this->overwriteConfig($data);
	}
	
	public function increaseDeath($name) {
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		$data = array();
		
		if (ARRAY_KEY_EXISTS("$name", $cfg)) {
			$death = (int) $cfg["$name"]["death"];	
			$death += 1;
			$data = array("$name" => array("kill" => $cfg["$name"]["kill"], "death" => $death ));
		}
		else {
			$death = 1;
			$data = array( "$name" => array("kill" => 0, "death" => $death ));	
		}
		$player = $this->api->player->get($name);
		$player->sendChat("Your kill death count is now ".$cfg["$name"]["kill"].":".$death);
		$this->overwriteConfig($data);
	}
	
	private function overwriteConfig($dat){
		$cfg = array();
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		$result = array_merge($cfg, $dat);
		$this->api->plugin->writeYAML($this->path."config.yml", $result);
	}

	
}