<?php
/*
__PocketMine Plugin__
name=Join MOTD
description=Sends a message to a joined player
version=1.0
author=Lambo
class=theJoinMOTD
apiversion=10
*/

class theJoinMOTD implements Plugin{

	private $api;
	
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}

	public function init(){
		$this->config = new Config($this->api->plugin->configPath($this) . "motd.yml", CONFIG_YAML, array("motd" => "Welcome back!", "prefix" => "[Server Name]", "playercounter"=>false, "playercounter msg" => "Total of players that have\njoined the server before "));
		$this->api->addHandler("player.spawn", array($this, "playerSpawned"));
		$this->api->console->register('joinmotd', "Join MOTD", array($this, 'commandHandler'));
	}

	public function playerSpawned($data){
	if($this->config->get('playercounter'))
	{
			$playercount = $this->api->dhandle('pc.get.count', false);
			$username = $data->username;
			$data->sendChat($this->config->get("prefix") . " " . $this->config->get('motd') . "\n" . $this->config->get('playercounter msg') . ": " . $playercount);
	}else
	{
			$username = $data->username;
			$data->sendChat($this->config->get("prefix") . " " . $this->config->get('motd'));
	}
	}
	
	public function commandHandler($cmd, $params, $issuer, $alias)
	{
	   $cmd = array_shift($params);
	   if($cmd==="motd")
	   {
	      $motd = implode(" ",$params);
	      $this->config->set("motd", $motd);
	      console("[JoinMOTD] Motd set.");
	      $this->config->save();
	   }else
	   if($cmd==="prefix")
	   {
	      $prefix = implode(" ",$params);
	      $this->config->set("prefix", $prefix);
	      console("[JoinMOTD] Prefix set.");
	      $this->config->save();
	   }else
	   if($cmd==="playercounter")
	   {
	   	  if($this->config->get("playercounter"))
	   	  {
	   	  	 $this->config->set("playercounter", false);
	   	  	 console("[JoinMOTD] PlayerCounter function has been disabled.");
	   	  	 $this->config->save();
	   	  }else
	   	  {
	   	  	 $this->config->set("playercounter", true);
	   	  	 $this->config->save();
	   	  	 console("[JoinMOTD] PlayerCounter function has been enabled.");
	   	  }
	   }else
	   if($cmd==="playercountermsg")
	   {
	      $pcmsg = implode(" ",$params);
	      $this->config->set('playercounter message', $pcmsg);
	      if($this->config->get('playercounter'))
	      {
	         console("[JoinMOTD] PlayerCounter message set.");
	      }else{console("[JoinMOTD] PlayerCounter message set, but PlayerCounter is disabled. \nUse /joinmotd playercounter to enable.");}
	      $this->config-save();
	   }
	}

	public function __destruct(){
	   $this->config->save();
	}
}
?>