<?php
/*
__PocketMine Plugin__
 name=MineReset
 description=Powerful mine reseting plugin
 version=0.4
 author=Falk
 class=mineReset
 apiversion=10,11,12
 */
class mineReset implements Plugin {
  private $api, $path;
  public function __construct(ServerAPI $api, $server = false) {
    $this->api = $api;
  }

  public function init() {
    $this->api->console->register("mine", "Manage mines", array($this, "command"));
    $this->api->addHandler("player.block.touch", array($this,"handleAdd"),50);
    $this->config = new Config($this->api->plugin->configPath($this)."mines.yml", CONFIG_YAML, array());
    $this->u = array();
  }
  public function __destruct() {}

  public function command($cmd, $params, $issuer, $alias, $args, $issuer) {
    switch ($params[0]) {
      case "create": 
      if(!($issuer instanceof Player)) return "Please run in game.";
        if(isset($this->u[$issuer->username])){
          unset($this->u[$issuer->username]);
          return "Mine creation mode turned off.";
        }
        if(isset($params[1])){
          if (array_key_exists($params[1], $this->api->plugin->readYAML($this->api->plugin->configPath($this). "mines.yml"))) return('[MineReset] This mine already exists!');
          $this->u[$issuer->username] = $params[1];
          return "Tap a block to set as position 1";
        }
        return "Usage: /mine create <NAME>";
      break;
    case "reset": 
      $name = $params[1];
      $mines = $this->api->plugin->readYAML($this->api->plugin->configPath($this). "mines.yml");
      if (array_key_exists($name, $mines)) {
        if ($mines[$name][6] !== "null") {
          $x1 = $mines[$name][0];
          $x2 = $mines[$name][1];
          $y1 = $mines[$name][2];
          $y2 = $mines[$name][3];
          $z1 = $mines[$name][4];
          $z2 = $mines[$name][5];
          $level = $this->api->level->get($mines[$name][7]);
          if($level == false) return "Can't reset now, world not loaded.";
          if ($x1 > $x2) {
            $temp = $x1;
            $x1 = $x2;
            $x2 = $temp;
          }
          if ($y1 > $y2) {
            $temp = $y1;
            $y1 = $y2;
            $y2 = $temp;
          }
          if ($z1 > $z2) {
            $temp = $z1;
            $z1 = $z2;
            $z2 = $temp;
          }

          $sets = $mines[$name][6];
          $id = array_keys($sets);
          $m = array_values($sets);
          $sum[0] = $m[0];
          for ($l = 1; $l < count($m); $l++) {
            $sum[$l] = $sum[$l-1] + $m[$l];
          }
        foreach($this->api->player->getAll($level) as $p) if($p->entity->x >= $x1 && $p->entity->x <= $x2 && $p->entity->y >= $y1 && $p->entity->y <= $y2 && $p->entity->z >= $z1 && $p->entity->z <= $z2) $p->teleport($level->getSpawn());
        $data = array('x' => $x1, 'y' => $y1, 'x1' => $x1, 'x2' => $x2, 'y1' => $y1, 'y2' => $y2, 'z1' => $z1, 'z2' => $z2, 'sum' => $sum, 'id' => $id, 'level' => $level);
        $this->api->schedule(2, array($this, 'buildMine'), $data);
        /*
          for ($i = $x1; $i <= $x2; $i++) {
            for ($j = $y1; $j <= $y2; $j++) {
              for ($k = $z1; $k <= $z2; $k++) {
                $a = rand(0, end($sum));
                for ($l = 0; $l < count($sum); $l++) {
                  if ($a < $sum[$l]) {
                    $level->setBlock(new Vector3($i, $j, $k), BlockAPI::get($id[$l], 0));
                    $l = count($sum);
                  }
                }
              }
            }
          }
          */
          return "[MineReset] " . $name . " is rebuilding";
        }
        else return "[MineReset] Mine not resetable";
      }
      else return "[MineReset] No mine with that name";
      break;
    case "pos1":
    case "pos2": 
      return "/mine <pos1/pos2> have been deprecated.";
      break;
    case "set": 
      $name = $params[1];
      $mines = $this->api->plugin->readYAML($this->api->plugin->configPath($this). "mines.yml");
      if (array_key_exists($name, $mines)) {
        $sets = array_slice($params, 2);
        foreach ($sets as $key => $item) {
          if ( $key & 1 ) {
            $save[$sets[$key-1]] = $item;
          }
        }
        $mines[$name][6] = $save;

        $this->api->plugin->writeYAML($this->api->plugin->configPath($this)."mines.yml", $mines);
        return "[MineReset] Mine setted";
      }
      else return "[MineReset] No mine found";
      break;
    default:
      if ($issuer instanceof Player) {
        $issuer->sendChat("---MineReset---");
        $issuer->sendChat("/mine create <NAME>");
        $issuer->sendChat("/mine set <NAME> <ITEM> <PERCENT>...");
        $issuer->sendChat("/mine reset <NAME>");
      }
      else {
        console("---MineReset---");
        console("/mine set <NAME> <ITEM> <PERCENT>...");
        console("/mine reset <NAME>");
      }
    }
  }
public function handleAdd($data){
  if(!isset($this->u[$data["player"]->username])) return;
  if(is_array($this->u[$data["player"]->username])){
          $mines = $this->api->plugin->readYAML($this->api->plugin->configPath($this). "mines.yml");
          $mines[$this->u[$data["player"]->username][0]] = array($this->u[$data["player"]->username][1], $data["target"]->x, $this->u[$data["player"]->username][2], $data["target"]->y, $this->u[$data["player"]->username][3], $data["target"]->z, "null", $data["target"]->level->getName());
          $this->api->plugin->writeYAML($this->api->plugin->configPath($this)."mines.yml", $mines);
          unset($this->u[$data["player"]->username]);
          $data["player"]->sendChat('[MineReset] Mine created! You can now set it with /mine set');
  }
  else{
    $this->u[$data["player"]->username] = array($this->u[$data["player"]->username],$data["target"]->x,$data["target"]->y,$data["target"]->z);
    $data["player"]->sendChat('Tap another block to set position 2');
  }
}
public function buildMine($data){
           for ($i = $data['x']; $i <= $data['x2']; $i++) {
                for ($j = $data['y']; $j <= $data['y2']; $j++) {
                        for ($k = $data['z1']; $k <= $data['z2']; $k++) {
                                $a = rand(0,end($data['sum']));
                                for ($l = 0; $l < count($data['sum']); $l++) {
                                        if ($a <= $data['sum'][$l]) {
                                            $data['level']->setBlock(new Vector3($i, $j, $k), BlockAPI::get($data['id'][$l], 0));
                                            break;
                                        }
                                }
                        }
                        $data['y']++;
                        $this->api->schedule(2, array($this, 'buildMine'), $data);
                        return;
                }
                $data['x']++;
                $data['y'] = $data['y1'];
                $this->api->schedule(2, array($this, 'buildMine'), $data);
                return;
        }
  }
}
