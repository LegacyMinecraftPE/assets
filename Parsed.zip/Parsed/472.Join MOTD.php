<?php
/*
__PocketMine Plugin__
name=Join MOTD
description=Sends a message to a joined player
version=1.0
author=Lambo
class=theJoinMOTD
apiversion=10
*/

class theJoinMOTD implements Plugin{

	private $api;
	
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}

	public function init(){
		$this->config = new Config($this->api->plugin->configPath($this) . "motd.yml", CONFIG_YAML, array("motd" => "Welcome back!", "prefix" => "[Server Name]"));
		$this->api->addHandler("player.spawn", array($this, "playerSpawned"));
		$this->api->console->register('joinmotd', "Join MOTD", array($this, 'commandHandler'));
	}

	public function playerSpawned($data){
		$data->sendChat($this->config->get("prefix") . " " . $this->config->get('motd'));
	}
	
	public function commandHandler($cmd, $params, $issuer, $alias)
	{
	   $cmd = array_shift($params);
	   if($cmd==="motd")
	   {
	      $motd = implode(" ",$params);
	      $this->config->set("motd", $motd);
	      console("[JoinMOTD] Motd set.");
	      $this->config->save();
	   }else
	   if($cmd==="prefix")
	   {
	      $prefix = implode(" ",$params);
	      $this->config->set("prefix", $prefix);
	      console("[JoinMOTD] Prefix set.");
	      $this->config->save();
	   }
	}

	public function __destruct(){
	
	}
}
?>