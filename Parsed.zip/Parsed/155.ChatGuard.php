<?php

/*
__PocketMine Plugin__
name=ChatGuardDynamicLoader
description=A Dynamic Loader for the ChatGuard plugin.
version=2.0.0
author=sekjun9878
class=ChatGuardDynamicLoader
apiversion=8,9,10,11,12,13,14
*/



class ChatGuardDynamicLoader implements Plugin
{
	private $api, $server;
	
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
		$server = ServerAPI::request();
		
		$this->api->plugin->load("http://gist.github.com/sekjun9878/6636915/raw/ChatGuard.php");
	}
	
	public function init()
	{
		
	}
	
	public function __destruct(){

	}
}
