<?php

/*
__PocketMine Plugin__
name=RealTime
description=Manage time
version=1.1
author=Guillaume351
class=send
apiversion=12
*/

class send implements Plugin{
	private $api;
public function __construct(ServerAPI $api, $server = false){
     $this->api = $api;
   }

   
   public function init(){
     
	$this->path =$this->api->plugin->configPath($this);
	$this->api->console->register("rtday", "have always day", array($this, "mode"));	
	$this->api->console->register("rt", "have real time", array($this, "mode"));	
	$this->api->console->register("rtnight", "have always day", array($this, "mode"));
	$this->api->console->register("rtsunset", "have always sunset", array($this, "mode"));	
	$this->api->console->register("rtsunrise", "have always sunrise", array($this, "mode"));	
	$this->api->console->register("rtnormal", "have normal time", array($this, "mode"));		

if(!file_exists($this->path . "mode.txt")) {
file_put_contents($this->path . "mode.txt","0");
}
	$Message =  "In the file config, put only number to correct the hour. For exemple, if for you server it's 8am but it is 2pm for you, put +6.
	If it is 2pm for your server but 8am for you, put -6.
	To change manually the mode, in mode.txt : 0= real time, 1 = always day and 2 = always night, 3 = normal time, 4 = sunset, 5 = sunrise.
	/rtday : lock time to day
	/rtnight : lock time to night
	/rt : enable realtime
	/rtnormal : disable all time changes, back to normal time
	/rtsunset : lock time to sunset
	/rtsunrise : lock time to sunrise";
	
	
	$this->config = new Config($this->api->plugin->configPath($this)."config.txt", CONFIG_YAML, array("Version"=>'1.1 '  , "Time changes" =>'+0'));
new Config($this->api->plugin->configPath($this)."READ ME.txt");
	
	file_put_contents($this->path . "READ ME.txt",$Message);
	$modify = ($this->config->get("Mode"));
$modify = ($this->config->get("Time changes"));


$test = date('H') + ($modify);
	
console("[RealTime] It is " . $test. " (20h is same as 8pm)");
$this->api->schedule(1,array($this,"changetime"),true, 'server.schedule');
   }
   
   public function mode($cmd){
   					  switch($cmd){
	    case "rtday":
   	file_put_contents($this->api->plugin->configPath($this) . "mode.txt","1");
   	console("[RealTime] Time lock to day.");
   	break;
    
case "rtnight":
   	file_put_contents($this->api->plugin->configPath($this) . "mode.txt","2");
   	console("[RealTime] Time lock to night.");
   	break;
   	
   	case "rtnormal":
   	file_put_contents($this->api->plugin->configPath($this) . "mode.txt","3");
   	console("[RealTime] Time unlock (back to normal time).");
   	break;
   	
   	case "rtsunset":
   	file_put_contents($this->api->plugin->configPath($this) . "mode.txt","4");
   	console("[RealTime] Time lock to sunset.");
   	break;
	
	case "rtsunrise":
   	file_put_contents($this->api->plugin->configPath($this) . "mode.txt","5");
   	console("[RealTime] Time lock to sunrise.");
   	break;
   	
   	case "rt":
   	file_put_contents($this->api->plugin->configPath($this) . "mode.txt","0");
   	console("[RealTime] RealTime enabled.");
   	break;
	break;
	}
	
}
    
    public function changetime(){
 $modify = ($this->config->get("Time changes"));
	$times = date('H');
	$time = $times + ($modify);
	$ticks = 0;
	$mode= file_get_contents($this->api->plugin->configPath($this) . "mode.txt");
	
	if ($mode == 1){
		$ticks = 6001;
	}
	if ($mode == 4){
		$ticks = 10001;
	}
	if ($mode == 5){
		$ticks = 18551;
	}

	if ($mode == 2){
		$ticks = 13751;		
	}
	
	if ($mode == 0){
		
	if ($time == 0) {
		$ticks = 13750;
		}
	if ($time == 1) {
		$ticks = 15001;
		}	
	if ($time == 2) {
		$ticks = 15501;
		}	
	if ($time == 3) {
		$ticks = 16001;
		}	
	if ($time == 4) {
		$ticks = 16501;
		}	
	if ($time == 5) {
		$ticks = 17001;
		}	
	if ($time == 6) {
		$ticks = 17501;
		}	
	if ($time == 7) {
		$ticks = 18001;
		}	
	if ($time == 8) {
		$ticks = 1;
		}	
	if ($time == 9) {
		$ticks = 1001;
		}	
	if ($time == 10) {
		$ticks = 2001;
		}	
	if ($time == 11) {
		$ticks = 3001;
		}	
	if ($time == 12) {
		$ticks = 4001;
		}	
	if ($time == 13) {
		$ticks = 5001;
		}	
	if ($time == 14) {
		$ticks = 6001;
		}	
	if ($time == 15) {
		$ticks = 7001;
		}	
	if ($time == 16) {
		$ticks = 8251;
		}	
	if ($time == 17) {
		$ticks = 9251;
		}	
	if ($time == 18) {
		$ticks = 9751;
		}	
	if ($time == 19) {
		$ticks = 10001;
		}	
	if ($time == 20) {
		$ticks = 11001;
		}	
	if ($time == 21) {
		$ticks = 12001;
		}	
	if ($time == 22) {
		$ticks = 12751;
		}	
	if ($time == 23) {
		$ticks = 13501;
		}
}
if ($mode == 3){}
else{
	$this->api->time->set($ticks);
	}
	}
    
 public function __destruct(){
    }
}
 
?>