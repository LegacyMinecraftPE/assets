<?php
/*
__PocketMine Plugin__
name=GodMode
author=LDX
version=1.0
apiversion=12
class=GodMode
*/
class GodMode implements Plugin {
  private $api;
  public function __construct(ServerAPI $api,$server = false) {
    $this->api = $api;
  }
  public function init() {
    $this->api->addHandler("entity.health.change",array($this,"event"));
    $this->api->console->register("god","[player]",array($this,"command"));
  }
  public function command($cmd,$args,$issuer) {
    if(isset($args[0])) {
      if($this->api->player->get($args[0]) != false) {
        $name = strtolower($this->api->player->get($args[0])->username);
        $p = $this->api->player->get($args[0]);
        if(isset($this->enabled[$name])) {
          if($this->enabled[$name] == true) {
            $this->enabled[$name] = false;
            return "God mode disabled for " . $this->api->player->get($args[0])->username . "!";
          } else {
            $this->enabled[$name] = true;
            return "God mode enabled for " . $this->api->player->get($args[0])->username . "!";
          }
        } else {
          $this->enabled[$name] = true;
          return "God mode enabled for " . $this->api->player->get($args[0])->username . "!";
        }
      } else {
        return "Player not connected.";
      }
    } else if($issuer instanceof Player) {
      $name = strtolower($issuer->username);
      if(isset($this->enabled[$name])) {
        if($this->enabled[$name] == true) {
          $this->enabled[$name] = false;
          return "God mode disabled!";
        } else {
          $this->enabled[$name] = true;
          return "God mode enabled!";
        }
      } else {
        $this->enabled[$name] = true;
        return "God mode enabled!";
      }
    } else {
      return "Must be used in-game.";
    }
  }
  public function event($data) {
    $t = $data["entity"];
    if($this->api->player->get($t->name) instanceof Player) {
      $name = strtolower($this->api->player->get($t->name)->username);
      if(isset($this->enabled[$name]) && $this->enabled[$name] == true) {
        return false;
      }
    }
  }
  public function __destruct() { }
}
?>
