<?php

/*
__PocketMine Plugin__
name=Google Analytics
description=
version=1.1
author=DarkN3ss
class=Google_Analytics
apiversion=10, 11, 12
*/

class Google_Analytics implements Plugin{
   private $api;

   public function __construct(ServerAPI $api, $server = false){
     $this->api = $api;
   }

   public function init(){
		$this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array('analyticsServerAccount' => "MO-XXXXXXXX-X", 'analyticsServerDomain' => "website.com"));
		define("AnalyticsServerAccount", $this->config->get('analyticsServerAccount'));
		define("AnalyticsServerDomain", $this->config->get('analyticsServerDomain'));
		
		$this->api->addHandler("player.quit", array($this, "eventHandler"), 50);
		$this->api->addHandler("player.connect", array($this, "eventHandler"), 50);
		$this->api->addHandler("player.spawn", array($this, "eventHandler"), 50);
		$this->api->addHandler("player.respawn", array($this, "eventHandler"), 50);
		$this->api->addHandler("player.death", array($this, "eventHandler"), 50);
   }
   
   
   public function eventHandler($data, $event){
		switch($event){
			case "player.quit":
				if(!($data instanceof Player)){
					break;
				}
				$this->pos[$data->username][1] = "Playtime Unkown";
				  if ($this->pos[$data->username][1] != null){
					$this->pos[$data->username][2] = (round(microtime(true) * 1000) - $this->pos[$data->username][0]) / 1000;
					if ($this->pos[$data->username][2] / 60 / 60 >= 5) {
					  $this->pos[$data->username][1] = "Played more than 5 hours";
					} else if ($this->pos[$data->username][2] / 60 / 60 >= 4) {
					  $this->pos[$data->username][1] = "Played 4 hours";
					} else if ($this->pos[$data->username][2] / 60 / 60 >= 3) {
					  $this->pos[$data->username][1] = "Played 3 hours";
					} else if ($this->pos[$data->username][2] / 60 / 60 >= 2) {
					  $this->pos[$data->username][1] = "Played 2 hours";
					} else if ($this->pos[$data->username][2] / 60 / 60 >= 1) {
					  $this->pos[$data->username][1] = "Played 1 hour";
					} else if (($this->pos[$data->username][2] / 60 <= 30) && ($this->pos[$data->username][2] / 60 > 5)) {
					  $this->pos[$data->username][1] = "Played less than 30 minutes";
					} else {
					  $this->pos[$data->username][1] = "Played less than 5 minutes";
					}
				  }
				$this->track($data->username, $data->ip,$data->username,"Quit", $this->pos[$data->username][1]);
				break;
			case "player.connect":
				if(!($data instanceof Player)){
					break;
				}
				$this->pos[$data->username][0] = round(microtime(true) * 1000);
				$this->track($data->username, $data->ip,$data->username,"Connecting",$data->ip); //$visitorId, $visitorIp, $category, $action, $label
				break;
			case "player.spawn":
				if(!($data instanceof Player)){
					break;
				}
				$this->track($data->username, $data->ip,$data->username,"Spawn",$data->username);
				break;
			case "player.death":
				if(is_numeric($data["cause"])){
					$e = $this->api->entity->get($data["cause"]);
					$user["target"] = strtolower($e->name);
					$playerIP = $this->api->player->get($user['target'])->ip;
					if($e instanceof Entity){
						switch($e->class){
							case ENTITY_PLAYER:
								$message = "Was killed by ".$e->name;
								$this->track($e->name, $playerIP, $e->name,"Kill Total", "Events = Kills");
								$this->track($e->name, $playerIP, $e->name,"Kill", $data["player"]->username);
								break;
							default:
								$message = "Was killed";
								break;
							}
						}
					}else{
						switch($data["cause"]){
							case "cactus":
								$message = "Was pricked to death";
								break;
							case "lava":
								$message = "Tried to swim in lava";
								break;
							case "fire":
								$message = "Went up in flames";
								break;
							case "burning":
								$message = "Burned to death";
								break;
							case "suffocation":
								$message = "Suffocated in a wall";
								break;
							case "water":
								$message = "Drowned";
								break;
							case "void":
								$message = "Fell out of the world";
								break;
							case "fall":
								$message = "Hit the ground too hard";
								break;
							case "explosion":
								$message = "Blew up";
								break;
							default:
								$message = "Died";
								break;
						}
					}
				$this->track($data["player"]->username, $data["player"]->ip,$data["player"]->username,"Died", $message);
				break;
			case "player.respawn":
				if(!($data instanceof Player)){
					break;
				}
				$this->track($data->username, $data->ip,$data->username,"Respawn", "At Spawn");
				break;
		}
		return;
	}
	
	public function track($username, $visitorIp, $category, $action, $label){
		$this->trackPageAction($username, $visitorIp, $category, $action, $label);
		$this->trackPageView($username, $visitorIp);
	}
	
	public function trackPageAction($visitorId, $visitorIp, $category, $action, $label)
	{
		$message = AnalyticsServerAccount . " " . $visitorId;	
		$messageAsNumber = md5(strlen($message));
		$md5String = $messageAsNumber;
			while(strlen($md5String) < 32)
			{
				$md5String = "0" . $md5String;
			}
		$getVisitorId =  ("0x" . substr($md5String,0, 16));
		$event = '(' . $category . '*' . $action . '*' . $label . ')';
	   
		$utmUrl = 'http://www.google-analytics.com/__utm.gif?utmwv=4.4sj&utmn=' .
		  rand() . 
		  "&utmhn=" . AnalyticsServerDomain . 
		  "&utmr=" . "-" . 
		  "&utmp=" . 
		  "&utmt=" . "event" . 
		  "&utme=" . "5" . str_replace(' ', '%20', $event) .
		  "&utmac=" . AnalyticsServerAccount . 
		  "&utmcc=__utma%3D999.999.999.999.999.1%3B" . 
		  "&utmvid=" . $getVisitorId . 
		  "&utmdt=" . ("MCPE") . 
		  "&utmip=" . $visitorIp;
		//$this->api->chat->broadcast("Tracker Url: " . $utmUrl);  //for debug
		
		$this->asyncOperation($utmUrl);
	}
	
    public function trackPageView($visitorId, $visitorIp)
	{
		$message = AnalyticsServerAccount . " " . $visitorId;	
		$messageAsNumber = md5(strlen($message));
		$md5String = $messageAsNumber;
			while(strlen($md5String) < 32)
			{
				$md5String = "0" . $md5String;
			}
		$getVisitorId =  ("0x" . substr($md5String,0, 16));
	   
		$utmUrl = 'http://www.google-analytics.com/__utm.gif?utmwv=4.4sj&utmn=' .
		  rand() . 
		  "&utmhn=" . AnalyticsServerDomain . 
		  "&utmr=" . "-" . 
		  "&utmp=" . AnalyticsServerDomain . 
		  "&utmac=" . AnalyticsServerAccount . 
		  "&utmcc=__utma%3D999.999.999.999.999.1%3B" . 
		  "&utmvid=" . $getVisitorId  . 
		  "&utmdt=" . ("MCPE") . 
		  "&utmip=" . $visitorIp;
		//$this->api->chat->broadcast("Tracker Url: " . $utmUrl);  //for debug
		
		$this->asyncOperation($utmUrl);
    }
	
	public function asyncOperation($url){
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1);

		curl_exec($ch);
		curl_close($ch);
	}
   
	public function __destruct(){
	}
}

/*                             .-'''''-.
                               |'-----'|
                               |-.....-|
                               |       |
                               |       |
              _,._             |       |
         __.o`   o`"-.         |       |
      .-O o `"-.o   O )_,._    |       |
     ( o   O  o )--.-"`O   o"-.`'-----'`
      '--------'  (   o  O    o)  
                   `----------` 
				   Oh HEY look some cookies and milk for you Judges :D . Just saying this is NOT a bribe ಠ_ಠ 
				   */

?>