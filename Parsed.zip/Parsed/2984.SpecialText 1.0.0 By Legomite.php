<?php

/*
 __PocketMine Plugin__
 name=SpecialText
 version=1.0.0
 author=Legomite
 class=color23
 apiversion=12,13,14
 */

 /*
___Changelog___
  1.0.0
  * Initial Release
  */
class color23 implements Plugin {
	private $api, $message, $player;
	public function __construct(ServerAPI $api, $server = false) {
		$this -> api = $api;
		$this -> server = ServerAPI::request();
	}

	public function init() {
		$this -> api -> console -> register("text", "Info on SpecialText", array($this, "cmd"));
		$this -> api -> console -> register("texthelp", "Help on Special Text", array($this, "cmd"));
		$this -> api -> console -> register("text1", "Write in Gray font!", array($this, "cmd"));
		$this -> api -> console -> register("text2", "Write in skinny font!", array($this, "cmd"));
		$this -> api -> console -> register("text3", "Write in skinny and gray font!", array($this, "cmd"));
		$this -> api -> ban -> cmdWhitelist("text");
		$this -> api -> ban -> cmdWhitelist("texthelp");
		$this -> api -> ban -> cmdWhitelist("text1");
		$this -> api -> ban -> cmdWhitelist("text2");
		$this -> api -> ban -> cmdWhitelist("text3");
		$this -> api -> console -> alias("t", "text");
		$this -> api -> console -> alias("t?", "texthelp");
		$this -> api -> console -> alias("t1", "text1");
		$this -> api -> console -> alias("t2", "text2");
		$this -> api -> console -> alias("t3", "text3");
	console("§a[SpecialText] loading...");
		console("§a[SpecialText] §dThis plugin is created by §cLegomite.§dCheck if you have the latest version of this plugin!");
	}

	public function cmd($cmd, $args, $issuer) {
		switch($cmd) {
			case "text" :
				$issuer -> sendChat("/Version 1.0.0 By Legomite lego_mite@yahoo.com\n");
				break;
			case "texthelp" :
				$issuer -> sendChat("/text1 ::Does the gray color\n");
				$issuer -> sendChat("/text2 ::Does the skinny font\n");
				$issuer -> sendChat("/text3 ::Does the gray color and the skinny font\n");
				break;
			case "text1" :
				if ($args[0] == "") {
					$output = "Usage: /text1 (Message)";
				} else {
					$name = $issuer -> username;
					$msg = implode(" ", $args);
					//Todo:
					//Remove Random slash
					$this -> api -> chat -> broadcast("/<$name> $msg\n");
					break;
				}
			case "text2" :
				if ($args[0] == "") {
					$output .= "Usage: /text2 (Message)";
				} else {
					$name = $issuer -> username;
					$msg2 = implode(" ", $args);
					$this -> api -> chat -> broadcast("<$name>“ $msg2 ” ");
					break;
				}
			case "text3" :
				if ($args[0] == "") {
					$issuer -> sendChat("Usage: /text3 (Message)");
				} else {
					$name = $issuer -> username;
					$msg3 = implode(" ", $args);
					$this -> api -> chat -> broadcast("/<$name>“ $msg3\n");
					break;
				}
		}
	}

	public function __destruct() {
	}

}
