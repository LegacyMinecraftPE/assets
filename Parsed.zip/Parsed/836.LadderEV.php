﻿<?php
/*
__Pocketmine Plugin__
name=LadderEV
version=1.0
author=Nexus
class=LadderEV
apiversion=9,10
*/
class LadderEV implements Plugin{
        private $api;
        public function __construct(ServerAPI $api, $server = false){$this->api = $api;}
        public function init(){
		$this->api->addHandler("player.block.touch", array($this, "blocktouch"), 100);
        }
        public function __destruct(){}
	public function blocktouch($data){
		$x = $data['target']->x;
		$y = $data['target']->y; 
		$z = $data['target']->z;
		if($data['target']->getID() == 65 && $data["item"]->getID() == 280){
			$level = $data['target']->level;
			for($i = 1;$i < 256;$i++){
				$block[$i] = $level->getBlock(new Position($x,$y+$i,$z, $data['target']->level));
				if($block[$i]->getID() != 65) {
					$data["player"]->teleport(new Vector3($block[$i]->x + 0.5, $block[$i]->y, $block[$i]->z + 0.5));;
					break;
				}
			}
			
		}
	}

}
?>