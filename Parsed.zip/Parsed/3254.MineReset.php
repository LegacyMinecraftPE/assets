<?php
/*
__PocketMine Plugin__
 name=MineReset
 description=Powerful mine resetting plugin
 version=0.5
 author=Falk
 class=MineReset
 apiversion=10,11,12
 */

class MineReset implements Plugin
{
    private $api;

    public function __construct(ServerAPI $api, $server = false)
    {
        $this->api = $api;
    }

    public function init()
    {
        $this->api->console->register("mine", "Manage mines", array($this, "command"));
        $this->api->addHandler("player.block.touch", array($this, "handleAdd"), 50);
        $this->config = new Config($this->api->plugin->configPath($this) . "mines.yml", CONFIG_YAML, array());
        $this->u = array();
    }

    public function __destruct()
    {
    }

    public function command($cmd, $params, $issuer, $alias, $args, $issuer)
    {
        switch ($params[0]) {
            case "create":
                if (!($issuer instanceof Player)) return "Please run in game.";
                if (isset($this->u[$issuer->username])) {
                    unset($this->u[$issuer->username]);
                    return "Mine creation mode turned off.";
                }
                if (isset($params[1])) {
                    if (array_key_exists($params[1], $this->api->plugin->readYAML($this->api->plugin->configPath($this) . "mines.yml"))) return ('[MineReset] This mine already exists!');
                    $this->u[$issuer->username] = $params[1];
                    return "[MineReset] Mine creation wizard started.\nTap a block to set as position 1";
                }
                return "Usage: /mine create <NAME>";
                break;
            case "reset":
            case "longreset":
                $name = $params[1];
                $mines = $this->api->plugin->readYAML($this->api->plugin->configPath($this) . "mines.yml");
                if (array_key_exists($name, $mines)) {
                    if ($mines[$name][6] !== "null") {
                        $level = $this->api->level->get($mines[$name][7]);
                        if ($level == false) return "Can't reset now, world not loaded.";
                        $x1 = min($mines[$name][0], $mines[$name][1]);
                        $x2 = max($mines[$name][0], $mines[$name][1]);
                        $y1 = min($mines[$name][2], $mines[$name][3]);
                        $y2 = max($mines[$name][2], $mines[$name][3]);
                        $z1 = min($mines[$name][4], $mines[$name][5]);
                        $z2 = max($mines[$name][4], $mines[$name][5]);
                        $sets = $mines[$name][6];
                        $id = array_keys($sets);
                        $m = array_values($sets);
                        $sum[0] = $m[0];
                        for ($l = 1; $l < count($m); $l++) $sum[$l] = $sum[$l - 1] + $m[$l];
                        foreach ($this->api->player->getAll($level) as $p) if ($p->entity->x >= $x1 && $p->entity->x <= $x2 && $p->entity->y >= $y1 && $p->entity->y <= $y2 && $p->entity->z >= $z1 && $p->entity->z <= $z2) $p->teleport($level->getSpawn());
                        if($params[0] == "longreset"){
                            $data = array('x' => $x1, 'y' => $y1, 'x1' => $x1, 'x2' => $x2, 'y1' => $y1, 'y2' => $y2, 'z1' => $z1, 'z2' => $z2, 'sum' => $sum, 'id' => $id, 'level' => $level);
                            $this->api->schedule(2, array($this, 'buildMine'), $data);
                            return "[MineReset] " . $name . " is rebuilding.";
                        }
                        else{
                            $send = (($x2-$x1)*($y2-$y1)*($z2-$z1) < 524288);
                              for ($i = $x1; $i <= $x2; $i++) {
                                for ($j = $y1; $j <= $y2; $j++) {
                                  for ($k = $z1; $k <= $z2; $k++) {
                                    $a = rand(0, end($sum));
                                    for ($l = 0; $l < count($sum); $l++) {
                                      if ($a <= $sum[$l]) {
                                        $level->setBlockRaw(new Vector3($i, $j, $k), BlockAPI::get($id[$l], 0), false, $send);
                                        $l = count($sum);
                                      }
                                    }
                                  }
                                }
                              }
                            /*
                                Code from WorldEditor by @shoghicp
                            */
                            if($send === false){
                                $forceSend = function($X, $Y, $Z){
                                    $this->changedCount[$X.":".$Y.":".$Z] = 4096;
                                };          
                                $forceSend->bindTo($level, $level);
                                for($X = $x1 >> 4; $X <= ($x2 >> 4); ++$X){
                                    for($Y = $y1 >> 4; $Y <= ($y2 >> 4); ++$Y){
                                        for($Z = $z1 >> 4; $Z <= ($z2 >> 4); ++$Z){
                                            $forceSend($X,$Y,$Z);
                                        }
                                    }
                                }
                            }
                            /*

                            */
                            return "[MineReset] " . $name . " has been reset";
                        }
                    } else return "[MineReset] You need to set this mine using /mine set";
                } else return "[MineReset] No mine with that name";
                break;
            case "pos1":
            case "pos2":
                return "/mine <pos1/pos2> have been deprecated.";
                break;
            case "set":
                $name = $params[1];
                if (!isset($params[3]) || count($params) % 2 !== 0) return "--Setting a Mine-- \n In order to set a mine you must specify it's name followed by a list of block IDs and the coresponding percentages to set in the mine. \n Example: To set a mine to half stone and half air use: /mine set " . (isset($params[1]) ? $name : "<NAME>") . " 1 50 0 50";
                $mines = $this->api->plugin->readYAML($this->api->plugin->configPath($this) . "mines.yml");
                if (array_key_exists($name, $mines)) {
                    $sets = array_slice($params, 2);
                    foreach ($sets as $key => $item) {
                        if ($key & 1) {
                            $save[$sets[$key - 1]] = $item;
                        }
                    }
                    $mines[$name][6] = $save;

                    $this->api->plugin->writeYAML($this->api->plugin->configPath($this) . "mines.yml", $mines);
                    return "[MineReset] Mine setted.";
                } else return "[MineReset] No mine found";
                break;
            default:
                if ($issuer instanceof Player) {
                    return "--MineReset-- \n /mine create <NAME> \n /mine set <NAME> <ITEM> <PERCENT>... \n /mine reset <NAME>";
                } else {
                    return "--MineReset-- \n /mine set <NAME> <ITEM> <PERCENT>... \n /mine reset <NAME>";
                }
        }
    }

    public function handleAdd($data)
    {
        //$this->api->dhandle("entity.event", array("entity" => $data['player']->entity, "event" => 2));
        if (!isset($this->u[$data["player"]->username])) return;
        if (is_array($this->u[$data["player"]->username])) {
            $mines = $this->api->plugin->readYAML($this->api->plugin->configPath($this) . "mines.yml");
            $mines[$this->u[$data["player"]->username][0]] = array($this->u[$data["player"]->username][1], $data["target"]->x, $this->u[$data["player"]->username][2], $data["target"]->y, $this->u[$data["player"]->username][3], $data["target"]->z, "null", $data["target"]->level->getName());
            $this->api->plugin->writeYAML($this->api->plugin->configPath($this) . "mines.yml", $mines);
            unset($this->u[$data["player"]->username]);
            $data["player"]->sendChat('[MineReset] Mine created! You can now set it with /mine set');
        } else {
            $this->u[$data["player"]->username] = array($this->u[$data["player"]->username], $data["target"]->x, $data["target"]->y, $data["target"]->z);
            $data["player"]->sendChat('Tap another block to set position 2');
        }
    }

    public function buildMine($data)
    {
        for ($i = $data['x']; $i <= $data['x2']; $i++) {
            for ($j = $data['y']; $j <= $data['y2']; $j++) {
                for ($k = $data['z1']; $k <= $data['z2']; $k++) {
                    $a = rand(0, end($data['sum']));
                    for ($l = 0; $l < count($data['sum']); $l++) {
                        if ($a <= $data['sum'][$l]) {
                            $data['level']->setBlock(new Vector3($i, $j, $k), BlockAPI::get($data['id'][$l], 0));
                            break;
                        }
                    }
                }
                $data['y']++;
                $this->api->schedule(2, array($this, 'buildMine'), $data);
                return;
            }
            $data['x']++;
            $data['y'] = $data['y1'];
            $this->api->schedule(2, array($this, 'buildMine'), $data);
            return;
        }
    }
}
