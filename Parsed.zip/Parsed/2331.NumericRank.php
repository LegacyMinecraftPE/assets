<?php

/*
__PocketMine Plugin__
class=NumRkPlugin
name=Numeric Ranks
author=PEMapModder
version=alpha 0
apiversion=12
*/

/*
 * ChangeLog:
 * Edition alpha
 * * Version 1: Initial release - Last commit #d7fd8d9 submittee
 * * * Commit #8066f8c: Initial commit
 * * * Commit #6398bcd: Added chat override, unfinished ConditionalExpression!
 * * * Commit #47c81e5: Partially added commands
 * * * Commit #c3f754f: Continue adding commands, cmd-echo, first testing, safe-mode ConExp, more work on a TODO ConExp, MainServer::handle() access functions externally!
 * * * Commit #3054773: events
 * * * Commit #a60b8bd: addHandler()
 * * * Commit #536df6a: self instance returned
 * * * Commit #d7fd8d9: testing and syntax debugs, preparation for release, fully added commands and fixed bugs for missing "whitelist" and "numrank" (d*** how could I have forgotten myself...)
 * * Version 2: Bug fixes
 * * * Commit #???????: Added bug list!
*/
/*
 * Known bugs:
 * Player with no standard tags have ranks of nothing. Data type of the emptiness TBC.
*/

class NumRkPlugin implements Plugin{
	public function init(){
		$this->server=ServerAPI::request();
		$this->dir=$this->server->api->plugin->configPath($this);
		if("rank-names"==="rank-names"){
			$path=$this->dir."rank-names.";
			$ext="yml";
			if(is_file($path."txt"))
				$ext="txt";
			$this->ranks=new Config($path.$ext, CONFIG_YAML, array(
					"default"=>"player",
					"watched"=>-50,
					"player"=>0,
					"vip"=>50,
					"trusted"=>100,
					"admin"=>150,
					"owner"=>200
					// "console"=>PHP_INT_MAX,
					// "rcon"=>PHP_INT_MAX-1
			));
			if(false===$this->ranks->get($this->ranks->get("default")))
				console("[ERROR] Default rank permission not found. Strange bugs may occur.");
		}
		if("rank-perm-indices"==="rank-perm-indices"){
			$path=$this->dir."rank-permissions.";
			$ext="yml";
			if(is_file($path."txt"))
				$ext="txt";
			$this->perms=new Config($path.$ext, CONFIG_YAML, array(
					"ban"=>150,
					"banip"=>150,
					"defaultgamemode"=>200,
					"deop"=>200,
					"difficulty"=>150,
					"gamemode"=>100,
					"give"=>100,
					"help"=>-100,
					"kick"=>100,
					"kill"=>100,
					"list"=>-100,
					"me"=>50,
					"numrank"=>200,
					"op"=>200,
					"ping"=>-100,
					"save-all"=>200,
					"save-off"=>200,
					"save-on"=>200,
					"say"=>50,
					"seed"=>50,
					"spawn"=>50,
					"spawnpoint"=>100,
					"status"=>0,
					"stop"=>PHP_INT_MAX,
					"sudo"=>150, // consider 200
					"tell"=>50,
					"time"=>100,
					"tp"=>100,
					"whitelist"=>PHP_INT_MAX,
			));
		}
		if("general-config"==="general-config"){
			$path=$this->dir."general-config.";
			$ext="yml";
			if(is_file($path."txt"))
				$ext="txt";
			$this->config=new Config($path.$ext, CONFIG_YAML, array(
					"chat-override"=>"[@rank] @name: @message",
					"cmd-echo"=>true,
					"cmd-echo-list"=>array("console", "README: You can add player names here"), // honestly I nearly added my own name into it by accident
					"chat-only-broadcast-in-that-world"=>false, // follow the tradition of PocketMine
			));
		}
		@mkdir($this->dir."players/");
		$this->server->addHandler("player.chat", array($this, "onChat"));
		$this->server->addHandler("console.check", array($this, "cslCheck"), 0x1000); // fully monopolize the permissions
		$this->server->addHandler("console.command", array($this, "cslCmd"), 0x1000); // fully monopolize the permissions
		$c=$this->server->api->console;
		$c->register("numrank", "<cmd|help> [args ...] NumericRanks command", array($this, "cmd"));
		$c->alias("nrcmd", "numrank cmd");
		$c->alias("nrplyr", "numrank player");
		$this->server->addHandler("numrk.player.get.int", array($this, "getPlyrPerm")); // fourth word stands for the return type, third is set/get, second is subcmd, first is plugin name. Fifth onwards are miscellaneous info
		$this->server->addHandler("numrk.rank.get.string", array($this, "getRankName"));
		$this->server->addHandler("numrk.cmd.get.int.min", array($this, "getCmdMinPerm"));
		$this->server->addHandler("numrk.instance.get", array($this, "getInstance"));
	}
	public function __construct(ServerAPI $a, $s=0){
	}
	public function __destruct(){
	}
	public function getPlyrPerm($player){
		$file=@file_get_contents($this->dir."players/".strtolower(trim("$player")));
		if($file===false){
			$file=$this->ranks->get($this->ranks->get("default"));
		}
		return (int)$file;
	}
	public function getPlyrPermName($plyr){
		return $this->getRankName($this->getPlyrPerm($plyr)); // server handler function
	}
	public function getInstance(){
		return $this;
	}
	public function setPlyrPerm($player, $perm){
		file_put_contents($this->dir."players/".strtolower(trim("$player")), (int)$perm);
	}
	public function getRankName($index){
		if(!is_numeric($index) or ($ret=array_search($index, $this->ranks->getAll()))){
			$ret="$index";
			foreach($this->ranks->getAll() as $rk=>$idx){
				if($idx<=$index)
					$ret=$rk;
			}
			return $ret;
		}
		return $ret;
	}
	public function getCmdMinPerm($cmd){
		$index=$this->perms->get($cmd);
		if(!is_numeric($index))
			return false;
		return $index;
	}
	private function getChat($p, $msg){
		$idx=$this->getPlyrPerm($p);
		// console("[DEBUG] $p index $idx");
		$name=$this->getRankName($idx);
		return $this->parseCfgStrStable($this->config->get("chat-override"), array("rank", "name", "message", "msg"), array($name, "$p", $msg, $msg));
	}
	public function onChat($data){
		$msg=$this->getChat($data["player"], $data["message"]);
		console("[CHAT] $msg");
		foreach($this->server->api->player->getAll($this->config->get("chat-only-broadcast-in-that-world")===true?$data["player"]->entity->level:null) as $p)
			$p->sendChat($msg);
		return false;
	}
	public function cslCheck($data){
		$pp=$this->getPlyrPerm($data["issuer"]);
		$cmp=$this->getCmdMinPerm($data["cmd"]);
		if($pp>=$cmp)
			return true;
	}
	public function cslCmd($data){
		if(is_string($data["issuer"]))
			return;
		if($data["cmd"]=="login" or $data["cmd"]=="register") // security
			$data["parameters"]=array("[NumRank]", "[CmdEcho]", "Hidden", "for", "safety", "reasons");
		if($this->config->get("cmd-echo"))
			$this->cmdEcho($data["issuer"], "/".$data["cmd"]." ".implode(" ", $data["parameters"]), @$data["alias"]);
		$pp=$this->getPlyrPerm($data["issuer"]);
		$cmp=$this->getCmdMinPerm($data["cmd"]);
		if($pp<$cmp)
			return false;
	}
	public function setMute($args){
		$this->mutes[$args[0]]=$args[1];
	}
	public function cmdEcho($issuer, $line, $alias=false){
		$path="\$this->mutes[\$issuer->iusername]";
		eval("\$mute=isset($path) and $path===true;");
		if($mute)return;
		if(substr($line, 6)==="/help "){
			$this->server->schedule(1, array($this, "setMute"), array($issuer->iusername, false));
			$this->setMute($issuer->iusername, true);
		}
		if($alias!==false)
			$line.=" with alias /$alias";
		foreach($this->config->get("cmd-echo-list") as $echoee){
			if($echoee==="console")
				console(FORMAT_LIGHT_PURPLE."[NumRank CmdEcho] $issuer has run command $line");
			else{
				$p=$this->server->api->player->get($echoee, false); // no alike
				if($p instanceof Player)
					$p->sendChat("[NumRank CmdEcho] $issuer has run command $msg");
			}
		}
	}
	public function parseCfgStrStable($str, $params=array(), $data=array()){
		foreach($params as $key=>$name){
			$str=str_replace("@".$name, $data[$key], $str);
		}
		return $str;
	}
	public function parseConStr($conStr, $names=array(), $data=array()){
		$output=$conStr;
		foreach($names as $k=>$escape)
			$output=str_replace("@$escape", $data[$k], $output);
		return $output;
	}
	public function parseConExp($exp){
		#TODO parse
		#Let's see how I can finish this without using RegExp...
	}
	public function parseConStr2Unused($conStr, $names=array(), $data=array()){ // @"PEMapModder's take on RegExp"=="true"=>"just a mess":"quickly finish this plugin"
		if(preg_match_all("#(^@)@([@a-zA-Z0-9_!\"'=<>: ]{1,})#", $conStr, $matches)>0){
			$newStr=strstr($conStr, "@");
			foreach($matches[0] as $escape){
				$savedLits=array(); // array_shift()
				if(preg_match_all("#\"(.*)(^\\)\"#", $escape, $literals)>0){
					$newEsc=$escape;
					$noLit=strstr($newEsc, "\"", true);
					foreach($literals[1] as $literal){
						$savedLits[]=$this->parseConStr2Unused(str_replace("\\\"", "\"", $literal), $names, $data);
						$noLit.="\"";
						$noLit.=strstr($newEsc, "\"", true);
					}
				}
				if(preg_match_all("#@([@a-zA-Z0-9_])*(>|<|((!|=|<|>)=))(@([a-zA-Z0-9_])*|\")=>\":\"", $escape, $conditions)){ // Am I crazy...
					foreach($conditions[0] as $condition){
						$con=preg_split("#(>|<|((!|=|<|>)=))#", explode("=>", $condition, 2)[0]);
						$trueBlock=explode("=>", $condition)[1];
						$falseBlock=explode(":", $condition)[1];
						$conLeft=$con[0];
						$conRight=$con[1];
						// literals
						$tmpConl=$conLeft;
						$conLeft="";
						for($i=0; $i<strlen($tmpConl); $i++){
							if($tmpConl{$i}=="\"" and count($savedLits)>0)
								$conLeft.=array_shift($savedLits);
							else $conLeft.=$tmpConl{$i};
						}
						$tmpConl=$conRight;
						$conRight="";
						for($i=0; $i<strlen($tmpConl); $i++){
							if($tmpConl{$i}=="\"" and count($savedLits)>0)
								$conRight.=array_shift($savedLits);
							else $conRight.=$tmpConl{$i};
						}
						$tmpConl=$trueBlock;
						$trueBlock="";
						for($i=0; $i<strlen($tmpConl); $i++){
							if($tmpConl{$i}=="\"" and count($savedLits)>0)
								$trueBlock.=array_shift($savedLits);
							else $trueBlock.=$tmpConl{$i};
						}
						$tmpConl=$falseBlock;
						$falseBlock="";
						for($i=0; $i<strlen($tmpConl); $i++){
							if($tmpConl{$i}=="\"" and count($savedLits)>0)
								$falseBlock.=array_shift($savedLits);
							else $falseBlock.=$tmpConl{$i};
						}
						#conditions
						if($this->parseConStr2Unused($conLeft, $names, $data) == $this->parseConStr2Unused($conRight, $names, $data))
							$result=$this->parseConStr2Unused($trueBlock);
						else $result=$this->parseConStr2Unused($falseBlock);
					}
					$result="";#TODO
				}
				preg_match_all("#@([a-zA-Z0-9_]{1,})#", $escape, $nameAll);
				foreach($nameAll[0] as $name){
					if(($k=array_search(substr($name, 1), $names)))
						$newStr.=$data[$k];
				}
			}
		}
	}
	public function cmd($cmd, $args, $issuer){
		$cmd=array_shift($args);
		switch($cmd){
		case "cmd":
			if(count($args)<2 or !is_numeric($args[1]))
				return "Usage: /numrank cmd <cmd> <minimum permissiom index>";
			$this->perms->set($args[0], (int) $args[1]);
			$this->perms->save();
			return "Minimal permission index if /".$args[0]." set to ".$args[1];
		case "player":
			$usage="Usage: /numrank player <player> <permission>";
			if(!isset($args[0]))
				return $usage;
			if(!($p=$this->server->api->player->get($args[0])) instanceof Player)
				return "Player ".$args[0]." not found. $usage";
			if(!isset($args[1]))
				return "$p has permission ".(($perm=$this->getRankName($idx=$this->getPlyrPerm($p)))===false?"#$idx":"rank $perm");
			if(is_numeric($args[1])){
				$this->setPlyrPerm($p, (int)$args[1]);
				return "$p's permission index is set to ".$args[1];
			}
			if(($rk=$this->ranks->get($args[1]))!==false){
				$this->setPlyrPerm($p, $rk);
				return "$p's permission is set to ".$args[1]." (index $rk)";
			}
			else return "Rank ".$args[1]." not found. Use /numrank rank ".$args[1]." <permission index> to set a new permission";
		case "rank":
			if(!isset($args[0])){
				$all=$this->ranks->getAll();
				$max=4;
				foreach($all as $rank=>$i){
					$max=max(strlen($rank), $max);
				}
				$max++;
				$output="List of ranks\n";
				$output.="Rank";
				$output=$this->insertAfterStr(" ", $max-4, $output);
				$output.="| Permission index\n";
				foreach($all as $rank=>$index){
					$output.=$rank;
					$output=$this->insertAfterStr(" ", $max-strlen($rank), $output);
					$output.="| $index\n";
				}
				return $output;
			}
			if(is_numeric($args[0]))
				return "Rank names must not be numeric";
			if(!isset($args[1]))
				return "The permission index for rank ".$args[0]." is ".(($idx=$this->ranks->get($args[0]))===false?"undefined":$idx);
			if(!is_numeric($args[1]))
				return "Please give a numeric permission index.";
			$exist=$this->ranks->get($args[0]);
			$this->ranks->set($args[0], $args[1]);
			$this->ranks->save();
			if($exist!==false)
				return "Set the permission index of rank ".$args[0]." to ".$args[1];
			return "Added rank ".$args[0]." with permission index of ".$args[1];
		case "rmrank":
			$all=$this->ranks->getAll();
			if(!isset($all[$args[0]]))
				return "Rank ".$args[0]." does not exist!";
			unset($all[$args[0]]);
			$this->ranks->setAll($all);
			$this->ranks->save();
			if($this->ranks->get($args[0])===false)//debug
				return "Remove rank ".$args[0]." success!";
			return "Error while trying to remove rank ".$args[0]."!";
		case "help":
			$this->tell($issuer, "Showing help of command /numrank...");
		default:
			return "--Note: perm stands for permission--\n/numrank cmd <cmd> <min perm index> Set a command's minimal permission index\n/numrank player <player> <perm|perm index> Set a player's permission rank or permission index\n/numrank rank <rank> <index> Add/set a rank's permission index\n/numrank rmrank <rank> Remove a rank";
		}
	}
	public function tell($rcp, $msg){
		if(is_string($rcp))
			return console("[NumRank] $msg");
		if($rcp instanceof Player)
			return $rcp->sendChat("$msg");
		else return false;
	}
	public function insertAfterStr($repeater, $times, $string){//I don't have the courage to pass by reference
		while($times>0){
			$string.=$repeater;
			$times--;
		}
		return $string;
	}
}
