<?php

/*
 * __PocketMine Plugin__
 * name=TrollPro
 * description=Troll all your friends
 * version=1.0
 * author=Glitchmaster_PE
 * class=Troll
 * apiversion=10
 */

 class Troll implements Plugin{
     private $api;
     
     public function __construct(ServerAPI $api, $server = false){
         $this->api = $api;
     }
     
     public function init(){
         $this->api->console->register("troll","Troll someone. Usage: /troll <playername>", array($this, "troll"));
     }
     public function troll($cmd, $args, $issuer, $target){
         $target = $args[0];
         $username = $issuer->username;
         $this->api->console->run("tp ".$target." 20 300 20");
         $this->api->chat->sendTo(false, "You have been trolled by ".$username, $target);
         $this->api->chat->sendTo(false, "You have trolled ".$target, $username);
     }
     
     public function __destruct(){
         
     }
 }
?>