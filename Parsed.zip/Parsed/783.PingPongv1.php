<?php

/*
__PocketMine Plugin__
name=Ping Pong
description=Plugin made with PMMP Plugin Generator by SuperChipsLP
version=1.0
author=ikyogre1
class=1JtcNpeB
apiversion=10
*/

class 1JtcNpeB implements plugin{

private $api;

    public function __construct(ServerAPI $api, $server = false){

		$this->api = $api;

	}

	public function init(){

      $this->api->console->register("ping", "testcommand", array($this, "commandHandler"));
      $this->api->ban->cmdWhitelist("ping");

    }

    public function commandHandler($cmd, $params, $issuer, $alias){

    $output = "Pong";
    return $output;

    }

    public function __destruct(){

    }

}


