<?php

/*
__PocketMine Plugin__
name=No Void Death
description=Switches block with a similar type (flower to another flower)
version=1.0
author=Junyi00
class=NoVoidDeath
apiversion=10
*/

class NoVoidDath implements Plugin{
	private $api, $path, $config;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->api->addHandler("entity.health.change", array($this, "handler"));
	}
	
	public function __destruct() {}
	
	public function handler($data, $event) {
		if (!$data['entity']->class === ENTITY_PLAYER) {
			return true;
		}
		$player = $this->api->player->getByEID($data['entity']->eid);
		if ($player->entity->y <= -16) {
			return false;
		}
		else {
			return true;
		}
	}
	
}