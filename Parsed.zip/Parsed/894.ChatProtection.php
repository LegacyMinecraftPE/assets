<?php

/*
__PocketMine Plugin__
name=ChatProtection
version=0.1
author=Edited By:ShaderHD , Made by:Xfusionios
class=noobblocker
apiversion=10
*/

/*
^^ Versions ^^
* 1.0= initial release
*/
       
class ChatProtection implements Plugin{   
private $api; private $server;
public function __construct(ServerAPI $api, $server = false){
        $this->api = $api;
        $server = ServerAPI::request();
    }
   
    public function init(){ 
            $this->api->addHandler("player.chat", array($this, "eventHandler"), 100);
			console("[INFO] ChatProtection Started! ");
       
    }
    public function eventHandler($data, $event)
    {
        switch($event)
        {
            case "player.chat":
            $message = strtolower($data['message']);
                if(strpos($message,'Fuck') !== false) {
				$data['player']->sendChat("No Cursing!");
				return false;
				}
				 if(strpos($message,'Fuck You') !== false) {
				$data['player']->sendChat("No Cursing!");
				return false;
				}
				if(strpos($message, 'op me') !== false) {
				$data['player']->sendchat("DONT ASK FOR OP!");
				return false;
				}
				if(strpos($message, 'Im The Owner') !== false) {
				$data['player']->sendchat("Your Not The Owner");
				return false;
				}
				if(strpos($message, 'Give me diamonds') !== false) {
				$data['player']->sendchat("Go Mine Them Yourself");
				return false;
				}
				if(strpos($message, 'ass') !== false) {
				$data['player']->sendchat("No Cursing !");
				return false;
				}
				if(strpos($message, 'you bitch') !== false) {
				$data['player']->sendchat("No Cursing!");
				return false;
				}
				if(strpos($message, 'i hate this server!') !== false) {
				$data['player']->sendchat("Leave if u dont like it!");
				return false;
				}
				if(strpos($message, 'You Suck') !== false) {
				$data['player']->sendchat("You Suck MY Good Man!");
				return false;
				}
				if(strpos($message, 'Join my sevrer') !== false) {
				$data['player']->sendchat("Don't advertise here");
				return false;
				}
				if(strpos($message, 'Subscribe to my channel') !== false) {
				$data['player']->sendchat("Don't advertise here !");
				return false;
				}
				if(strpos($message, 'Im console') !== false) {
				$data['player']->sendchat("No Your not!");
				return false;
				}
				if(strpos($message, 'Give me') !== false) {
				$data['player']->sendchat("Get it your self");
				return false;
				}
				if(strpos($message, 'Damn') !== false) {
				$data['player']->sendchat("No cursing !");
				return false;
				}
				if(strpos($message, 'Ban Me') !== false) {
				$data['player']->sendchat("Fine!");
				return false;
				}
				if(strpos($message, 'Can i be admin ?') !== false) {
				$data['player']->sendchat("No Asking For Op !");
				return false;
				}
				if(strpos($message, ' OP ME' ) !== false) {
				$data['player']->sendchat("NO ASKING FOR OP!");
				return false;
				}
				if(strpos($message, ' How i build' ) !== false) {
				$data['player']->sendchat("Its survival !");
				return false;
				}
				if(strpos($message, ' Can i build spawn' ) !== false) {
				$data['player']->sendchat("NO !");
				return false;
				}
				if(strpos($message, ' Lets Grief' ) !== false) {
				$data['player']->sendchat("NO Griefing!");
				return false;
				}
				if(strpos($message, 'Im a griefer' ) !== false) {
				$data['player']->sendchat("NO Griefing !!!");
				return false;
				}
				else {
				return true;
				}
				
   

   break;
	
	}
}
public function __destruct(){
        }
    
}

    