<?php

/*
__PocketMine Plugin__
name=C4
description=Plant C4 and use it to blow things/people up!
version=1.0
author=DarkN3ss
class=C4
apiversion=10,11
*/

class C4 implements Plugin {
	private $api;
	
	public function __construct(ServerAPI $api, $server = false) {
		$this->api = $api;
	}
	
	public function init() {
		
		$this->api->console->register("plant", "Plants the C4 where player is standing." , array($this, "commandHandler"));
		$this->api->console->register("c4", "Detonated the planted C4." , array($this, "commandHandler"));
		$this->api->console->register("setblastsize", "<Size> Sets C4 blast size. Default size: 5" , array($this, "commandHandler"));
	}
	public function commandHandler($cmd, $params, $issuer, $alias)
	{
		if(!isset($this->pos[$issuer->username][4]))
		{
			$this->pos[$issuer->username][4] = (float) 5;
		}
		if($cmd === "c4")
		{
			if(isset($this->pos[$issuer->username][0]))
				{
					$e = new Explosion(new Position($this->pos[$issuer->username][0], $this->pos[$issuer->username][1], $this->pos[$issuer->username][2], $this->pos[$issuer->username][3]), $this->pos[$issuer->username][4]);
					$e->explode();
					$output ="C4 has exploded";
				}
				else
				{
					$output ="Please plant the C4 first";
				}
			return $output;
		}
		if($cmd === "plant")
		{
			$this->pos[$issuer->username][0] = ceil($issuer->entity->x);
			$this->pos[$issuer->username][1] = ceil($issuer->entity->y);
			$this->pos[$issuer->username][2] = ceil($issuer->entity->z);
			$this->pos[$issuer->username][3] = $issuer->level;
			$output ="C4 Planted at X: ".$this->pos[$issuer->username][0]." Y: ".$this->pos[$issuer->username][1]." Z: ".$this->pos[$issuer->username][2];
			return $output;
		}
		if($cmd === "setblastsize")
		{
			if(isset($params[0]))
			{
				$this->pos[$issuer->username][4] = (float) $params[0];
				$output ="C4 blast size set to: ".$this->pos[$issuer->username][4];
			}
			else
			{
				$output ="Please enter a blast size after the command.";
			}
			return $output;
		}
    }
	
	public function __destruct(){}
}
?>