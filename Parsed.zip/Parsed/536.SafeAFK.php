<?php

/*
__PocketMine Plugin__
name=Safe AFK
description=AFK safely, dont have to worry about dying while afking anymore!
version=0.1
author=Junyi00
class=SafeAFK
apiversion=10
*/

class SafeAFK implements Plugin{
	private $api, $path, $config;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->path = $this->api->plugin->configPath($this);
		$this->api->console->register("afk", "Enable Away from keyboard", array($this, "Control"));
		$this->api->console->register("afkoff", "Disable Away from keyboard", array($this, "Control"));
		$this->api->addHandler("entity.health.change", array($this, "healthchange"));
		$this->api->addHandler("player.move", array($this, "move"));
		$this->config = new Config($this->path."config.yml", CONFIG_YAML, array());
	}
	
	public function __destruct() {}
	
	public function Control($cmd, $arg, $issuer) {
		$ms = "";
		$name = $issuer->username;
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		switch($cmd) {
			case "afk":
				$x = $issuer->entity->x;
				$y = $issuer->entity->y;
				$z = $issuer->entity->z;
				if (!ARRAY_KEY_EXISTS("$name", $cfg)) {
					$new = array(
						"$name" => array(
							"afk" => true,
							"x" => $x,
							"y" => $y,
							"z" => $z
							));
					$this->overwriteConfig($new);
					$ms = "You are now in afk mode!";
					return $ms;
				}
				elseif ($cfg["$name"]["afk"] == true) {
					$ms = "You are already in afk mode!";
					return $ms;	
				}
				else {
					$change = array(
						"$name" => array(
							"afk" => true,
							"x" => $x,
							"y" => $y,
							"z" => $z
							));	
					$this->overwriteConfig($change);
					$ms = "You are now in afk mode!";
					return $ms;
				}
				break;
				
			case "afkoff":
				if (!ARRAY_KEY_EXISTS("$name", $cfg)) {
					$ms = "You are not in afk mode!";
					return $ms;
				}
				elseif ($cfg["$name"]["afk"] == false) {
					$ms = "You are not in afk mode!";
					return $ms;
				}
				else {
					$change = array(
						"$name" => array(
							"afk" => false
							));	
					$this->overwriteConfig($change);
					$ms = "You are now not in afk mode!\n";
					return $ms;
				}
		}
		return $ms;
	}
	
	public function move ($data, $event) {
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		$player = $this->api->player->getByEID($data->eid);
		$name = $player->username;
		
		if (ARRAY_KEY_EXISTS("$name", $cfg)) {
			if ($cfg["$name"]["afk"] == true) {
				$replace = array(
					"$name" => array(
						"afk" =>false
						));
				$this->overwriteConfig($replace);
				$player->sendChat("You are now not in afk mode!");
			}	
		}
	}
	
	public function healthchange($data, $event) {
		$player = $this->api->player->getByEID($data['entity']->eid);
		$name = $player->username;
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		
		if (!ARRAY_KEY_EXISTS("$name", $cfg)) {
			return true; //nvr afk b4
		}
		elseif ($cfg["$name"]["afk"] == false) {
			return true;
		}
		else {
			return false; //player is afking
		}
		
	}
	
	private function overwriteConfig($dat){
		$cfg = array();
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		$result = array_merge($cfg, $dat);
		$this->api->plugin->writeYAML($this->path."config.yml", $result);
	}
	
}