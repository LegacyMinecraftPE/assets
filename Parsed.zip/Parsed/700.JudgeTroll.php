<?php

/*
__PocketMine Plugin__
name=JudgeTroll
version=0.2
author=Junyi00
class=JudgeTroll
apiversion=10
*/

class JudgeTroll implements Plugin{
	private $api, $path;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->path = $this->api->plugin->configPath($this); 
		$this->config = new Config($this->path."config.yml", CONFIG_YAML, array());
		$this->api->console->register("judge", "As an admin or owner, punish the trollers/griefers or bad players", array($this, "Judge"));
		$this->api->console->alias("troll", "judge");
	}
	
	public function __destruct() {}
	
	private function fall($player) {
		$y = $player->entity->y + 40;
		$player->teleport(new Vector3($player->entity->x, $y, $player->entity->z));
	}
	
	private function death($player) {
		$player->setHealth(0, "none");
	}
	
	private function lowHP($player) {
		$player->setHealth(1, "none");	
	}
	
	private function terror($player) {
		$y = $player->entity->y + 40;
		$level = $palyer->level;
		$level->setBlock(new Vector3($player->entity->x, $y, $player->entity->z), BlockAPI::get(20,0));
		$player->teleport(new Vector3($player->entity->x, $y+1, $player->entity->z)); 
		
	}
	
	private function trap($player) {
		$level = $player->level;
		$x = $player->entity->x;
		$y = $player->entity->y;
		$z = $player->entity->z;
		
		$stone = BlockAPI::get(98,0);
		$glass = BlockAPI::get(20,0);
		
		$level->setBlock(new Vector3($x+1, $y, $z, $level), $stone);
		$level->setBlock(new Vector3($x+1, $y+1, $z, $level), $glass);
		
		$level->setBlock(new Vector3($x-1, $y, $z, $level), $stone);
		$level->setBlock(new Vector3($x-1, $y+1, $z, $level), $glass);
		
		$level->setBlock(new Vector3($x, $y, $z+1, $level), $stone);
		$level->setBlock(new Vector3($x, $y+1, $z+1, $level), $glass);
		
		$level->setBlock(new Vector3($x, $y, $z-1, $level), $stone);
		$level->setBlock(new Vector3($x, $y+1, $z-1, $level), $glass);
		
		$level->setBlock(new Vector3($x, $y+2, $z, $level), $stone);
		$level->setBlock(new Vector3($x, $y-1, $z, $level), $stone);
		
		$player->teleport(new Vector3($x, $y, $z));
	}
	
	private function cobwebs($player) {
		$level = $player->level;
		$x = $player->entity->x;
		$y = $player->entity->y;
		$z = $player->entity->z;
		
		$cobweb = BlockAPI::get(30,0);
		
		$level->setBlock(new Vector3($x, $y, $z, $level), $cobweb);
		$level->setBlock(new Vector3($x, $y+1, $z, $level), $cobweb);
		$level->setBlock(new Vector3($x, $y+2, $z, $level), $cobweb);
		
		$level->setBlock(new Vector3($x+1, $y, $z, $level), $cobweb);
		$level->setBlock(new Vector3($x+1, $y+1, $z, $level), $cobweb);
		$level->setBlock(new Vector3($x+1, $y+2, $z, $level), $cobweb);
		
		$level->setBlock(new Vector3($x-1, $y, $z, $level), $cobweb);
		$level->setBlock(new Vector3($x-1, $y+1, $z, $level), $cobweb);
		$level->setBlock(new Vector3($x-1, $y+2, $z, $level), $cobweb);
		
		$level->setBlock(new Vector3($x, $y, $z+1, $level), $cobweb);
		$level->setBlock(new Vector3($x, $y+1, $z+1, $level), $cobweb);
		$level->setBlock(new Vector3($x, $y+2, $z+1, $level), $cobweb);
		
		$level->setBlock(new Vector3($x, $y, $z+-1, $level), $cobweb);
		$level->setBlock(new Vector3($x, $y+1, $z-1, $level), $cobweb);
		$level->setBlock(new Vector3($x, $y+2, $z-1, $level), $cobweb);
	}
	
	private function explodePlayer($player, $power) {
		$e = new Explosion(new Position($player->entity->x, $player->entity->y + 0.5, $player->entity->z, $player->level), $power);
		$e->explode();
	}
	
	private function burn($player, $dmg) {
		$fire = $dmg *20;
		$player->entity->fire($fire);
	}
	
	private function dropInven($player) {
		$player->entity->spawnDrops();
		$player->entity->updateMetadata();
	}
	
	public function Judge($cmd, $arg, $issuer) {
		$ms = "";
		switch($cmd) {
			case "judge":
				if (!($issuer instanceof Player)) {
					$ms = "Please run this command in-game";
					return $ms;
				}
			
				$target = $arg[0];
				$type = $arg[1];
				
				if (!$this->api->player->get($target)) {
					$ms = "$target is not online";
					return $ms;
				}
				$player = $this->api->player->get($target);
				
				$player->sendChat("Time for you to get punished!");
				
				switch($type) {
					case "explode":
						$power = 4;
						if (isset($arg[2])) {
							$power = (float) $arg[2];
						}
						$this->explodePlayer($player, $power);
						break;
					case "trap": $this->trap($player);
					case "fall": $this->fall($player);
					case "death": $this->death($player);
					case "lowHP": $this->lowHP($player);
					case "terror": $this->terror($player);
					case "cobwebs": $this->cobwebs($player);
					case "burn": 
						$dmg = 4;
						if (isset($arg[2])) {
							$power = (int) $arg[2];
						}
						$this->explodePlayer($player, $dmg);
						break;
					case "dropInven": $this->dropInven($player);
					
					$ms = "$target has been punished/trolled!";
					
				}
				
		}
		return $ms;
	}
	
	private function overwriteConfig($dat){
		$cfg = array();
		$cfg = $this->api->plugin->readYAML($this->path . "config.yml");
		$result = array_merge($cfg, $dat);
		$this->api->plugin->writeYAML($this->path."config.yml", $result);
	}
	
}