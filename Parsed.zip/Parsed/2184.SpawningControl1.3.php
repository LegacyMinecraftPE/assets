<?php

/*
 __PocketMine Plugin__
name=SpawningControl
description=
version=1.3
author=RapDoodle
class=SpawningControl
apiversion=13
*/

class SpawningControl implements Plugin{ 
	private $api;
	
	public function __construct(ServerAPI $api, $server =false){ 
		$this->api = $api;
		$this->server = ServerAPI::request();
	}
	
	public function init(){
		$this->api->addHandler("entity.health.change", array($this, "eventHandler"), 50);
		$this->api->console->register('sc', '<world>', array($this, 'command'));
		$this->api->console->register('wspawn', 'Back to the spawn in the target world.', array($this, 'command'));
		$this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array("world-list" => array(),"every-level" => false));
	}
	
	public function eventHandler($data){
		$player = $data["entity"]->player;
		if($player === false){
			//No event or an none-object
		}else{
			$hp = $data["health"];
			if($hp <= 0){
				$player = $data["entity"]->player;
				$player->entity->setHealth(20, "respawn", true);
				$world = $player->level->getName();
				if(in_array($world, $this->config->get("world-list")) or ($this->config->get("every-level") === true)){
					$player->teleport($this->api->level->get($world)->getSpawn());
				}else{
					$player->teleport($this->server->spawn);
				}
				$ms = "<server> ".$player." just respawn from dead.";
				$this->api->chat->broadcast($ms);
				return false;
			}
		}
	}
	
	public function command($cmd, $args, $issuer, $alias){
		switch($cmd){
			case "wspawn":
				if($issuer === "console"){
					console("<SpawningControl> Please run this command in game.");
				}else{
					$world = $issuer->level->getName();
					$issuer->teleport($this->api->level->get($world)->getSafeSpawn());
				}
				break;
			case "sc":
				$subCommand = strtolower($args[0]);
				$worldname = $args[1];
				switch($subCommand){
					case "add":
						if(in_array($worldname, $this->config->get("world-list"))){
							$output = "<SpawningControl> ".$worldname." already in the list.";
						}else{
							$info = $this->config->get("world-list");
						$info[] = $worldname;
						$this->config->set("world-list", $info);
						$this->config->save();
						$output = "<SpawningControl> ".$worldname." has added to the list";
						}
						break;
					case "remove":
						$worldname = $args[1];
						if(in_array($worldname, $this->config->get("world-list"))){
							$info = $this->config->get("world-list");
							$key = array_search($worldname, $info);
							unset($info[$key]);
							$this->config->set("world-list", $info);
							$this->config->save();
							$output = "<SpawningControl> ".$worldname." has removed from the list.";
						}else{
							$output = "<SpawningControl> ".$worldname." wasn't in the list.";
						}
						break;
					case "all":
						if($this->config->get("every-level") === false){
							$this->config->set("every-level", true);
							$output = "<SpawningControl> Every level mode has turned on.";
							$this->config->save();
						}else{
							$this->config->set("every-level", false);
							$output = "<SpawningControl> Every level mode has turned off.";
							$this->config->save();
						}
						break;
					}
				break;
		}
		return $output;
	}
	
	public function __destruct(){
		
	}
}