<?php

/*
__PocketMine Plugin__
name=BanHammer
description=The BanHammer Has Spoken!
version=1.6.8
author=Comedyman937
class=BanHammer
apiversion=11,12,13
*/

/*
===============
   Changelog
===============

1.6.8
- Security Improvements
- New Config Option For TimerBan Support ("TimerBanTime")
- Better Config Updating With Commands (Hopefully)
- Added BanHammerTime Command
- Added Alias For BanHammerTime Command
- TimerBan Compatibility (Please Report Issues As There May Be Bugs)
- Small Bug Fixes (Most Were Rare)
- Better Code Organization (For Future Updates)

1.4.0
- Added kick command support

1.0.0
- Initial Release

===============
 End Changelog
===============
*/

class BanHammer implements Plugin
{
    private $api;

    public function __construct(ServerAPI $api, $server = false)
    {
        $this->api = $api;
    }

    public function init()
    {
        if(!file_exists($this->api->plugin->configPath($this) . "config.yml"))
        {
            $this->CONFIG = new Config($this->api->plugin->configPath($this) . "config.yml", CONFIG_YAML, array(
                "BanHammer" => '286',
                "BanType" => 'ban',
                "TimerBanTime" => '6',
            ));
        }

        $this->CONFIG = $this->api->plugin->readYAML($this->api->plugin->configPath($this) . "config.yml");

        $this->api->console->register("banhammer", "Get the BanHammer!", array($this, "CommandHandler"));
        $this->api->console->register("banhammeritem", "Change the BanHammer Item!", array($this, "Item"));
        $this->api->console->register("banhammertype", "Change the BanHammer Type!", array($this, "Type"));
        $this->api->console->register("banhammertime", "Change the BanHammer TimerBan Time!", array($this, "Time"));

        $this->api->addHandler("player.equipment.change", array($this, "EventHandler"));
        $this->api->addHandler("player.interact", array($this, "EventHandler"));

        $this->api->console->alias("bhtime","banhammertime");
        $this->api->console->alias("bht","banhammertype");
        $this->api->console->alias("bhi","banhammeritem");
        $this->api->console->alias("bh","banhammer");

        if($this->CONFIG["BanHammer"] <= 0 || $this->CONFIG["BanHammer"] > 500){
                    console("[ERROR] BanHammer did not start as the item set in its config.yml is not compatible!");
                        }elseif(!($this->api->block->getItem($this->CONFIG["BanHammer"]) instanceof Item)){
                            console("[ERROR] BanHammer will NOT work as the item set in its config.yml is not compatible!");
                                }else{

                                    console("[INFO] BanHammer Loaded!");
        }
    }

    public function CommandHandler($cmd, $params, $issuer, $alias)
    {
        switch(strtolower($cmd))
        {
            case "banhammer":
                if(!($issuer instanceof Player)){
                     return "[ERROR] [BanHammer] Please run this command in-game!";
                         }elseif($this->CONFIG["BanHammer"] <= 0 || $this->CONFIG["BanHammer"] > 500){
                             return "[BanHammer] An invalid item is set in the config.yml\nBanHammer will not work until this has been fixed!";
                                 }elseif(!($this->api->block->getItem($this->CONFIG["BanHammer"]) instanceof Item)){
                                     return "[BanHammer] An invalid item is set in the config.yml\nBanHammer will not work until this has been fixed!";
                                         }else{
                                             $this->api->console->run("give " . $issuer->username . " " . $this->CONFIG["BanHammer"] . " 1", "console", false);

                                             return "[BanHammer] The BanHammer has been added to your inventory!\nInteract with a player to ban/kick them!";
                }
                break;
          }
     }

     public function Item($cmd, $params, $issuer, $alias)
     {
        switch(strtolower($cmd))
        {
            case "banhammeritem":

                if(count($params) > 2){
                    return "Usage: /banhammeritem <ITEM ID>";
                        }if($params[0] <= 0 || $params[0] > 500){
                            return "[BanHammer] Invalid Item ID!";
                                }if(!($this->api->block->getItem($params[0]) instanceof Item)){
                                    return "[BanHammer] Blocks Can NOT Be Used As A BanHammer!";
                                        }if(isset($this->CONFIG["BanHammer"])){
                                            $this->CONFIG["BanHammer"] = $params[0];
                                        }
                                            $this->api->plugin->writeYAML($this->api->plugin->configPath($this) . "config.yml", $this->CONFIG);
                                            $this->CONFIG = $this->api->plugin->readYAML($this->api->plugin->configPath($this) . "config.yml");

                                            return "[BanHammer] The BanHammer Item has been changed!";
                break;
          }
     }

     public function Type($cmd, $params, $issuer, $alias)
     {
        switch(strtolower($cmd))
        {
            case "banhammertype":

                if(count($params) > 2){
                    return "Usage: /banhammertype <BAN|BANIP|KICK|TIMERBAN|TIMERBANIP>";
                }if($params[0] == "ban" || $params[0] == "banip" || $params[0] == "kick" || $params[0] == "timerban" || $params[0] == "timerbanip"){
                     if(isset($this->CONFIG["BanType"])){
                          $this->CONFIG["BanType"] = $params[0];
                     }
                         }else{
                             return "Usage: /banhammertype <BAN|BANIP|KICK|TIMERBAN|TIMERBANIP>";
                         }
                             $this->api->plugin->writeYAML($this->api->plugin->configPath($this) . "config.yml", $this->CONFIG);
                             $this->CONFIG = $this->api->plugin->readYAML($this->api->plugin->configPath($this) . "config.yml");

                             return "[BanHammer] The BanHammer Type has been changed!";
                break;
        }
    }

     public function Time($cmd, $params, $issuer, $alias)
     {
        switch(strtolower($cmd))
        {
            case "banhammertime":

                if(count($params) > 2){
                    return "Usage: /banhammertime <HOURS>";
                        }if(isset($this->CONFIG["TimerBanTime"])){
                            if($params[0] >= 0.01){
                                $this->CONFIG["TimerBanTime"] = $params[0];
                                     }else{
                                         return "[BanHammer] The TimerBan Time MUST be greater than 0.01 Hours!";
                                     }
                                         }else{
                                             return "Usage: /banhammertime <HOURS>";
                                     }
                                         $this->api->plugin->writeYAML($this->api->plugin->configPath($this) . "config.yml", $this->CONFIG);
                                         $this->CONFIG = $this->api->plugin->readYAML($this->api->plugin->configPath($this) . "config.yml");

                                         return "[BanHammer] The BanHammer TimerBan Time has been changed!\nNOTE: This will only be used if the BanType is set to \"timerban\" or \"timerbanip\" in the Config.yml file!";
                break;
        }
    }

    public function EventHandler($data, $event)
    {
        switch($event)
        {
            case "player.equipment.change":

                if($data["item"]->getID() == $this->CONFIG["BanHammer"]){
                    $this->TEMP[$data["player"]->username] = true;
                        }else{
                            $this->TEMP[$data["player"]->username] = false;
                        }
                break;

            case "player.interact":

                if($this->api->ban->isOP($data["entity"]->player->username)){
                    if(isset($this->TEMP[$data["entity"]->player->username]) and $this->TEMP[$data["entity"]->player->username] == true){                
                        if($this->CONFIG["BanType"] == "ban" || $this->CONFIG["BanType"] == "banip"){
                            $this->api->console->run($this->CONFIG["BanType"] . " add " . $data["targetentity"]->player->username);
                      
                            $this->api->chat->broadcast("[BanHammer] The BanHammer has spoken against " . $data["targetentity"]->player->username . "!");
                                }elseif($this->CONFIG["BanType"] == "timerban"){

                                    $this->api->console->run($this->CONFIG["BanType"] . " add " . $data["targetentity"]->player->username . " " . $this->CONFIG["TimerBanTime"]);

                                    $this->api->chat->broadcast("[BanHammer] The BanHammer has spoken against " . $data["targetentity"]->player->username . "!");
                                        }elseif($this->CONFIG["BanType"] == "timerbanip"){

                                            $this->api->console->run($this->CONFIG["BanType"] . " add " . $data["targetentity"]->player->ip . " " . $this->CONFIG["TimerBanTime"]);

                                            $this->api->chat->broadcast("[BanHammer] The BanHammer has spoken against " . $data["targetentity"]->player->username . "!");
                                                }elseif($this->CONFIG["BanType"] == "kick"){

                                                    $this->api->console->run($this->CONFIG["BanType"] . " " . $data["targetentity"]->player->username . " The BanHammer Has Spoken!");

                                                    $this->api->chat->broadcast("[BanHammer] The BanHammer has spoken against " . $data["targetentity"]->player->username . "!");
                                                        }else{
                                                            $this->api->chat->broadcast("[BanHammer] The BanHammer could not speak as it does not know how to use its set BanType!");
                                                        }
                        break;
                    }
                }
                break;
        }
    }

    public function __destruct()
    {
        console("[INFO] BanHammer Unloaded!");
    }
}

?>