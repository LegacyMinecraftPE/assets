<?php

/*
__PocketMine Plugin__
name=GeoLocation
description=
version=2.0
author=DarkN3ss
class=GeoLocation
apiversion=10, 11, 12
*/

class GeoLocation implements Plugin{
   private $api;

   public function __construct(ServerAPI $api, $server = false){
     $this->api = $api;
   }

   public function init(){
		$this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array('WelcomeMessage' => true));
		define("WelcomeMessage", $this->config->get('WelcomeMessage'));
		
		$this->api->console->register("gl", "<Player>", array($this, "cmdHandler"));
		$this->api->addHandler("player.spawn", array($this, "eventHandler"), 50);
   }
   
   public function cmdHandler($cmd, $params, $issuer, $alias)
	{
		$user["issuer"] = strtolower($issuer->username);
		$user["target"] = strtolower($params[0]);
		switch($cmd) {
			case "gl":
				if(!$this->api->player->get($user['target']) instanceof Player)       
				{ 
				return "Invalid Player Name"; 
				}
				else
				{
					$playerIP = $this->api->player->get($user['target'])->ip;
					if(!filter_var($data->ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE) )
					{
						// $result = file_get_contents("http://api.hostip.info/get_json.php?ip=");
						$result = $this->asyncOperation("http://ip-api.com/json/");
					}
					else
					{
						// $result = file_get_contents("http://api.hostip.info/get_json.php?ip=" . $playerIP);
						$result = $this->asyncOperation("http://ip-api.com/json/" . $data->ip);
					}
					$country = json_decode($result, 1)['country'];
					return ($user['target'] . " with the ip: " . $playerIP . " comes from " . ucwords(strtolower($country)));
				}
				break;
		}
		return;
	}
	
	public function eventHandler($data, $event){
   
		switch($event){
			case "player.spawn":
				if(WelcomeMessage)
				{
					if(!($data instanceof Player)){
						break;
					}
					   if ( ! filter_var($data->ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE) )
					{
						$result = $this->asyncOperation("http://ip-api.com/json/");
					}
					else
					{
						$result = $this->asyncOperation("http://ip-api.com/json/" . $data->ip);
					}
					
					$country = json_decode($result, 1)['country'];
					$this->api->chat->broadcast($data->username . " from " . ucwords(strtolower($country)) . " just joined the game.");
					break;
				}
		}
		return;
	}
	
	public function asyncOperation($url){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HEADER, false);
		$data = curl_exec($curl);
		curl_close($curl);
		return $data;
	}
   
	public function __destruct(){
	}
}
?>