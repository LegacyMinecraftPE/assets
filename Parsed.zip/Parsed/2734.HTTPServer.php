<?php
/*
__PocketMine Plugin__
name=HTTPServer
description=Quickly setup an HTTP server.
version=0.2.1
author=Falk
class=HTTPServer
apiversion=11,12,13
*/
class HTTPServer implements Plugin{
  private $api;

  public function __construct(ServerAPI $api, $server = false){
    $this->api = $api;
  }
    public function __destruct(){
    console("[INFO] [HTTPServer] Stopping server...");
    $this->server->stop();
  }
  public function init(){
  	if(!is_dir(FILE_PATH . "HTTPServer")) mkdir(FILE_PATH . "HTTPServer");
    console("[INFO] [HTTPServer] Starting HTTP server...");
    $this->vars = new Arr();
    $this->server = new Server($this->vars);
    if ($this->server->stop === false) console("[SUCCESS] HTTP Server Status: " . FORMAT_GREEN . "Active");
 	  else console("[WARNING] HTTP Server Status: " . FORMAT_RED . "Failed");
 	  $this->api->addHandler("httpserver.update", array($this,"addValue"),50);
    }
    public function addValue($data){
      $this->vars[$data[0]] = $data[1];
    }
  }
  class Arr extends Stackable{
   public function __construct() {}
  public function run(){}
}
class Server extends Thread {
  public $stop;
  private $sock;
  public $vars;
  public function __construct(Arr $vars) {
    $this->stop = false;
    $this->vars = $vars;
    $this->sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
    if(socket_bind($this->sock, "0.0.0.0", 8080) === false) $this->stop = true;
    if(socket_listen($this->sock, 5) === false) $this->stop = true;
    $this->start();
  }
  public function stop() {
    $this->stop = true;
  }
  public function run() {
    while ($this->stop === false) {
  $con = socket_accept($this->sock);
  $page = trim(socket_read($con, 2048, PHP_NORMAL_READ));
  $page = substr($page,strpos($page, " ")+1);
  $page = substr($page, 0,strpos($page, " "));
  $page = parse_url("http://e.co" . $page,PHP_URL_PATH); //Parse url won't work on relative URLs
  $page = str_replace("/.", "", str_replace("/..", "", $page));
  if($page == "/") $page = "/index.html";
  if(!is_file(FILE_PATH . "HTTPServer" . $page)) socket_write($con, "File not found.");
  elseif (substr($page, -4) == "html") socket_write($con, $this->replace(file_get_contents(FILE_PATH . "HTTPServer" . $page)));
  else socket_write($con, file_get_contents(FILE_PATH . "HTTPServer" . $page));
  socket_close($con);
    }
    socket_close($this->sock);
    exit(0);
  }
  public function replace($data){
    preg_match_all('/{{(.*?)}}/', $data, $items);
    $items = $items[1];
    foreach ($items as $i) {
    	if(isset($this->vars[$i])) $data = str_replace("{{" . $i . "}}", $this->vars[$i], $data);
    	else console("[HTTPServer] Failed to find variable: " . $i);
    }
    return $data;
  }
}
