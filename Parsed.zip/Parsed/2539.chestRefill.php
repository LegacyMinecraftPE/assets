<?php
/*
__PocketMine Plugin__
name=ChestRefill
description=Painless chest refilling
version=0.1
author=Falk
class=chestRefill
apiversion=10,11,12,13
*/
class chestRefill implements Plugin{
private $api, $path;
public function __construct(ServerAPI $api, $server = false){
$this->api = $api;
}

public function init(){

$this->api->addHandler("player.block.touch", array($this,"eventHandle"),50);
$this->api->console->register("refill", "Turn on or off chest refill", array($this, "command"));
$this->select = array();
$interval = 5; //Amount of minutes between chest resets
$this->config = new Config($this->api->plugin->configPath($this)."chests.yml", CONFIG_YAML, array());
$this->api->schedule($interval*20*60,array($this,"refillChests"),$interval*20*60,true,"server.schedule");
}

public function __destruct(){}
public function command($cmd, $params, $issuer, $alias, $args, $issuer){
if($issuer != "console"){
$this->select[$issuer->username] = true;
return "[ChestRefill] Touch a chest to refresh refill";
}
return "Please run this command in game.";
}
public function eventHandle($data, $event) {
if(isset($this->select[$data["player"]->username])){
if($data["target"]->getID() == 54){
$data["player"]->sendChat("[ChestRefill] Chest contents captured");
$tile = $this->api->tile->get(new Position($data['target']->x, $data['target']->y, $data['target']->z, $data['target']->level));
$new = array();
for($i = 0; $i < 27; $i++){
	$new[] = array($tile->getSlot($i)->getID(),$tile->getSlot($i)->count,$tile->getSlot($i)->getMetadata());
}
$cfg = $this->api->plugin->readYAML($this->api->plugin->configPath($this). "chests.yml");
$cfg[$data["target"]->x . ":" . $data["target"]->y . ":" . $data["target"]->z . ":" . $data["target"]->level->getName()] = $new;
$this->api->plugin->writeYAML($this->api->plugin->configPath($this)."chests.yml", $cfg);
unset($this->select[$data["player"]->username]);
}
else $data["player"]->sendChat("[ChestRefill] You need to tap a chest.");
}
}
public function refillChests(){
$cfg = $this->api->plugin->readYAML($this->api->plugin->configPath($this). "chests.yml");
foreach ($cfg as $c => $slots) {
	$c = explode(":", $c);
	$tile = $this->api->tile->get(new Position($c[0],$c[1],$c[2],$this->api->level->get($c[3])));
	if($tile == false) continue;
	if($tile->class != TILE_CHEST) continue;
	foreach ($slots as $key => $slot) {
		$item = $this->api->block->getItem($slot[0], $slot[2], $slot[1]);
		$tile->setSlot($key,$item);
	}
}
$this->api->chat->broadcast("[ChestRefill] Chests have been reset!");
}
}

