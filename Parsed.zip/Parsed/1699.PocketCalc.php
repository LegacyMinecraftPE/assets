<?php

/*
__PocketMine Plugin__
name=PocketCalc
description=Does math. (Just basic like + - / and *)
version=0.0.1
author=I_Is_Payton_
class=Math
apiversion=10,11,12,13,14,15,16,17,18,19,20
*/


class Math implements Plugin {
        private $api, $path, $config;
        public function __construct(ServerAPI $api, $server = false){
                $this->api = $api;
        }
        
        public function init(){
                $this->api->console->register("add", "Addition", array($this, "add"));
                $this->api->console->register("subtract", "Subtraction", array($this, "subtract"));
                $this->api->console->register("multiply", "Multiplication", array($this, "multiply"));
                $this->api->console->register("divide", "Division", array($this, "divide"));

                $this->api->ban->cmdWhitelist("add", "Addition", array($this, "add"));
                $this->api->ban->cmdWhitelist("subtract", "Subtraction", array($this, "subtract"));
                $this->api->ban->cmdWhitelist("multiply", "Multiplication", array($this, "multiply"));
                $this->api->ban->cmdWhitelist("divide", "Division", array($this, "divide"));
        }
        
        public function add($cmd, $arg, $issuer) {
          $user = $issuer->username;
        	             $numone = $arg[0];
                       $operation = $arg[1];
                       $numtwo = $arg[2];
                        
                         if (empty($arg[0]) || empty($arg[2])) {
                                 if($issuer instanceof Player) {
                                 $this->api->chat->sendTo(false, "[PCalc] Usage: /add <number one> <number two>", $issuer);
                                 }else{
                                  $aempty = ("[PCalc] Usage: /add <number one> <number two>");
                                  return $aempty;
                                 }
                         }
                                 
                         elseif(!is_numeric($numone) || !is_numeric($numtwo)) {
                         if($issuer instanceof Player) {
                                  $this->api->chat->sendTo(false, "[PCalc] Usage: /add <number one> <number two>", $issuer);
                         }else{
                                  $ausage = ("[PCalc] Usage: /add <number one> <number two>");
                                  return $ausage;
                         }        
                                 
                         }else{
                                          switch ($operation) {
                                            case '+':
                                          $result = $numone + $numtwo;
                                          if($issuer instanceof Player) {
                                             $this->api->chat->sendTo(false, "$numone + $numtwo equals $result", $issuer);
                                          }else{
                                                  $addition = ("$numone + $numtwo equals $result");
                                                  return $addition;
                                                  break;
                                                }
                                                }
                                              }
                                            }
                                          
                      public function subtract($cmd, $arg, $issuer) {
                                 $user = $issuer->username;
        	                       if (empty($arg[0]) || empty($arg[2])) {
                                 if($issuer instanceof Player) {
                                 $this->api->chat->sendTo("[PCalc] Usage: /subtract <number one> <number two>");
                                 }else{
                                  $sempty = ("[PCalc] Usage: /subtract <number one> <number two>");
                                  return $sempty;
                                 }
                               }
                                 
                         elseif(!is_numeric($numone) || !is_numeric($numtwo)){
                         if($issuer instanceof Player) {
                        $this->api->chat->sendTo(false, "[PCalc] Usage: /subtract <number one> <number two>", $issuer);
                         }else{
                              $susage = ("[PCalc] Usage: /subtract <number one> <number two>");
                              return $susage;
                         }           
                         }else{
                                          switch($operation){
                                            case '-':
                                          $result = $numone - $numtwo;
                                          if($issuer instanceof Player) {
                                             $this->api->chat->sendTo(false, "$numone - $numtwo equals $result", $issuer);
                                          }else{
                                                  $subtract = ("$numone - $numtwo equals $result");
                                                  return $subtract;
                                                  break;
                                                }
        }
      }
    }
                public function multiply($cmd, $arg, $issuer) {
                                 $user = $issuer->username;
        	                       if (empty($arg[0]) || empty($arg[2])) {
                                 if($issuer instanceof Player) {
                                 $this->api->chat->sendTo("[PCalc] Usage: /multiply <number one> <number two>");
                                 }else{
                                  $mempty = ("[PCalc] Usage: /multiply <number one> <number two>");
                                  return $mempty;
                                 }
                               }
                                 
                         elseif(!is_numeric($numone) || !is_numeric($numtwo)){
                         if($issuer instanceof Player) {
                                  $this->api->chat->sendTo(false, "[PCalc] Usage: /multiply <number one> <number two>", $issuer);
                         }else{
                                  $musage = ("[PCalc] Usage: /multiply <number one> <number two>");
                                  return $musage;
                                  }       
                         }else{
                                          switch($operation){
                                            case '*':
                                          $result = $numone * $numtwo;
                                          if($issuer instanceof Player) {
                                             $this->api->chat->sendTo(false, "$numone * $numtwo equals $result", $issuer);
                                          }else{
                                                  $multiply = ("$numone * $numtwo equals $result");
                                                  return $multiply;
                                                  break;
                                                }
        }
      }
    }
                        public function divide($cmd, $arg, $issuer) {
                          $user = $issuer->username;
        	                     if (empty($arg[0]) || empty($arg[2])) {
                                 if($issuer instanceof Player){
                                 $this->api->chat->sendTo("[PCalc] Usage: /divide <number one> <number two>");
                                 }else{
                                  $dempty = ("[PCalc] Usage: /divide <number one> <number two>");
                                  return $dempty;
                                 }
                               }
                                 
                         elseif(!is_numeric($numone) || !is_numeric($numtwo)){
                         if($issuer instanceof Player) {
                                  $this->api->chat->sendTo(false, "[PCalc] Usage: /divide <number one> <number two>", $issuer);
                         }else{
                                  $dusage = ("[PCalc] Usage: /divide <number one> <number two>");
                                  return $dusage;
                         }        
                                 
                         }else{
                                          switch($operation){
                                            case '/':
                                          $result = $numone / $numtwo;
                                          if($issuer instanceof Player) {
                                             $this->api->chat->sendTo(false, "$numone / $numtwo equals $result", $issuer);
                                          }else{
                                                  $divide = "$numone / $numtwo equals $result";
                                                  return $divide;
                                                  break;
                                                }
                                                  }
                                                }
                                              }
			public function __destruct(){}
    }

    ?>