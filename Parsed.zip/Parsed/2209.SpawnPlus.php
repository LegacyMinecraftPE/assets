<?php
 
/*
__PocketMine Plugin__
name=Spawn+
description=Set spawn in world
version=1.0
author=Topic
class=SpawnPlus
apiversion=9,10,11,12
*/

class SetSpawn implements Plugin{	
	private $api;

	public function __construct(ServerAPI $api, $server = false){
        $this->api = $api;
        $this->server = ServerAPI::request();
    }
    public function init(){
		$this->api->console->register("setspawn", "Set Spawn of world", array($this, "commandHandler"));
		$this->api->console->register("spawn", "Teleport to spawn", array($this, "commandHandler"));
		$this->api->ban->cmdwhitelist("spawn");
		console("[INFO] Spawn+ enabled");
    }
	public function __destruct() {}

    public function commandHandler($cmd, $arg, $issuer){
    	switch($cmd){
      		case "setspawn":
			     if(!($issuer instanceof Player)){
					console("[Spawn+]: Run command in game");
					break;
				}
				$position = new Vector3($issuer->entity->x, $issuer->entity->y, $issuer->entity->z);
				$level = $issuer->level->getName();
				$this->api->level->get($level)->setSpawn($position);
				$issuer->sendChat("[Spawn+]: Spawn set in world: ".$level);
        	break;
        	case "spawn":
        		$level = $issuer->level->getName();
        		$spawn = $this->api->level->get($level)->getSpawn();
        		$issuer->teleport($spawn);
        		$issuer->sendChat("[Spawn]: You teleported to spawn on ".$level);
        	break;
        }
      }
}