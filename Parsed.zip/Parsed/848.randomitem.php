<?php

/*
__PocketMine Plugin__
name=RandomItem
description=Gives a random item on command and at set intervals.
version=0.1.2
author=LDX
class=RandomItem
apiversion=10
*/

class RandomItem implements Plugin {
private $api;
public function __construct(ServerAPI $api, $server = false) {
$this->api = $api;
}

public function init() {
$this->api->console->register("gift", "Gives a random item.", array($this, "giveRI"));
$this->api->schedule(12000,array($this,'giveRI'),array(),true,'server.schedule');
console("[INFO] RandomItem Enabled!");
}

public function __destruct(){}

public function giveRI() {
$randomItemNumber = rand(1,5);
if($randomItemNumber == 1) {
$randItem = "360";
} else if($randomItemNumber == 2) {
$randItem = "267";
} else if($randomItemNumber == 3) {
$randItem = "265";
} else if($randomItemNumber == 4) {
$randItem = "354";
} else if($randomItemNumber == 5) {
$randItem = "6";
}
$this->api->console->run("give @all " . $randItem . " 1");
$this->api->chat->broadcast("[RandomItem] Random item given!");
}
}
?>