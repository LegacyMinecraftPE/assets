<?php

/*
__PocketMine Plugin__
class=OpSudoPlugin
name=OpSudo
author=PEMapModder
version=1
apiversion=12
*/

class OpSudoPlugin implements Plugin{
  private $allow=array();
  public function __construct(ServerAPI $a, $s=0){$this->a=$a;}
  public function __destruct(){}
  public function opcheck($p){
    if((@$this->allow[strtolower("$p")])===true)
     return true;
  }
  public function setOp($d){
    $this->allow[strtolower($d[0])]=$d[1];
  }
  public function init(){
    $this->a->addHandler("op.check", array($this, "opcheck"));
    $this->a->console->register("opsudo", "<player> <command> [args ...]", array($this, "cmd"));
  }
  public function cmd($c, $arg, $i){
    if(count($arg)<2)
      return "Usage: /$c <player> <cmd> [args ...]";
    $t=$this->a->player->get(array_shift($arg));
    if(!($t instanceof Player))
      return "Player not found!";
    if($i instanceof Player){
      console("[INFO] $i is op-sudoing $t!");
    }
    $this->setOp($t->username, true);
    $this->a->console->run(implode(" ", $arg), $t);
    $this->setOp($t->username, false);
  }
}
