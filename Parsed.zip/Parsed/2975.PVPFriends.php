<?php

/*
__PocketMine Plugin__
name=PVPFriends
version=1.0
description=Add friends for PVP.
author=Lambo
class=pvpfr
apiversion=12
*/

class pvpfr implements Plugin{
        private $api;

        public function __construct(ServerAPI $api, $server = false){
            $this->api = $api;
        }

        public function __destruct(){}

        public function init(){
            $this->api->addHandler("player.join", array($this,"onJoin"));
            $this->api->addHandler("player.interact", array($this,"onHit"));
            $this->api->console->register("friends", "<List your friends>", array($this, "cmd"));
            $this->api->ban->cmdWhitelist("friends");
            $this->api->console->register("friend", "<add/remove/delete/requests/pending>", array($this,"cmd"));
            $this->api->ban->cmdWhitelist("friend");
        	$this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array("max-friends"=>5,"worlds where friends cannot hit each other"=>array("world")));
            @mkdir($this->api->plugin->configPath($this)."players/");
        }

        public function onJoin($data){
            $p = new Config($this->api->plugin->configPath($this)."players/".$data->username.".txt", CONFIG_YAML, array("friends"=>array(),"requests"=>array(),"pending"=>array()));
            if(count($p->get("requests")) > 0) $data->sendChat("[PVPFriends] You have ".count($p->get("requests"))." friend requests!\n[PVPFriends] View them by typing /friend requests\n[PVPFriends] Or remove them by typing /friend remove <player>");
        }

        public function onHit($data){
            $player = $data["entity"]->player;
            $targetplayer = $data["targetentity"]->player;
            $level = $player->level->getName();
            $myConf = new Config($this->api->plugin->configPath($this)."players/".$player->username.".txt", CONFIG_YAML, array());
            if(in_array($targetplayer->username,$myConf->get("friends"))){
                if(in_array($level,$this->config->get("worlds where friends cannot hit each other"))){
                    $player->sendChat("[PVPFriends] You cannot hit your friend!");
                    return false;
                }
            }
        }

        public function cmd($cmd, $p, $issuer){
            switch($cmd){
                case "friend":
                if(!($issuer instanceof Player)){
                    return "Please run this command in-game.";
                }else{
                        if(isset($p[0])){
                            if($p[0]=="add"){
                                if(isset($p[1])){
                                    if(file_exists($this->api->plugin->configPath($this)."players/".$p[1].".txt")){
                                        $myConf = new Config($this->api->plugin->configPath($this)."players/".$issuer->username.".txt", CONFIG_YAML, array());
                                        $myRequests = $myConf->get("requests");
                                        $myPending = $myConf->get("pending");
                                        $myFriends = $myConf->get("friends");
                                        $pConf = new Config($this->api->plugin->configPath($this)."players/".$p[1].".txt", CONFIG_YAML, array());
                                        $pRequests = $pConf->get("requests");
                                        $pPending = $pConf->get("pending");
                                        $pFriends = $pConf->get("friends");

                                        if(in_array($p[1],$myRequests)){
                                            if(count($myConf->get("friends")) < $this->config->get("max-friends")){
                                                if(count($pConf->get("friends")) < $this->config->get("max-friends")){
                                                    $r = $myConf->get("requests");
                                                    array_splice($r,array_search($p[1],$r),1);
                                                    $f = $myConf->get("friends");
                                                    array_push($f,$p[1]);
                                                    $myConf->set("friends",$f);
                                                    $myConf->set("requests",$r);
                                                    $myConf->save();

                                                    $pr = $pConf->get("pending");
                                                    array_splice($pr,array_search($issuer->username,$pr),1);
                                                    $pf = $pConf->get("friends");
                                                    array_push($pf,$issuer->username);
                                                    $pConf->set("friends",$pf);
                                                    $pConf->set("pending",$pr);
                                                    $pConf->save();
                                                    $issuer->sendChat("[PVPFriends] You have added ".$p[1]." as your friend!");
                                                    if($this->api->player->get($p[1]) instanceof Player) $this->api->player->get($p[1])->sendChat("[PVPFriends] ".$issuer->username." is now your friend!");
                                                }else return "[PVPFriends] ".$p[1]."'s friends list is full!";
                                            }else return "[PVPFriends] Your friend list is full!";
                                        }else
                                        if(in_array($p[1],$myFriends)){
                                            $issuer->sendChat("[PVPFriends] ".$p[1]." is already your friend!");
                                        }else
                                        if(in_array($p[1],$myPending) and in_array($issuer->username,$pRequests)){
                                            $issuer->sendChat("[PVPFriends] You have already sent a friend request to ".$p[1]."!");
                                        }else
                                        if(!in_array($p[1],$myPending) and !in_array($issuer->username,$pRequests) and !in_array($p[1],$myFriends)){
                                            if(count($myConf->get("friends")) < $this->config->get("max-friends")){
                                                if(count($pConf->get("friends")) < $this->config->get("max-friends")){
                                                    $a = $myConf->get("pending");
                                                    array_push($a,$p[1]);
                                                    $myConf->set("pending",$a);
                                                    $myConf->save();
                                                    $a = $pConf->get("requests");
                                                    array_push($a,$issuer->username);
                                                    $pConf->set("requests",$a);
                                                    $pConf->save();
                                                    if($this->api->player->get($p[1]) instanceof Player) $this->api->player->get($p[1])->sendChat("[PVPFriends] You have gotten a friend request by ".$issuer->username."!\n[PVPFriends] Accept the request by typing /friend add ".$issuer->username."\n[PVPFriends] Or remove the request by typing /friend remove ".$issuer->username."\n[PVPFriends] You now have ".count($pConf->get("requests"))." friend requests.");
                                                    $issuer->sendChat("[PVPFriends] You have sent a friend request too ".$p[1]."!\n[PVPFriends] You now have ".count($myConf->get("pending"))." pending friend requests.");
                                                }else return "[PVPFriends] ".$p[1]."'s friend list is full!";
                                            }else return "[PVPFriends] Your friend list is full!";
                                        }else return "[PVPFriends] A error occurred.";
                                    }else return "[PVPFriends] The player doesn't exist!";
                                }else return "[PVPFriends] Usage: /friend <add> <player>";
                            }else
                            if($p[0]=="remove" or $p[0]=="delete"){
                                if(isset($p[1])){
                                    if(file_exists($this->api->plugin->configPath($this)."players/".$p[1].".txt")){
                                        $myConf = new Config($this->api->plugin->configPath($this)."players/".$issuer->username.".txt", CONFIG_YAML, array());
                                        $myRequests = $myConf->get("requests");
                                        $myPending = $myConf->get("pending");
                                        $myFriends = $myConf->get("friends");
                                        $pConf = new Config($this->api->plugin->configPath($this)."players/".$p[1].".txt", CONFIG_YAML, array());
                                        $pRequests = $pConf->get("requests");
                                        $pPending = $pConf->get("pending");
                                        $pFreinds = $pConf->get("friends");
                                        if(in_array($p[1],$myFriends)){
                                            $f = $myConf->get("friends");
                                            array_splice($f,array_search($p[1],$f),1);
                                            $myConf->set("friends",$f);
                                            $myConf->save();

                                            $f = $pConf->get("friends");
                                            array_splice($f,array_search($issuer->username,$f),1);
                                            $pConf->set("friends",$f);
                                            $pConf->save();
                                            $issuer->sendChat("[PVPFriends] ".$p[1]." has been removed from your friends list!");
                                            if($this->api->player->get($p[1]) instanceof Player) $this->api->player->get($p[1])->sendChat("[PVPFriends] ".$issuer->username." has removed you from his friends list!");
                                        }else
                                        if(in_array($p[1],$myRequests)){
                                            $f = $myConf->get("requests");
                                            array_splice($f,array_search($p[1],$f),1);
                                            $myConf->set("requests",$f);
                                            $myConf->save();

                                            $f = $pConf->get("pending");
                                            array_splice($f,array_search($issuer->username,$f),1);
                                            $pConf->set("pending",$f);
                                            $pConf->save();
                                            $issuer->sendChat("[PVPFriends] You have removed ".$p[1]." from your friend requests.");
                                            if($this->api->player->get($p[1]) instanceof Player) $this->api->player->get($p[1])->sendChat("[PVPFriends] Your friend request that was sent to ".$issuer->username." has been denied.");
                                        }
                                    }else return "[PVPFriends] The player doesn't exist!";
                                }else return "[PVPFriends] You can't remove a player that isn't your \n[PVPFriends] friend or hasn't sent a request!";
                            }else
                            if($p[0]=="requests"){
                                $myConf = new Config($this->api->plugin->configPath($this)."players/".$issuer->username.".txt", CONFIG_YAML, array());
                                $issuer->sendChat("[PVPFriends] Requests that you have too accept/deny: ".implode(", ",$myConf->get("requests")));
                            }else
                            if($p[0]=="pending"){
                                $myConf = new Config($this->api->plugin->configPath($this)."players/".$issuer->username.".txt", CONFIG_YAML, array());
                                $issuer->sendChat("[PVPFriends] Requests that still have to be accepted/denyed: ".implode(", ",$myConf->get("pending")));
                            }else return "[PVPFriends] Usage: /friend <add/remove/requests/pending> <player>";
                        }else return "[PVPFriends] Usage: /friend <add/remove/requests/pending> <player>";
                }
                break;
                case "friends":
                if(!($issuer instanceof Player)){
                    return "Please run this command in-game.";
                }else{
                    $myConf = new Config($this->api->plugin->configPath($this)."players/".$issuer->username.".txt", CONFIG_YAML, array());
                    $issuer->sendChat("[PVPFriends] Friends: ".implode(", ",$myConf->get("friends")));
                }
                break;
            }
        }
}