import requests as req
import re
for cf in range(6568, 10000000):
	r = req.get(f"https://forums.pocketmine.net/attachments/{cf}")
	if(r.status_code == 200):
		d = r.headers['content-disposition']
		fname = re.findall("filename=(.+)", d)[0][1:-1]
		print("Downloading ", fname, ": ", cf)
		with open(str(cf)+"."+fname, "wb") as f:
			f.write(r.content)
	else:
		print("failed: ", cf)
