<?php

/*
__PocketMine Plugin__
name=Gills
description=Allow players to breath underwater
version=1.0
author=Falk
class=Gills
apiversion=10,11,12,13
*/

class Gills implements Plugin{
	private $api, $path, $config;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->api->addHandler("entity.health.change", array($this, "eventHandler"));
		$this->api->console->register("gills", "Give a user gills", array($this, "command"));
}
	
	public function __destruct() {}
	public function command($cmd, $params, $issuer){
	if (isset($params[0])) {
	if (isset($this->gills[$params[0]])) unset($this->gills[$params[0]]);
	else $this->gills[$params[0]] = true;
	return $params[0] . (isset($this->gills[$params[0]]) ? " can breath underwater." : " can no longer breath underwater.");
}
else return "Usage: /gills <PLAYER NAME>";
	}

	public function eventHandler($data, $event) {
		if ($data['entity']->class !== ENTITY_PLAYER) return true;
		if ($data['cause'] == "water" && isset($this->gills[$this->api->player->getByEID($data['entity']->eid)->username])) return false;
		else return true;
	}
	
}