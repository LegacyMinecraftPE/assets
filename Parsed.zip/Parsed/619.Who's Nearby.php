<?php

/*
__PocketMine Plugin__
name=Who's Nearby
description=Switches block with a similar type (flower to another flower)
version=0.1
author=Junyi00
class=Nearby
apiversion=10
*/

class Nearby implements Plugin{
	private $api, $path, $config;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->path = $this->api->plugin->configPath($this);
		$this->api->console->register("nearby", "Enable/Disable check for nearby players", array($this, "detectSwitch"));
		$this->api->ban->cmdWhitelist("nearby");
		$this->config = new Config($this->path."config.yml", CONFIG_YAML, array());
		$this->api->schedule(20* 10, array($this, "Check"), array(), true);
		
	}
	
	public function __destruct() {}
	
	public function detectSwitch($cmd, $arg, $issuer) {
        $username = $issuer->username;
        $data = $this->config->get($username);
        if ($data['On/Off'] == "On") {
            $this->config->set($username, array("On/Off" => "Off"));
        }
        else {
            $this->config->set($username, array("On/Off" => "On"));
        }
        $this->config->save();
    } //flip boolean
	
	public function Check() {
		$py = $this->api->player->online();
		$copy = $py;
		if (count($py) > 1) {
			for($i=0;$i<count($py);$i++) {
				if ($i == (count($py)-1)) break;
				
				$p1 = $this->api->player->get($py[$i]);
				array_shift($copy);
				for($e=0;$e<count($copy);$e++) {
					$p2 = $this->api->player->get($copy[$e]);
					
					$p1vec = new Vector3($p1->entity->x, $p1->entity->y, $p1->entity->z);
					$p2vec = new Vector3($p2->entity->x, $p2->entity->y, $p2->entity->z);
					$range = round($p1vec->distance($p2vec));
					if ($range <= 25) {
						if ($this->config->get($p1->username)["On/Off"] == "On") {
							$p1->sendChat($p2->username." is ".round($range)." blocks away from u");
						}
						if ($this->config->get($p2->username)["On/Off"] == "On") {
							$p2->sendChat($p1->username." is ".round($range)." blocks away from u");
						}
						
					}
				}
			}
			$copy = $py;
		}
	}

}