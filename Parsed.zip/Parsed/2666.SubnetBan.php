<?php

/*
__PocketMine Plugin__
name=SubnetBan
description=
version=1.0
author=DarkN3ss
class=SubBan
apiversion=10, 11, 12
*/


class SubBan implements Plugin{
	private $api;
   
	private $subnetBanned;
	private $config;
	private $file;
	private $correct;
	private $type = CONFIG_DETECT;


	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}

	public function init(){
		$this->subnetBanned = new Config($this->api->plugin->configPath($this)."subnetBanned.txt", CONFIG_LIST);//Open Subnet Banned IPs list file
		$this->load($this->api->plugin->configPath($this)."subnetBanned.txt");
		$this->api->console->register("subban", "<add|remove|list|reload> [IP|player]", array($this, "commandHandler"));
		$this->api->addHandler("player.connect", array($this, "eventHandler"), 50);
		
	}
   
	public function eventHandler($data, $event){
		switch($event){
			case "player.connect":
				if($this->isSubnetBanned($this->subnetIP($data->ip)))
				{
					$data->close("You have been banned");
				}
				break;
		}
		return;
	}
	
	public function commandHandler($cmd, $params, $issuer, $alias){
		$output = "";
		switch($cmd){
			case "subban":
				$p = strtolower(array_shift($params));
				switch($p){
					case "pardon":
					case "remove":
						$ip = strtolower($params[0]);
						$this->remove($this->subnetIP($ip));
						$this->save();
						$output .= "IP \"$ip\" removed from ban list\n";
						break;
					case "add":
					case "ban":
						$ip = strtolower($params[0]);
						$player = $this->api->player->get($ip);
						if($player instanceof Player){
							$ip = $player->ip;
							$player->close("banned");
						}
						$this->set($this->subnetIP($ip));
						$this->save();
						$output .= "IP \"$ip\" added to ban list\n";
						break;
					case "reload":
						$this->subnetBanned = new Config($this->api->plugin->configPath($this)."subnetBanned.txt", CONFIG_LIST);
						$this->load($this->api->plugin->configPath($this)."subnetBanned.txt");
						$output .= "Reloaded Subnet Banned List list\n";
						break;
					case "list":
						$output .= "IP ban list: ". implode(", ", $this->getAll(true)) ."\n";
						break;
					default:
						$output .= "Usage: /subban <add|remove|list|reload> [IP|player]\n";
						break;
				}
				break;
		}
		return $output;
	}
	
	public function subnetIP($ip)
	{
		list($ipPart1, $ipPart2) = explode('.', $ip);
		$subnetIP = $ipPart1 . "." . $ipPart2;
		return $subnetIP;
	}
	
	public function getAll($keys = false){
		return ($keys === true ? array_keys($this->config):$this->config);
	}
	
    public function load($file, $type = CONFIG_DETECT, $default = array()){
		$this->correct = true;
		$this->type = (int) $type;
		$this->file = $file;
		if(!is_array($default)){
			$default = array();
		}
		$extension = explode(".", basename($this->file));
		$extension = strtolower(trim(array_pop($extension)));
		if(isset(Config::$formats[$extension]))
		{
			$this->type = Config::$formats[$extension];
			$content = @file_get_contents($this->file);
			$this->parseList($content);
			if(!is_array($this->config)){
				$this->config = $default;
			}	
		}
		return true;
	}
	
	private function parseList($content){
		foreach(explode("\n", trim(str_replace("\r\n", "\n", $content))) as $v){
			$v = trim($v);
			if($v == ""){
				continue;
			}
			$this->config[$v] = true;
		}
	}
	
	public function set($k, $v = true){
		$this->config[$k] = $v;
	}
	
	public function remove($k){
		unset($this->config[$k]);
	}
	
	public function save()
	{
		if($this->correct === true)
		{
			$content = implode("\r\n", array_keys($this->config));
			@file_put_contents($this->file, $content, LOCK_EX);
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public function isSubnetBanned($ip){
		if($this->exists($ip, true)){
			return true;
		}
        else
        {
		    return false;
        }
	}
	
	public function exists($k, $lowercase = false){
        if($lowercase === true):
            $k = strtolower($k);
            $array = array_change_key_case($this->config, CASE_LOWER);
            return isset($array[$k]);
        else:
		    return isset($this->config[$k]);
        endif;
	}
  
	public function __destruct(){
	}
}
?>