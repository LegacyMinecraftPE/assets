<?php

/*
__PocketMine Plugin__
name=StaffListPro
description=Additions to original StaffList plugin
version=1.0
author=Glitchmaster_PE
class=StaffListPro
apiversion=10
*/

class StaffListPro implements Plugin{
	private $api, $lang, $prefix0, $prefix, $path, $config, $user;
	
	public function __construct (ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->api->console->register("stafflist","Gives a list of this server's staff", array($this, "StaffListPro"));
		$this->api->console->register("prefix","Set a users prefix", array($this, "Prefix"));
		$this->api->ban->cmdwhitelist("stafflist");
		$this->readConfig();
		$this->api->addHandler("player.join", array($this, "handler"), 5);
		$this->api->addHandler("player.chat", array($this, "handler"), 5);
		$this->path = $this->api->plugin->configPath($this);
		$this->msgs = new Config($this->path. "staff.yml", CONFIG_YAML, array(
			"  [StaffListPro]
---Owner---
(INSERT HERE)
---Admins---
(INSERT HERE)
---Moderators---
(INSERT HERE)
---Trusted---
(INSERT HERE)",
		));
		$this->msgs = $this->api->plugin->readYAML($this->path . "staff.yml");
	}
	
	public function StaffListPro($cmd, $args, $issuer){
		$username = $issuer->username;
		foreach($this->msgs as $msg){
			$this->api->chat->sendTo(false, $msg, $username);
		}
	}
	
	public function __destruct(){
	}
	
	public function readConfig(){
		$this->path = $this->api->plugin->createConfig($this, array(
			"format" => "[{prefix}]<{DISPLAYNAME}> {MESSAGE}",
		));
		$this->config = $this->api->plugin->readYAML($this->path."config.yml");
	}

	
	public function Prefix($cmd, $args){
	switch($cmd){
	    case "prefix":
	      $player = $args[0];
		  $pref = $args[1];
        
		$this->config['player'][$player] =$pref;
        $this->api->plugin->writeYAML($this->path."config.yml", $this->config);
         $output .= "[StaffListPro] Gave ".$pref." to ".$player.".";
         $this->api->chat->sendTo(false, "[StafflistPro] Your prefix is now ".$pref." !", $player);
          break;
	  
	  default:		$output .= 'StaffListPro by Glitchmaster_PE';
	  break;
	  }
	  }
	  
	public function handler(&$data, $event){
		switch($event){
				case "player.join":
				$user = $data->username;
				if (!isset($this->config['player'][$user])) {
					$this->config['player'][$user] ='Player';
					$this->api->plugin->writeYAML($this->path."config.yml", $this->config);
				}
			break;
			case "player.chat":
			    $prefix = $data["player"]->username;
                $this->config = $this->api->plugin->readYAML($this->path."config.yml");
				$data = array("player" => $data["player"], "message" => str_replace(array("{DISPLAYNAME}", "{MESSAGE}", "{prefix}"), array($data["player"]->username, $data["message"], $this->config["player"][$prefix]), $this->config["format"]));
				if($this->api->handle("StaffListPro.".$event, $data) !== false){
					$this->api->chat->broadcast($data["message"]);
				}
				return false;
				break;
		}
	}	
}
