<?php

/*
__PocketMine Plugin__
name=Advanced PvP
description=On and Off pvp in your server
version=1.0
author=Ilia_plav
class=Advanced_pvp
apiversion=10
*/

/*
Plugin by Ilia_plav
Version 1.0
Email ►► urusovilia@gmail.com
*/

class Advanced_pvp implements Plugin{

	private $api;
	
	private $pvp = true;

	
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->api->addHandler("entity.health.change", array($this, "eventHandler"), 100);
		$this->api->console->register("pvp", "PvP manager", array($this, "pvpcmdHandler"));
		$this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array(
			"pvp"       => true
			));
		 $this->config->reload();
		 
		
		 
		
		
		$this->pvp = $this->config->get('pvp');
		
		
		console("[Advanced PvP] Plugin started...");
		console("[Advanced PvP] Done !");
	}
	
public function eventHandler($data, $event)
	{
		switch($event)
		{
	case 'entity.health.change':
	
	if($this->pvp == false)
	{
	return false;
	}
	
	break;
	}
	}
	
	public function pvpcmdHandler($cmd, $params, $issuer, $alias){
	
	if($cmd = "pvp")
	{
	
	switch(array_shift($params)){
			case "":
				$output = "\n======Advanced PvP=====\n/pvp on - PvP on in server\n/pvp off - PvP off in server\nAdvanced PvP by Rem1x\n=======================
				";
				break;
			case "on":
				$output = "PvP is now on!";
				$this->api->chat->broadcast("[Advanced PvP] PvP is now on!");
				$this->pvp = true;
				break;
			case "off":
				$output = "PvP is now off!";
				$this->api->chat->broadcast("[Advanced PvP] PvP is now off!");
				$this->pvp = false;
				break;	
		}
		
		return $output;
	
	}
	
	}
	
	
	
	
	public function __destruct(){
	}

}