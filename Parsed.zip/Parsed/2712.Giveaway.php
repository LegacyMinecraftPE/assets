<?php

/*
__PocketMine Plugin__
name=Giveaway
description=
version=1.2
author=DarkN3ss
class=Giveaway
apiversion=10, 11, 12, 13
*/

class Giveaway implements Plugin{
   private $api;

   public function __construct(ServerAPI $api, $server = false){
     $this->api = $api;
   }

   public function init(){
		$this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array(
            "GiveawayItems" => array(
                "Items" => array(
                    array(
                        310,
                        0,
                        1
                    ), // id , meta, count
                    array(
                        307,
                        0,
                        1
                    ),
					array(
                        304,
                        0,
                        1
                    ),
					array(
                        301,
                        0,
                        1
                    ),
                )
            ),
        ));
          
        $this->config = $this->api->plugin->readYAML($this->api->plugin->configPath($this) . "config.yml");
		$this->api->console->register("giveaway", "Gives a random player the prizes." , array($this, "commandHandler"));
   }
   
   public function commandHandler($cmd, $params, $issuer, $alias)
	{
		switch($cmd) {
			case "giveaway":
				{
					if ($this->api->ban->isOp($issuer) || !$issuer instanceof Player)
					{
						$playerName = $this->api->player->get($this->randPlayer());
						$items = $this -> config["GiveawayItems"];
						$this->giveItems($items, $playerName);
						$this->api->chat->broadcast($playerName . " Has won the giveaway! Enjoy your items.");
						return;
					}
				}
				break;
		}
		return;
	}
	
	public function randPlayer()
    {
        $RIA =$this->api->player->online();
		$RIN =rand(1,count($RIA)) -1;
		$randomPlayer =$RIA[$RIN];
		return $randomPlayer;
    }
	
	public function giveItems($items, $player)
    {
        foreach ($items['Items'] as $val)
        {
			if($player instanceof Player) 
			{ 
				$player->addItem($val[0], $val[1], $val[2]); 
			}
        }
    }
  
	public function __destruct(){
	}
}
?>