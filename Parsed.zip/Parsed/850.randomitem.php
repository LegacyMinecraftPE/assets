<?php

/*
__PocketMine Plugin__
name=RandomItem
description=Gives a random item on command and at set intervals.
version=0.1.3
author=LDX
class=RandomItem
apiversion=10
*/

class RandomItem implements Plugin {
private $api;
public function __construct(ServerAPI $api, $server = false) {
$this->api = $api;
}

public function init() {
$this->api->console->register("gift", "Gives a random item.", array($this, "giveRI"));
$this->api->schedule(12000,array($this,'giveRI'),array(),true,'server.schedule');
console("[INFO] RandomItem Enabled!");
}

public function __destruct(){}

public function giveRI() {
$RIN = rand(0,4);
$RIA = array("360","267","265","354","6");
$randItem = $RIA[$RIN];
$this->api->console->run("give @all " . $randItem . " 1");
$this->api->chat->broadcast("[RandomItem] Random item given!");
}
}
?>