<?php

/*
__PocketMine Plugin__
name=ChatPro
description=Adds new commands for handling the chat
version=1.0
author=Glitchmaster_PE
class=ChatPro
apiversion=10
*/

class ChatPro implements Plugin{
	private $api, $lang, $prefix0, $prefix, $path, $config, $user;
	
	public function __construct (ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->api->console->register("stafflist","Gives a list of this server's staff", array($this, "StaffListPro"));
		$this->api->console->register("prefix","Set a users prefix. Usage: /prefix <username> [prefix]", array($this, "Prefix"));
		$this->api->ban->cmdwhitelist("stafflist");
		$this->readConfig();
		$this->api->addHandler("player.join", array($this, "handler"), 5);
		$this->api->addHandler("player.chat", array($this, "handler"), 5);
		$this->path = $this->api->plugin->configPath($this);
		$this->staffmsgs = new Config($this->path. "staff.yml", CONFIG_YAML, array(
			"  [ChatPro]
---Owner---
(INSERT HERE)
---Admins---
(INSERT HERE)
---Moderators---
(INSERT HERE)
---Trusted---
(INSERT HERE)",
		));
		$this->staffmsgs = $this->api->plugin->readYAML($this->path . "staff.yml");
		$this->api->console->register("announce","Gives server announcements", array($this, "Announce"));
		$this->api->ban->cmdwhitelist("announce");
		$this->path = $this->api->plugin->configPath($this);
		$this->announcemsgs = new Config($this->path. "announcements.yml", CONFIG_YAML, array("Announcements" => "[ChatPro] YOUR ANNOUNCEMENTS HERE"));
		$this->announcemsgs = $this->api->plugin->readYAML($this->path . "announcements.yml");
	}
	
	public function StaffListPro($cmd, $args, $issuer){
		$username = $issuer->username;
		foreach($this->staffmsgs as $staffmsg){
			$this->api->chat->sendTo(false, $staffmsg, $username);
		}
	}
	
	public function Announce($cmd, $args, $issuer){
		$username = $issuer->username;
		foreach($this->announcemsgs as $announcemsg){
			$this->api->chat->sendTo(false, $announcemsg, $username);
		}
	}
	
	public function __destruct(){
	}
	
	public function readConfig(){
		$this->path = $this->api->plugin->createConfig($this, array(
			"format" => "[{prefix}]<{DISPLAYNAME}> {MESSAGE}",
		));
		$this->config = $this->api->plugin->readYAML($this->path."config.yml");
	}

	
	public function Prefix($cmd, $args){
	switch($cmd){
	    case "prefix":
	      $player = $args[0];
		  $pref = $args[1];
        
		$this->config['player'][$player] =$pref;
        $this->api->plugin->writeYAML($this->path."config.yml", $this->config);
         $output .= "[ChatPro] Gave ".$pref." to ".$player.".";
         $this->api->chat->sendTo(false, "[ChatPro] Your prefix is now ".$pref." !", $player);
          break;
	  
	  default:		$output .= 'ChatPro by Glitchmaster_PE';
	  break;
	  }
	  }
	  
	public function handler(&$data, $event){
		switch($event){
				case "player.join":
				$user = $data->username;
				if (!isset($this->config['player'][$user])) {
					$this->config['player'][$user] ='Player';
					$this->api->plugin->writeYAML($this->path."config.yml", $this->config);
				}
			break;
			case "player.chat":
			    $prefix = $data["player"]->username;
                $this->config = $this->api->plugin->readYAML($this->path."config.yml");
				$data = array("player" => $data["player"], "message" => str_replace(array("{DISPLAYNAME}", "{MESSAGE}", "{prefix}"), array($data["player"]->username, $data["message"], $this->config["player"][$prefix]), $this->config["format"]));
				if($this->api->handle("ChatPro.".$event, $data) !== false){
					$this->api->chat->broadcast($data["message"]);
				}
				return false;
				break;
		}
	}	
}
?>
