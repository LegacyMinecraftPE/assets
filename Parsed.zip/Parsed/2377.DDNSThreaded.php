<?php
/*
__PocketMine Plugin__
name=DDNS
description=Sends IP updates to a Dynamic DNS server
version=0.1
author=Falk
class=dynamicDNS
apiversion=10,11,12,13
*/
/*
Important Info
- Although the api for DDNS services claims to be universal, services vary in API requirements
- A base64 authorization header is automatically attached to headers.
- On errors the plugin will not continue to send requests (in compliance with no-ip rules)
- If you recieve a 911 error code it is safe to wait about a half hour before retrying (some services may block you)

*/
class dynamicDNS implements Plugin{
private $api, $path;
public function __construct(ServerAPI $api, $server = false){
$this->api = $api;
}

public function init(){
$this->api->console->register("purgeip", "Purge any errors and force IP to be sent", array($this, "command"));
$this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array("api" =>"url of api gateway","user" => "username","password" => "your password", "hostname" => "hostname to use", "ip" => "DO NOT SET THIS :)"));
$this->data = $this->api->plugin->readYAML($this->api->plugin->configPath($this). "config.yml");
if($this->data["api"] == "url of api gateway"){ 
console("[ERROR] Please configure DDNS in the config.yml then restart your server or run /purgeip"); 
return false;
}
$this->loop = new checkLoop();
$this->loop->newData($this->data);
}

public function __destruct(){
	if(isset($this->loop)) $this->api->plugin->writeYAML($this->api->plugin->configPath($this)."config.yml", $this->loop->stop());
}
public function command($cmd, $params, $issuer, $alias, $args, $issuer){
$this->data = $this->api->plugin->readYAML($this->api->plugin->configPath($this). "config.yml");
$this->data["ip"] = "waiting";
$this->loop->error = false;
$this->loop->newData($this->data);
return "[DDNS] IP data purged, wait for next check to see results";
}
public function writeTo($ip){
$this->data["ip"] = $ip;
$this->loop->newData($this->data);

}
}
class checkLoop extends Thread{
	public $datas;
	public $error;
	public $stop;
	public $ip;
	public function __construct(){
		$this->datas = array();
		$this->error = false;
		$this->stop = false;
		$this->start();
	}

	public function stop(){
		$this->stop = true;
		$data = $this->datas;
		$data["ip"] = $this->ip;
		return $data;

	}
	public function newData($new){
		$this->datas = $new;
		$this->ip = $this->datas["ip"];
	}
	public function run(){
		while($this->stop === false){
			$curr = Utils::getIP(true);
			if($this->ip != $curr && !$this->error){	
	$auth = "Basic " . base64_encode($this->datas["user"] . ":" . $this->datas["password"]);
$ch = curl_init("https://" . $this->datas["api"] . "?hostname=" . $this->datas["hostname"] . "&myip=" . $curr);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array("User-Agent: PocketMine DDNS Client/0.1 falkirknh@gmail.com","Authorization: " . $auth));
		curl_setopt($ch, CURLOPT_AUTOREFERER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_FORBID_REUSE, 1); 
		curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1); 
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,10);
		$result = curl_exec($ch);
		curl_close($ch);
  if(strpos($result, "good") === 0 || strpos($result, "nochg") === 0 ){
  console("[DDNS] New IP sent to server.");
  $this->ip = $curr;
  }
  else{
  	console("[DDNS] An error occured, the code is below:");
  	console($result);
  	$this->error = true;
  	console("[DDNS] To remove an error you should resolve the problem and run purgeip");
  }
		}
	}
	exit(0);
}
}