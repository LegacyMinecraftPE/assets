<?php

/*
__PocketMine Plugin__
name=LogIntercepter
description=Detects changes to the log, and acts as a server, sending UDP packets to broadcast.
version=0.6
author=jython234
class=PluginCore
apiversion=12
*/
define("BROADCAST", "255.255.255.255");
define("PACKET_COMMAND_CONSOLE", "CC-");
define("PACKET_COMMAND_PLAYER", "CP-");
define("PACKET_PLAYER_CHAT", "PC-");
define("PACKET_GAMEMODE_CHANGE", "GC-");
define("PACKET_LOG_CHANGE", "LC-");
define("PACKET_CS_AUTH", "AUTH-");

class PluginCore implements Plugin{
	public $logSock;
	private $api;

	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}

	public function init(){
		$this->logMsg("Creating network socket...");
		$this->logSock = socket_create(AF_INET, SOCK_DGRAM, 0);
		socket_set_option($this->logSock, SOL_SOCKET, SO_BROADCAST, 1); 
		socket_set_nonblock($this->logSock);

		$this->api->addHandler('console.command', array($this, "evtHandler"));
		$this->api->addHandler('player.chat', array($this, "evtHandler"));
		$this->api->addHandler('player.gamemode.change', array($this, "evtHandler"));

		$this->logMsg("Plugin successfully enabled!");
	}

	

	public function evtHandler($evtData, $evt){
	  //TODO: WORK ON THIS!!
	  switch($evt){
	  case 'console.command':
	    //var_dump($cmd); //DEBUG
	    $issuer = $evtData['issuer'];
	    $issuerType = null;
	    if($issuer instanceof Player){
	      $issuerType = "Player";
	    }
	    else{
	      $issuerType = "Console";
	    }

	    //$this->logMsg("Command issued by: $issuerType"); //DEBUG
	    
	    $root = $evtData['cmd'];
	    $param = $evtData['parameters'];
	    $params = implode(" ", $param);
	    $command = $root ." " . $params;
	    if($issuerType == "Console"){
	      $this->sendCommand($command, PACKET_COMMAND_CONSOLE);
	    }
	    else{
	      $player = $issuer->iusername;
	      $this->sendCommand($command, PACKET_COMMAND_PLAYER, $player);
	    }
	    break;

	  case 'player.chat':
	    //SAY HI
	    $player = $evtData['player']->iusername;
	    $msg = $evtData['message'];
	    
	    $this->sendChat($msg, $player);
	    break;
		
	  case 'player.gamemode.change':
		//TODO: Work!
		//var_dump($evtData); //DEBUG
		$player = $evtData['player'];
		$playerName = $player->iusername;
		$gamemode = $player->gamemode;
		$this->logMsg("Player gamemode change: $playerName to $gamemode"); //DEBUG
		
		$this->sendGamemode($player, $gamemode);
		break;
	  }
	}

	private function sendCommand($command, $PID, $player = null){
	  if($PID == PACKET_COMMAND_PLAYER){
	    $data = PACKET_COMMAND_PLAYER . $player . "-" . $command;
	  }
	  else if($PID == PACKET_COMMAND_CONSOLE){
	    $data = PACKET_COMMAND_CONSOLE . $command;
	  }
	  socket_sendto($this->logSock, $data, strlen($data), 0, BROADCAST, 19130);
	}

	private function sendChat($message, $player){
	  $data = PACKET_PLAYER_CHAT . $player . "-" . $message;
	  socket_sendto($this->logSock, $data, strlen($data), 0, BROADCAST, 19130);
	}
	
	private function sendGamemode($player, $gamemode){
		$data = PACKET_GAMEMODE_CHANGE . $player->iusername . "-" . $gamemode;
		socket_sendto($this->logSock, $data, strlen($data), 0, BROADCAST, 19130);
	}

	private function strToHex($string){
	     $hex = '';
	     for ($i=0; $i<strlen($string); $i++){
	         $ord = ord($string[$i]);
	         $hexCode = dechex($ord);
	         $hex .= substr('0'.$hexCode, -2);
	     }
	     return strToUpper($hex);
	}

	function hexToStr($hex){
	  $string='';
	  for ($i=0; $i < strlen($hex)-1; $i+=2){
	    $string .= chr(hexdec($hex[$i].$hex[$i+1]));
	  }
	  return $string;
	}

	private function logMsg($msg){
		console("[Log Interceptor]: " . $msg);
	}

	public function __destruct(){
	  //TODO: Class destruction
	  socket_close($this->logSock);
	}
}