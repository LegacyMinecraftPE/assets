﻿<?php
/*
__PocketMine Plugin__
name=Siri - A informational chat bot that you can talk to,ask questions from and run commands 
version=2.2.1
author=Legomite
class=Siri
apiversion=9,10
*/

/*
___small-changelog___
1.2.1
*Added a new loading message
* Change the name of the file to Siri 2.2.1 by Legomite so you can identify the version your running
* updated the version name to 2.2.1 as it stayed 1.0.0 through two updates.
* Updated the name as though it is outdated.
* STILL DID NOT FIX THE GAMEMODE CHANGE COMMAND
1.2.0
* Added 3 new responses!!!
* Siri can now do one type of joke. e.g) What.did.the.fox.say? (still needs working on) 
* Siri can now talk about bathrooms!!!
* Add you think im funny? response. (actual text from real Siri) 
* Improved Siri's sense of humour
* Fixed some capitalizing and added periods for some text that were missing some.
* SWITCHING GAMEMODES DOES NOT WORK AS OF 1.1.0 AND 1.2.0
1.1.0
* removed what your speech said.
* made the commands more flexible and now access commands with multiple speeches
* Added new responses as call.me.master and sing.for.me and do.you.have.any.good.news?
* Can now ask Siri to switch gamemodes for you.
* New loading sign
* Several minor improvements and background changes.
1.0.0
* released
*/

class Siri implements Plugin{
private $api;
public function __construct(ServerAPI $api, $server = false){
$this->api = $api;
}

public function init(){

$this->api->console->register("siri", "Siri", array($this, "command"));
/*Greetings*/
$this->api->console->alias("hello", "Siri");
$this->api->console->alias("hi", "Siri");
/*kill*/
$this->api->console->alias("kill.everyone", "Siri");
$this->api->console->alias("kill.everybody", "Siri");
$this->api->console->alias("kill.us.all", "Siri");
$this->api->console->alias("kill.us.all!", "Siri");
/*brightness,darkness,weather*/
$this->api->console->alias("increase.my.brightness", "Siri");
$this->api->console->alias("decrease.my.brightness", "Siri");
$this->api->console->alias("make.it.brighter", "Siri");
$this->api->console->alias("make.it.darker", "Siri");
$this->api->console->alias("what.is.the.weather", "Siri");
$this->api->console->alias("what.is.the.weather?", "Siri");
$this->api->console->alias("what's.the.weather", "Siri");
$this->api->console->alias("what's.the.weather?", "Siri");
$this->api->console->alias("what's.the.weather.for.today", "Siri");
$this->api->console->alias("what's.the.weather.for.today?", "Siri");
/*what's minecraft?*/
$this->api->console->alias("search.up.Minecraft", "Siri");
$this->api->console->alias("what.is.minecraft", "Siri");
$this->api->console->alias("what.is.minecraft?", "Siri");
/*others*/
$this->api->console->alias("i.love.you", "Siri");
$this->api->console->alias("kill.me", "Siri");
$this->api->console->alias("How.old.is.president.obama", "Siri");
$this->api->console->alias("what.is.in.the.next.mcpe.update", "Siri");
/*do you like,you are very...*/
$this->api->console->alias("Do.you.like.cake", "Siri");
$this->api->console->alias("Do.you.like", "Siri");
$this->api->console->alias("You.are.very", "Siri");
/*good news?*/
$this->api->console->alias("any.good.news", "Siri");
$this->api->console->alias("any.good.news?", "Siri");
$this->api->console->alias("do.you.have.some.good.news", "Siri");
$this->api->console->alias("do.you.have.some.good.news?", "Siri");
/*gamemode switch*/
$this->api->console->alias("Switch.to.creative.mode", "Siri");
$this->api->console->alias("Switch.to.creative", "Siri");
$this->api->console->alias("Switch.to.creativemode", "Siri");
$this->api->console->alias("Switch.to.survival.mode", "Siri");
$this->api->console->alias("Switch.to.survival", "Siri");
$this->api->console->alias("Switch.to.survivalmode", "Siri");
$this->api->console->alias("Switch.to.adventure.mode", "Siri");
$this->api->console->alias("Switch.to.adventure", "Siri");
$this->api->console->alias("Switch.to.adventuremode", "Siri");
/*sing to me*/
$this->api->console->alias("sing.to.me", "Siri");
$this->api->console->alias("sing.for.me", "Siri");
$this->api->console->alias("sing", "Siri");
$this->api->console->alias("sing.me.a.song", "Siri");
$this->api->console->alias("play.me.a.song", "Siri");
/*call me master*/
$this->api->console->alias("call.me.master", "Siri");
$this->api->console->alias("my.name.is.master", "Siri");
$this->api->console->alias("nickname.me.master", "Siri");
$this->api->console->alias("for.now.on.you.will.call.me.master", "Siri");
/*You think I am funny?*/
$this->api->console->alias("ha.ha", "Siri");
$this->api->console->alias("ha.ha.ha", "Siri");
$this->api->console->alias("hee.hee", "Siri");
$this->api->console->alias("your.funny", "Siri");
/*I need to go to the bathroom*/
$this->api->console->alias("I.need.to.go.to.the.bathroom", "Siri");
$this->api->console->alias("i.need.to.go.to.the.bathroom.to.do.a.number.two", "Siri");
$this->api->console->alias("i.need.to.go.to.the.bathroom.to.do.a.number.one", "Siri");
$this->api->console->alias("i.need.to.go.to.the.bathroom.to.do.a.number.2", "Siri");
$this->api->console->alias("i.need.to.go.to.the.bathroom.to.do.a.number.1", "Siri");
$this->api->console->alias("i.need.to.go.to.the.toilet", "Siri");
$this->api->console->alias("i.need.to.eject.some.dung", "Siri");
$this->api->console->alias("i.need.to.eject.some.dung!", "Siri");
/*I did the thing say? jokes*/
$this->api->console->alias("what.did.the.fox.say", "Siri");
$this->api->console->alias("what.did.the.fox.say?", "Siri");
$this->api->console->alias("what.did.the.bird.say", "Siri");
$this->api->console->alias("what.did.the.bird.say?", "Siri");
$this->api->console->alias("what.did.the.guy.say", "Siri");
$this->api->console->alias("what.did.the.guy.say?", "Siri");
$this->api->console->alias("what.did.the.goose.say", "Siri");
$this->api->console->alias("what.did.the.goose.say?", "Siri");
$this->api->console->alias("what.did.the.butt.say", "Siri");
$this->api->console->alias("what.did.the.butt.say?", "Siri");
$this->api->console->alias("what.did.the.duck.say", "Siri");
$this->api->console->alias("what.did.the.duck.say?", "Siri");
console("§a[Siri] Siri loading...");
console("§a[Siri] §dThis plugin is created by §cLegomite.§dPlease check if you have the latest version of this plugin as I will update it constantly.");
}

public function __destruct(){}

public function command($cmd, $params, $issuer, $alias, $args, $issuer){
$subcmd = strtolower(array_shift($params));
switch($subcmd){
case "hello":
$this->api->chat->broadcast("<Siri> Hello master!");
break;
case "hi":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> Siri says hi back.");
break;
case "kill.everyone":
case "kill.everybody":
case "kill.us.all":
case "kill.us.all!":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> Okay, killing everybody.");
$this -> api -> console -> run("kill @a");
break;
case "increase.my.brightness":
case "make.it.brighter":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> Okay increasing brightness.");
$this -> api -> console -> run("time set day");
break;
case "decrease.my.brightness":
case "make.it.darker":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> Okay decreasing brightness.");
$this -> api -> console -> run("time set night");
break;
case "what.is.the.weather":
case "what.is.the.weather?":
case "what's.the.weather":
case "what's.the.weather?":
case "what's.the.weather.for.today":
case "what's.the.weather.for.today?":
$this->api->chat->broadcast("<Siri> It is sunny and partially cloudy today with 0");
$this->api->chat->broadcast("percent chance of rain fall, but of course you");
$this->api->chat->broadcast("allready know that.");
break;
case "search.up.minecraft":
case "what.is.minecraft":
case "what.is.minecraft?":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> Okay, here's what I got.");
$this->api->chat->broadcast("< Minecraft was made back in 2009");
$this->api->chat->broadcast("< Minecraft was founded my Notch");
$this->api->chat->broadcast("< Notch gave the lead development");
$this->api->chat->broadcast("of Minecraft to Jeb");
$this->api->chat->broadcast("< for more info go to http://minecraft.gamepedia.com/");
break;
case "i.love.you":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> You are the wind beneath my wings.");
break;
case "kill.me":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> I don't think that's a good idea.");
break;
case "how.old.is.president.obama":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> He is 52 years old,born august 4, 1961.");
break;
case "what.is.in.the.next.mcpe.update":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> It is going to be 8.0 They are adding");
$this->api->chat->broadcast("carpets,pumpkins,Birch and spruce planks,");
$this->api->chat->broadcast("slabs,and stairs,rails,powered rails,cobblestone");
$this->api->chat->broadcast("walls,mossy walls,iron bars,sponges,jungle wood");
$this->api->chat->broadcast("Carrots,potatoes,minecarts,pumkin seeds,pumkin pie,");
$this->api->chat->broadcast("far render distance and more. But I cannot");
$this->api->chat->broadcast("fit it on this small chat. For more info visit");
$this->api->chat->broadcast("http://minecraft.gamepedia.com/Pocket_Edition_upcoming_features");
break;
case "do.you.like.cake":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> Yes,but only the square type.");
break;
case "do.you.like":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> No,maybe,or yes.");
break;
case "you.are.very":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> Why?");
break;
case "switch.to.creative.mode":
case "switch.to.creative":
case "switch.to.creativemode":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> Okay, Switching to creative mode...");
$this -> api -> console -> run("gamemode 1".$user);
break;
case "switch.to.survival.mode":
case "switch.to.survival":
case "switch.to.survivalmode":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> Okay, Switching to Survival mode...");
$this -> api -> console -> run("gamemode 0".$user);
break;
case "switch.to.adventure.mode":
case "switch.to.adventure":
case "switch.to.adventuremode":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> Okay, Switching to Adventure mode...");
$this -> api -> console -> run("gamemode 2".$user);
break;
case "any.good.news":
case "any.good.news?":
case "do.you.have.some.good.news":
case "do.you.have.some.good.news?":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> Yes,pocket edition is getting a load");
$this->api->chat->broadcast("of blocks, item's and tweaks.");
$this->api->chat->broadcast("One of the biggest updates in mcpe.");
break;
case "sing.for.me":
case "sing.to.me":
case "sing":
case "sing.me.a.song":
case "play.me.a.song":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> You know I can't sing.");
break;
case "call.me.master":
case "my.name.is.master":
case "nickname.me.master":
case "for.now.on.you.will.now.call.me.master":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> Your wish is my command, O Great and");
$this->api->chat->broadcast("Benevolent Master.");
break;
case "ha.ha":
case "ha.ha.ha":
case "hee.hee":
case "your.funny":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> You think im funny?");
break;
case "I.need.to.go.to.the.bathroom":
case "i.need.to.go.to.the.bathroom.to.do.a.number.two":
case "i.need.to.go.to.the.bathroom.to.do.a.number.one":
case "i.need.to.go.to.the.bathroom.to.do.a.number.2":
case "i.need.to.go.to.the.bathroom.to.do.a.number.1":
case "i.need.to.go.to.the.toilet":
case "i.need.to.eject.some.dung":
case "i.need.to.eject.some.dung!":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> We are not that close. Please keep your");
$this->api->chat->broadcast("dung to yourself.");
break;
case "what.did.the.fox.say":
case "what.did.the.fox.say?":
case "what.did.the.bird.say":
case "what.did.the.bird.say?":
case "what.did.the.guy.say":
case "what.did.the.guy.say?":
case "what.did.the.goose.say":
case "what.did.the.goose.say?":
case "what.did.the.butt.say":
case "what.did.the.butt.say?":
case "what.did.the.duck.say":
case "what.did.the.duck.say?":
$user = strtolower($args[0]);
$this->api->chat->broadcast("<Siri> I don't know. What did he say?");
break;
}

}
}