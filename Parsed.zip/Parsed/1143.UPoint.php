<?php
/*
__PocketMine Plugin__
name=UPoint
description=CheckPoint system
version=1.0
author=1ron_pon3
class=UPoint
apiversion=10
*/
class upoint implements Plugin{
private $api, $path, $player, $user;
public function __construct(ServerAPI $api, $server = false){
$this->api = $api;
}

public function init(){

$this->api->addHandler("player.block.touch", array($this,"handler"),5);
$this->api->addHandler("player.spawn", array($this,"handler"),5);
$this->api->addHandler("player.respawn", array($this,"handler"),5);
$this->readConfig();
console(FORMAT_GREEN."[".FORMAT_RED."U".FORMAT_DARK_PURPLE."Point".FORMAT_GREEN."] Loaded configuration!");
}

public function __destruct(){}

public function readConfig(){
		$this->path = $this->api->plugin->createConfig($this, array());
		$this->config = $this->api->plugin->readYAML($this->path."config.yml");
}

public function handler($data, $event){
switch($event){
case "player.block.touch":
if($data["target"]->getID() === 247){
$user = $data["player"]->username;
$this->config['points'][$user]['x'] = round($data["player"]->entity->x);
$this->config['points'][$user]['y'] = round($data["player"]->entity->y);
$this->config['points'][$user]['z'] = round($data["player"]->entity->z);
$this->config['points'][$user]['level'] = $data["player"]->level->getName();
 $this->api->plugin->writeYAML($this->path."config.yml", $this->config);
 $this->api->chat->sendTo(false, "[UPoint] Checkpoint!", $user);
}
break;
case "player.respawn":
case "player.spawn":
$this->config = $this->api->plugin->readYAML($this->path."config.yml");
$user = $data->username;
$data->teleport(new Vector3($this->config['points'][$user]['x'], $this->config['points'][$user]['y'], $this->config['points'][$user]['z']));
$this->api->chat->sendTo(false, "[UPoint] Teleported!", $user);
break;
}
}
}