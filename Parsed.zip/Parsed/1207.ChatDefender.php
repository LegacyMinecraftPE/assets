<?php
/*
__PocketMine Plugin__
name=ChatDefender
description=A robot that will fight spam for you
version=0.1.1
author=Falk
class=ChatDefend
apiversion=10,11
*/
/*
_Change Log_
0.1 - Intial release
	
*/
class ChatDefend implements Plugin{
private $api, $path;
public function __construct(ServerAPI $api, $server = false){
$this->api = $api;
}

public function init(){

$this->api->addHandler("player.chat", array($this,"eventHandle"),50);
}

public function __destruct(){}

public function eventHandle($data, $event) {
$message = $data['message'];
$player = $data['player'];
$username = $player->username;
if (!isset($this->lastmessage[$username])) {
	$this->lastmessage[$username] = "";
}
if (strtolower($message) == $this->lastmessage[$username]) {
	$this->chatblock[$username] = strtotime("now") + 60;
	$player->sendChat("[ChatBlock] You have been blocked");
	return false;
}
elseif (isset($this->chatblock[$username])) {
	
if (strtotime("now") > $this->chatblock[$username]) {
	unset($this->chatblock[$username]);
	$player->sendChat('[ChatBlock] Your block has been lifted');
	return true;
}
else {
 $player->sendChat('[ChatBlock] You still have an existing block');
  return false;
	
}
}
else {
	$this->lastmessage[$username] = strtolower($message);
	return true;
}
	}
}