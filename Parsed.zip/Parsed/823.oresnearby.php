<?php
/*
__PocketMine Plugin__
name=OreFind
description=Brings the golden curse to PocketMine :P
version=0.1
author=Falk
class=oreFind
apiversion=10
*/
class oreFind implements Plugin{
private $api, $path;
public function __construct(ServerAPI $api, $server = false){
$this->api = $api;
}

public function init(){
$this->api->console->register("ores", "Do an ore scan", array($this, "command"));

}

public function __destruct(){}
public function command($cmd, $params, $issuer, $alias, $args, $issuer){
$issuer->sendChat("[OreFind] Scan started!");
$start = strtotime("now");
$y = $issuer->entity->y;
$blocky = array($y+8,$y+7,$y+6,$y+5,$y+4,$y+3,$y+2,$y+1,$y,$y-1,$y-2,$y-3,$y-4,$y-5,$y-6,$y-7,$y-8);
$x = round($issuer->entity->x);
$z = round($issuer->entity->z);
$blockz = $blockx = array($z+8,$z+7,$z+6,$z+5,$z+4,$z+3,$z+2,$z+1,$z,$z-1,$z-2,$z-3,$z-4,$z-5,$z-6,$z-7,$z-8);
$blockx = array($x+8,$x+7,$x+6,$x+5,$x+4,$x+3,$x+2,$x+1,$x,$x-1,$x-2,$x-3,$x-4,$x-5,$x-6,$x-7,$x-8);

//This probably lags like hell
foreach ($blocky as $y2) {
 foreach ($blockx as $x2) {
  foreach ($blockz as $z2) {
  	$block = $issuer->level->getBlock(new Vector3($x2, $y2, $z2));
  	$blocks[] = $block->getID();
  }
 	
 }
	
}
$blocks = array_count_values($blocks);
$issuer->sendChat("---ORE REPORT---");
$issuer->sendChat($blocks[16] . " coal");
$issuer->sendChat($blocks[15] . " iron");
$issuer->sendChat($blocks[14] . " gold");
$issuer->sendChat($blocks[56] . " diamond");
$issuer->sendChat($blocks[21] . " lapis");
$issuer->sendChat($blocks[73] . " redstone");
$time = strtotime("now") - $start;
$issuer->sendChat("512 blocks scanned in" . $time . " seconds");
}
}
