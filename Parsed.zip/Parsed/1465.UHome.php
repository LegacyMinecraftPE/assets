<?php
/*
__PocketMine Plugin__
name=UHome
description=CheckPoint system
version=1.2.1
author=1ron_pon3
class=UHome
apiversion=11
*/
class UHome implements Plugin{
private $api, $path, $player, $user;
public function __construct(ServerAPI $api, $server = false){
$this->api = $api;
}

public function init(){
$this->api->console->register("home", "tp home", array($this, "command"));
$this->api->ban->cmdWhitelist("home");
$this->api->addHandler("player.block.place", array($this,"handler"),5);
$this->api->addHandler("player.respawn", array($this,"handler"),5);
$this->readConfig();
console(FORMAT_GREEN."[".FORMAT_RED."U".FORMAT_DARK_PURPLE."Home".FORMAT_GREEN."] Loaded configuration!");
}

public function __destruct(){}

public function command($cmd, $args, $issuer){
	switch($cmd){
	    case "home":     
           $this->config = $this->api->plugin->readYAML($this->path."config.yml");
           $user = $issuer->username;
           if (isset($this->config['homes'][$user]['x'])){
              $lv = $this->api->level->get($this->config['homes'][$user]['level']);
              $pos = new Position($this->config['homes'][$user]['x'], $this->config['homes'][$user]['y'], $this->config['homes'][$user]['z'], $lv);
              $issuer->teleport($pos);
              $this->api->chat->sendTo(false, "[UHome] Teleported!", $user);}
		   else
		   {
		   $this->api->chat->sendTo(false, "[UHome] You don't have home!", $user);
		   }
      break;
}}	  

public function readConfig(){
		$this->path = $this->api->plugin->createConfig($this, array());
		$this->config = $this->api->plugin->readYAML($this->path."config.yml");
}

public function handler($data, $event){
switch($event){
case "player.block.place":

$user = $data["player"]->username;
if($data["item"]->getID() === 26 || $data["item"]->getID() === 355){
$this->config['homes'][$user]['x'] = round($data["player"]->entity->x);
$this->config['homes'][$user]['y'] = round($data["player"]->entity->y);
$this->config['homes'][$user]['z'] = round($data["player"]->entity->z);
$this->config['homes'][$user]['level'] = $data["player"]->level->getName();
 $this->api->plugin->writeYAML($this->path."config.yml", $this->config);
 $this->api->chat->sendTo(false, "[UHome] Home set!", $user);
}
break;
case "player.respawn":
$this->config = $this->api->plugin->readYAML($this->path."config.yml");
$user = $data->username;
if (isset($this->config['homes'][$user]['x'])){
$lv = $this->api->level->get($this->config['homes'][$user]['level']);
$pos = new Position($this->config['homes'][$user]['x'], $this->config['homes'][$user]['y'], $this->config['homes'][$user]['z'], $lv);
$data->teleport($pos);
#$data->teleport(new Vector3($this->config['homes'][$user]['x'], $this->config['homes'][$user]['y'], $this->config['homes'][$user]['z']));
$this->api->chat->sendTo(false, "[UHome] Teleported!", $user);}
break;
}
}
}