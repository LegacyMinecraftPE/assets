<?php
/*
__PocketMine Plugin__
name=Tap to do
description=A simple plugin to automate commands
version=0.2
author=Falk
class=tapdo
apiversion=10
*/
/*
_Change Log_
0.1 - Intial release
0.2 - 
	*Added new /tapcmd command 
	*Added :user:
	*Code format improvements
	
*/
class tapdo implements Plugin{
private $api, $path;
public function __construct(ServerAPI $api, $server = false){
$this->api = $api;
}

public function init(){

$this->api->addHandler("player.block.touch", array($this,"eventHandle"),50);
$this->api->console->register("setcmd", "Old Tap to Do command", array($this, "command"));
$this->api->console->register("tapcmd", "Sets the tap cmd for the block you click", array($this, "command"));
$this->config = new Config($this->api->plugin->configPath($this)."blocks.yml", CONFIG_YAML, array());
}

public function __destruct(){}
public function command($cmd, $params, $issuer, $alias, $args, $issuer){
switch ($cmd) {
	case "setcmd": 
	$blocks = $this->api->plugin->readYAML($this->api->plugin->configPath($this). "blocks.yml");
	$cmd = implode(" ", $params);
	$x = round($issuer->entity->x);
	$y = $issuer->entity->y;
	$y = $y-1;
	$z = round($issuer->entity->z);
	$level = $issuer->level->getName();
	$id = $x . "!" . $y . "!" . $z . "!" . $level;
		$blocks[$id] = $cmd;
	
		$this->api->plugin->writeYAML($this->api->plugin->configPath($this)."blocks.yml", $blocks);
$issuer->sendChat("Command added to block!");
	break;
	case "tapcmd": 
	$cmd = implode(" ", $params);
	$this->picked[$issuer->username] = $cmd;
	$issuer->sendChat("Tap a block to add the command!");
break;
		default:
	$issuer->sendChat("Error!");
}
}
public function eventHandle($data, $event) {
if (isset($this->picked[$data["player"]->username])) {
$block = $data["target"];
	$read = $this->api->plugin->readYAML($this->api->plugin->configPath($this). "blocks.yml");
    $x = $block->x;
	$y = $block->y;
	$z = $block->z;
	$level = $block->level->getName();
	$id = $x . "!" . $y . "!" . $z . "!" . $level;
	$read[$id] = $this->picked[$data["player"]->username];
	
		$this->api->plugin->writeYAML($this->api->plugin->configPath($this)."blocks.yml", $read);
		unset($this->picked[$data["player"]->username]);
		$data["player"]->sendChat("Command added to block!");
		}
else {
$block = $data["target"];
$read = $this->api->plugin->readYAML($this->api->plugin->configPath($this). "blocks.yml");
    $x = $block->x;
	$y = $block->y;
	$z = $block->z;
	$level = $block->level->getName();
	$search = $x . "!" . $y . "!" . $z . "!" . $level;
	if (array_key_exists($search,$read)) {
	$command = str_replace(":player:", $data["player"]->username, $read[$search]);
	 $this->api->console->run($command);
		}
		}
	}
}