<?php

/* 
__PocketMine Plugin__ 
name=KillCounter
description=KillCounter
version=1.0
author=99leonchang
class=KillCounter
apiversion=9,10
*/
class KillCounter implements Plugin{
    private $api,$server;
    const DEFAULT_KILLS = 0;
    public function __construct(ServerAPI $api, $server = false)
    {
        $this->api = $api;
        $this->server = ServerAPI::request();
    }
    public function init(){
        $this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML);
        $this->api->addHandler("player.death", array($this, "eventHandler"), 15);
        $this->api->addHandler("player.join", array($this, "eventHandler"), 15);
        $this->api->addHandler("player.chat", array($this, "eventHandler"), 15);
        $this->api->addHandler("kills.player.get", array($this, "eventHandler"));
    }

    public function eventHandler($data, $event){
        switch($event){
            case "player.death":
                if(is_numeric($data["cause"])){
                    $e = $this->api->entity->get($data["cause"]);
                    $plr = $e->name;
                    if($e instanceof Entity){
                        if($e->class == ENTITY_PLAYER){
                            $amount = 1;
                            $targetKills = $this->config->get($plr)['kills'] + $amount;
                            if($targetKills < 0) return false;
                            $this->config->set($plr, array('kills' => $targetKills));
                        }
                    }
                }
                break;
            case "player.join":
                //Registers users on first join
                $target = $data->username;
                if (!$this->config->exists($target)) {
                    $this->config->set($target, array('kills' => self::DEFAULT_KILLS));
                }
                $this->config->save();
                break;
            case "player.chat":
                $this->config->reload();
                $name = $data["player"]->username;
                $messages = $data["message"];
                $data = array(
                    'username' => $name
                );
                $kills = $this->config->get($name)['kills'];
                $data = array("player" => $name, "message" => str_replace(array("{DISPLAYNAME}", "{MESSAGE}", "{kills}"), array($name, $messages, $kills),  "<{DISPLAYNAME}({kills})> {MESSAGE}"));
                if($this->api->handle("KillCounter.".$event, $data) !== false){
                    $this->api->chat->broadcast($data["message"]);
                }
                return false;
                break;
            case "kills.player.get":
                if ($this->config->exists($data['username'])) {
                    return $this->config->get($data['username'])['kills'];
                }
                return false;
        }
    }

    public function __destruct() {}
}