<?php
/*
__PocketMine Plugin__
name=RandomItem
version=2.1.2
author=LDX
class=RandomItem
apiversion=10,11,12
*/
class RandomItem implements Plugin {
private $api;
public function __construct(ServerAPI $api, $server = false) {
$this->api = $api;
}
public function init() {
$currentVersion = "2.1.2";
$this->api->console->register("gift","Gives a random item to everyone online.",array($this, "giveRI"));
$path = $this->api->plugin->configPath($this);
if(file_exists($path . "items.yml")) {
console("[INFO] RandomItem: converting items.yml...");
$this->items = new Config($path . "items.yml",CONFIG_YAML);
$itemsYAML = array($this->items->get("0"),$this->items->get("1"),$this->items->get("2"),$this->items->get("3"),$this->items->get("4"));
unlink($path . "items.yml");
$items = implode("*",$itemsYAML);
file_put_contents($path . "items.txt",$items);
console("[INFO] RandomItem: items.yml converted!");
}
if(file_exists($path . "interval.yml")) {
console("[INFO] RandomItem: converting interval.yml...");
$this->time = new Config($path . "interval.yml",CONFIG_YAML);
$intervalYAML = $this->time->get("seconds") * 20;
unlink($path . "interval.yml");
file_put_contents($path . "interval.txt",$intervalYAML);
console("[INFO] RandomItem: interval.yml converted!");
}
if(!file_exists($path . "mode.txt")) {
file_put_contents($path . "mode.txt","1");
}
if(!file_exists($path . "items.txt")) {
file_put_contents($path . "items.txt","360*267*265*354*6");
}
if(!file_exists($path . "interval.txt")) {
file_put_contents($path . "interval.txt","600");
}
$timeInterval = file_get_contents($path . "interval.txt") * 20;
$this->api->schedule($timeInterval,array($this,"giveRI"),array($timeInterval),true,"server.schedule");
if(file_exists($this->api->plugin->configPath($this) . "version.txt") && file_get_contents($this->api->plugin->configPath($this) . "version.txt") == $currentVersion) {
$version = file_get_contents($this->api->plugin->configPath($this) . "version.txt"); 
} else {
if(file_exists($this->api->plugin->configPath($this) . "version.txt")) {
$version = file_get_contents($this->api->plugin->configPath($this) . "version.txt");
file_put_contents($this->api->plugin->configPath($this) . "version.txt",$currentVersion);
console("[INFO] RandomItem updated from " . $version . " to " . $currentVersion . "!");
} else {
file_put_contents($this->api->plugin->configPath($this) . "version.txt",$currentVersion);
}
}
console("[INFO] RandomItem Enabled!");
}
public function giveRI() {
$path = $this->api->plugin->configPath($this);
$mode = file_get_contents($path . "mode.txt");
$RIA = explode("*",file_get_contents($path . "items.txt"));
if($mode == "1") {
$RIN = rand(1,count($RIA)) - 1;
$randItem = $RIA[$RIN];
$this->api->console->run("give @all " . $randItem . " 1");
$this->api->chat->broadcast("[RandomItem] Random item given! (ID: " . $randItem . ")");
} else {
$players = $this->api->player->online();
foreach($players as $player) {
$RIN = rand(1,count($RIA)) - 1;
$randItem = $RIA[$RIN];
$this->api->console->run("give " . $player . " " . $randItem . " 1");
}
$this->api->chat->broadcast("[RandomItem] Random item given!");
}
}

public function __destruct(){}

}
?>