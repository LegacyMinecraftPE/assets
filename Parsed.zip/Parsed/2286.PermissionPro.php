<?php
 
/*
__PocketMine Plugin__
name=PermissionPro
description=A very easy and useful permission plugin.
It can permission of cmd and event.
version=1.0.1
apiversion=11,12,13
author=PMPCT&&JJ
class=PermissionPro
*/
/*

PMPChineseTeam制作
Made By PMPChineseTeam
=============Change=============
v1.0 First version, maybe have some small bugs.It have groups, every player permission, notice, and all-manager(it is very dangerous so just to write config to on/off it).
*Please don't use this version:1.0.

v1.0.1 Fixed can't give group bug and notice bug, and add permission for event:"player.flying" and "op.check", you can use /paddevent /premoveevent to add/remove it.

#You can on/off all-manager in:(pm)/plugins/PermissionPro/config.yml:

all-enable:true/false
all-disable:true/false

#true=on
#false=off

#permission of event
#flying=permission of flying in survival
#opthing=permisssion of things that op can do(like break/place spawn's block or other plugins's things)
#owner can do all event things about this
#use /pevenglist to see all permission of event

*/
 
class PermissionPro implements Plugin
{
    private $api, $config;
 
    public function __construct(ServerAPI $api, $server = false)
	{
        $this->api  = $api;
    }
     
    public function init()
	{            
		$this->makead($this->api->plugin->configPath($this)."players");
		$this->players = $this->api->plugin->configPath($this)."players/";
		$this->makead($this->api->plugin->configPath($this)."groups");
		$this->groups = $this->api->plugin->configPath($this)."groups/";
		$this->makead($this->api->plugin->configPath($this)."playercanuse");
		$this->playercanuse = $this->api->plugin->configPath($this)."playercanuse/";
		$this->makead($this->api->plugin->configPath($this)."playernouse");
		$this->playernouse = $this->api->plugin->configPath($this)."playernouse/";
		$this->api->console->register("owner", "<player>", array($this, 'command'));
		$this->api->console->register("deowner", "<player>", array($this, 'command'));
		$this->api->console->register("paddg", "<groupname>", array($this, 'command'));
		$this->api->console->register("premoveg", "<groupname>", array($this, 'command'));
		$this->api->console->register("pgiveg", "<player> <groupname>", array($this, 'command'));
		$this->api->console->register("pnog", "<player>", array($this, 'command'));
		$this->api->console->register("paddcmd", "<group|playercan|playerno|allcan|allno> [groupname|player] <command>", array($this, 'command'));
		$this->api->console->register("premovecmd", "<group|playercan|playerno|allcan|allno> [groupname|player] <command>", array($this, 'command'));
		$this->api->console->register("peventlist", "Permission Event List", array($this, 'command'));
		$this->api->console->register("paddevent", "<group|playercan|playerno|allcan|allno> [groupname|player] <event>", array($this, 'command'));
		$this->api->console->register("premoveevent", "<group|playercan|playerno|allcan|allno> [groupname|player] <event>", array($this, 'command'));
		//$this->api->console->register("pall", "<enable|disable> <on|off>", array($this, 'command'));
		$this->api->console->register("pnotice", "<on|off>", array($this, 'command'));
		$this->api->console->register("pseeplayer", "<player>", array($this, 'command'));
        $this->api->addHandler("console.command", array($this, 'p'),99);
        $this->api->addHandler("player.spawn", array($this, 'p'),99);
        $this->api->addHandler("player.flying", array($this, 'p'),99);
        $this->api->addHandler("op.check", array($this, 'opcc'),99);
        $this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array(
        "plugin-version" => "1.0.1",
        "all-disable" => false,
        "all-enable" => false,
        "group" => array(),
        "player" => array(),
        "more-things" => "soon-coming"
                ));
        $this->owner = new Config($this->api->plugin->configPath($this)."owner.yml", CONFIG_YAML, array(
        "owner" => array()
                ));
        $this->noticething = new Config($this->api->plugin->configPath($this)."notice.yml", CONFIG_YAML, array(
        "use-cmd-notice" => true
                ));
        $this->admin = new Config($this->groups . "admin.yml", CONFIG_YAML, array(
        "permission" => array()
                ));
        $this->op = new Config($this->groups . "op.yml", CONFIG_YAML, array(
        "permission" => array()
                ));
        $this->vip = new Config($this->groups . "vip.yml", CONFIG_YAML, array(
        "permission" => array()
                ));
        $this->canuse = new Config($this->api->plugin->configPath($this)."allcanuse.yml", CONFIG_YAML, array(
        "command" => array()
                ));
        $this->nouse = new Config($this->api->plugin->configPath($this)."allnouse.yml", CONFIG_YAML, array(
        "command" => array()
                ));
$this->tghas("admin");
$this->tghas("op");
$this->tghas("vip");
console(FORMAT_GREEN. "[PermissionPro] Loaded Permission of Command and Event.....");
   }


     public function opcheck($user){
				$this->pg = $this->api->plugin->readYAML($this->players . "$user.yml");
$usergroup=$this->pg["permission"];
if($this->ownerex($user)){return true;}else{
if($this->noex("opthing",$user)){return false;
    }else{if($this->nouseex("opthing")){return false;
      }else{
         if($this->groupex("opthing",$usergroup)||$this->canex("opthing",$user)||$this->canuseex("opthing")){
return true;
}else{
	return false;
        }
      }
    }
  }
break;
}


      public function opcc($user,$event){
    switch($event){
       case"op.check":
$opc=$this->opcheck($user);
       if($opc==false){return false;}else{return true;}}}


    public function p($data, $event){
    switch($event){
       case"player.flying":
       $user=$data->username;
					$this->pg = $this->api->plugin->readYAML($this->players . "$user.yml");
$usergroup=$this->pg["permission"];
if($this->ownerex($user)){return true;}else{
if($this->noex("flying",$user)){								
	$this->api->console->run("kick $user flying");
console(FORMAT_RED. "[PermissionPro] Player *$user has been kicked by this plugin, because he use mod to flying.");
}else{if($this->nouseex("flying")){								
	$this->api->console->run("kick $user flying");
console(FORMAT_RED. "[PermissionPro] Player *$user has been kicked by this plugin, because he use mod to flying.");}else{
if($this->groupex("flying",$usergroup)||$this->canex("flying",$user)||$this->canuseex("flying")){
return true;
}else{$this->api->console->run("kick $user flying");
console(FORMAT_RED. "[PermissionPro] Player *$user has been kicked by this plugin, because he use mod to flying.");
         }
       }
     }
   }
break;
       case"player.spawn":
$user=$data->username;
$this->tuser($user);
        $this->newplayerjoin = new Config($this->players . "$user.yml", CONFIG_YAML, array(
        "permission" => false
                ));
        $this->n = new Config($this->playercanuse . "$user.yml", CONFIG_YAML, array(
        "command" => array()
                ));
        $this->nn = new Config($this->playernouse . "$user.yml", CONFIG_YAML, array(
        "command" => array()
                ));
$this->opcc($user,$event);
break;
       case"console.command":
if($data["issuer"] === "console"){return;}else{
$pcmd = $data["cmd"];
$user = $data["issuer"]->iusername;
$player = $data["issuer"];
$this->config = $this->api->plugin->readYAML($this->api->plugin->configPath($this) . "config.yml");
$this->notice = $this->api->plugin->readYAML($this->api->plugin->configPath($this) . "notice.yml");
$this->pg = $this->api->plugin->readYAML($this->players . "$user.yml");
$alld=$this->config["all-disable"];
$alle=$this->config["all-enable"];
$notice=$this->notice["use-cmd-notice"];
$usergroup=$this->pg["permission"];
if($this->ownerex($user)){
$canm=FORMAT_RED. "●This player is an owner, please look this player carefully.";
}else{
if($usergroup==false){
$canm=FORMAT_YELLOW. "●This player doesn't have group.";}else{
$canm=FORMAT_GREEN. "●This player's group is *$usergroup.";}}
if($notice==true){
console(FORMAT_YELLOW."[PermissionPro] *$user use the command : /$pcmd. \n$canm");}
 }
if($alld==true){
return false;
 }
else{
if($this->ownerex($user)||$this->canuseex($pcmd)||$alle==true){
return;}else{
if($this->noex($pcmd,$user)||$this->nouseex($pcmd)){
return false;
 }
else{
if($usergroup==false){
if($this->canex($pcmd,$user)){
return;}
}
else{
$group=$usergroup;
if($this->groupex($pcmd,$group)||$this->canex($pcmd,$user)){
return;
}return false;
}return false;
}return false;
}return false;
}
break;
   }
 }


    public function command($cmd, $params){
    switch($cmd){
       case "owner":
				if(!isset($params[0])){
return("[PermissionPro] Usage: /owner <player>");
}else{
$user=$params[0];
$this->towner($user);
$this->api->chat->broadcast("[PermissionPro] Player *$user is now an owner.");
return("[PermissionPro] Give owner for *$user successfully.");
}
break;
       case"deowner":
				if(!isset($params[0])){
return("[PermissionPro] Usage: /deowner <player>");
}else{
$user=$params[0];
$this->dtowner($user);
$this->api->chat->broadcast("[PermissionPro] Now player *$user isn't an owner.");
return("[PermissionPro] Delete owner for *$user successfully.");
}
break;
       case"paddg":
				if(!isset($params[0])){
return("[PermissionPro] Usage: /paddg <groupname>");
}else{
$group=$params[0];
if($this->ghasex($group)){
return("[PermissionPro] Group *$group has been build, You can't build again");}else{
$this->tghas($group);
        $this->group = new Config($this->groups . "$group.yml", CONFIG_YAML, array(
        "permission" => array()
                ));
return("[PermissionPro] Group *$group add successfully.");}}
break;
      case"premoveg":
				if(!isset($params[0])){
return("[PermissionPro] Usage: /premoveg <groupname>");
}else{
$group=$params[0];
if(!$this->ghasex($group)){
return("[PermissionPro] There is no group named *$group ");}else{
$this->dtghas($group);
       unlink($this->groups . "$group.yml");
return("[PermissionPro] Group *$group removed successfully.");}}
break;
     case"pgiveg":
	if(!isset($params[0])||!isset($params[1])){
return("[PermissionPro] Usage: /pgiveg <player> <groupname>");
}else{
$user=$params[0];
$group=$params[1];
if($this->ghasex($group)){
       unlink($this->players . "$user.yml");
        $this->new = new Config($this->players . "$user.yml", CONFIG_YAML, array(
        "permission" => "$group"
                ));
$this->api->chat->broadcast("[PermissionPro] Player *$user 's group is now *$group.");
return("[PermissionPro] Give group *$group to *$user.");}else{
return("[PermissionPro] Group *$group doesn't exist.");
}
}
break;
    case"pnog":
				if(!isset($params[0])){
return("[PermissionPro] Usage: /pnog <player>");
}else{
$user=$params[0];
					$this->pg1 = $this->api->plugin->readYAML($this->players . "$user.yml");
$pg1=$this->pg1['permission'];
if($pg1==false){
return("[PermissionPro] Player *$user isn't in any group.");
}else{
//$this->dtggroup($user,$pg1);
       unlink($this->players . "$user.yml");
        $this->new = new Config($this->players . "$user.yml", CONFIG_YAML, array(
        "permission" => false
                ));
$this->api->chat->broadcast("[PermissionPro] Now player *$user didn't have any group.");
return("[PermissionPro] Move *$user to no group successfully.");
}}
break;
    case"peventlist":
return("[PermissionPro] Permission of Event List:\n1.flying\nwhen survival player use mod to fly they won't kick by server\n2.opthing\nplayer can do some event and things that just op can do(not command)");break;
    case"paddevent":
	if(!isset($params[0])){
return("[PermissionPro] Usage: /paddevent <group|playercan|playerno|allcan|allno> [groupname|player] <event>");
}else{
if($params[0]=="group"||$params[0]=="playercan"||$params[0]=="playerno"||$params[0]=="allcan"||$params[0]=="allno"){
switch($params[0]){
case"group":	if(!isset($params[1])||!isset($params[2])||($params[2]!="flying"&&$params[2]!="opthing")){


return("[PermissionPro] Usage: /paddevent group <groupname> <event>\nYou can use /peventlist to see the event");
}else{
$groupname=$params[1];
$acmd=$params[2];
if($this->ghasex($groupname)){
$this->tgroup($acmd,$groupname);
return("[PermissionPro]
Add event #$acmd to group *$groupname successfully.");}else{
return("[PermissionPro] Group *$groupname doesn't exist.");}}break;
case"playercan":
if(!isset($params[1])||!isset($params[2])||($params[2]!="flying"&&$params[2]!="opthing")){
return("[PermissionPro] Usage: /paddevent playercan <player> <event>\nYou can use /peventlist to see the event");
}else{
$playername=$params[1];
$acmd=$params[2];
if($this->userex($playername)){
$this->tcan($acmd,$playername);
return("[PermissionPro]
Add can event #$acmd to player *$playername successfully.");}else{
return("[PermissionPro] Player *$playername never plays in the server.");}}break;
case"playerno":
if(!isset($params[1])||!isset($params[2])||($params[2]!="flying"&&$params[2]!="opthing")){
return("[PermissionPro] Usage: /paddevent playerno <player> <event>\nYou can use /peventlist to see the event");
}else{
$playername=$params[1];
$acmd=$params[2];
if($this->userex($playername)){
$this->tno($acmd,$playername);
return("[PermissionPro]
Add no event #$acmd to player *$playername successfully.");}else{
return("[PermissionPro] Player *$playername never plays in the server.");}}break;
case"allcan":
if(!isset($params[1])||($params[1]!="flying"&&$params[1]!="opthing")){
return("[PermissionPro] Usage: /paddevent allcan <event>\nYou can use /peventlist to see the event");
}else{
$acmd=$params[1];
$this->tcanuse($acmd);
return("[PermissionPro]
Add allcan event #$acmd to all player.");
break;}
case"allno":
if(!isset($params[1])||($params[1]!="flying"&&$params[1]!="opthing")){
return("[PermissionPro] Usage: /paddevent allno <event>\nYou can use /peventlist to see the event");
}else{
$acmd=$params[1];
$this->tnouse($acmd);
return("[PermissionPro]
Add allno event #$acmd to all player.");
break;
}
}
}else{
return("[PermissionPro] Usage: /paddevent <group|playercan|playerno|allcan|allno> [groupname|player] <event>\nYou can use /peventlist to see the event");
}}
break;
    case"premoveevent":
	if(!isset($params[0])){
return("[PermissionPro] Usage: /premoveevent <group|playercan|playerno|allcan|allno> [groupname|player] <event>\nYou can use /peventlist to see the event");
}else{
if($params[0]=="group"||$params[0]=="playercan"||$params[0]=="playerno"||$params[0]=="allcan"||$params[0]=="allno"){
switch($params[0]){
case"group":	if(!isset($params[1])||!isset($params[2])||($params[2]!="flying"&&$params[2]!="opthing")){
return("[PermissionPro] Usage: /premoveevent group <groupname> <event>\nYou can use /peventlist to see the event");
}else{
$groupname=$params[1];
$acmd=$params[2];
if($this->ghasex($groupname)){
$this->dtgroup($acmd,$groupname);
return("[PermissionPro]
Removed event #$acmd to group *$groupname successfully.");}else{
return("[PermissionPro] Group *$groupname doesn't exist.");}}break;
case"playercan":
if(!isset($params[1])||!isset($params[2])||($params[2]!="flying"&&$params[2]!="opthing")){
return("[PermissionPro] Usage: /premoveevent playercan <player> <event>\nYou can use /peventlist to see the event");
}else{
$playername=$params[1];
$acmd=$params[2];
if($this->userex($playername)){
$this->dtcan($acmd,$playername);
return("[PermissionPro]
Removed can event #$acmd to player *$playername successfully.");}else{
return("[PermissionPro] Player *$playername never plays in the server.");}}break;
case"playerno":
if(!isset($params[1])||!isset($params[2])||($params[2]!="flying"&&$params[2]!="opthing")){
return("[PermissionPro] Usage: /premoveevent playerno <player> <event>\nYou can use /peventlist to see the event");
}else{
$playername=$params[1];
$acmd=$params[2];
if($this->userex($playername)){
$this->dtno($acmd,$playername);
return("[PermissionPro]
Removed no event #$acmd to player *$playername successfully.");}else{
return("[PermissionPro] Player *$playername never plays in the server.");}}break;
case"allcan":
if(!isset($params[1])||($params[1]!="flying"&&$params[1]!="opthing")){
return("[PermissionPro] Usage: /premoveevent allcan <event>\nYou can use /peventlist to see the event");
}else{
$acmd=$params[1];
$this->dtcanuse($acmd);
return("[PermissionPro]
Removed allcan event #$acmd to all player.");
break;
}
case"allno":
if(!isset($params[1])||($params[1]!="flying"&&$params[1]!="opthing")){
return("[PermissionPro] Usage: /premoveevent allno <event>\nYou can use /peventlist to see the event");
}else{
$acmd=$params[1];
$this->dtnouse($acmd);
return("[PermissionPro]
Removed allno event #$acmd to all player.");
break;
}
}
}else{
return("[PermissionPro] Usage: /premoveevent <group|playercan|playerno|allcan|allno> [groupname|player] <event>\nYou can use /peventlist to see the event");
}}
break;
    case"paddcmd":
	if(!isset($params[0])){
return("[PermissionPro] Usage: /paddcmd <group|playercan|playerno|allcan|allno> [groupname|player] <command>");
}else{
if($params[0]=="group"||$params[0]=="playercan"||$params[0]=="playerno"||$params[0]=="allcan"||$params[0]=="allno"){
switch($params[0]){
case"group":	if(!isset($params[1])||!isset($params[2])){
return("[PermissionPro] Usage: /paddcmd group <groupname> <command>");
}else{
$groupname=$params[1];
$acmd=$params[2];
if($this->ghasex($groupname)){
$this->tgroup($acmd,$groupname);
return("[PermissionPro]
Add cmd /$acmd to group *$groupname successfully.");}else{
return("[PermissionPro] Group *$groupname doesn't exist.");}}break;
case"playercan":
if(!isset($params[1])||!isset($params[2])){
return("[PermissionPro] Usage: /paddcmd playercan <player> <command>");
}else{
$playername=$params[1];
$acmd=$params[2];
if($this->userex($playername)){
$this->tcan($acmd,$playername);
return("[PermissionPro]
Add can cmd /$acmd to player *$playername successfully.");}else{
return("[PermissionPro] Player *$playername never plays in the server.");}}break;
case"playerno":
if(!isset($params[1])||!isset($params[2])){
return("[PermissionPro] Usage: /paddcmd playerno <player> <command>");
}else{
$playername=$params[1];
$acmd=$params[2];
if($this->userex($playername)){
$this->tno($acmd,$playername);
return("[PermissionPro]
Add no cmd /$acmd to player *$playername successfully.");}else{
return("[PermissionPro] Player *$playername never plays in the server.");}}break;
case"allcan":
if(!isset($params[1])){
return("[PermissionPro] Usage: /paddcmd allcan <command>");
}else{
$acmd=$params[1];
$this->tcanuse($acmd);
return("[PermissionPro]
Add allcan cmd /$acmd to all player.");
break;}
case"allno":
if(!isset($params[1])){
return("[PermissionPro] Usage: /paddcmd allno <command>");
}else{
$acmd=$params[1];
$this->tnouse($acmd);
return("[PermissionPro]
Add allno cmd /$acmd to all player.");
break;
}
}
}else{
return("[PermissionPro] Usage: /paddcmd <group|playercan|playerno|allcan|allno> [groupname|player] <command>");
}}
break;
    case"premovecmd":
	if(!isset($params[0])){
return("[PermissionPro] Usage: /premovecmd <group|playercan|playerno|allcan|allno> [groupname|player] <command>");
}else{
if($params[0]=="group"||$params[0]=="playercan"||$params[0]=="playerno"||$params[0]=="allcan"||$params[0]=="allno"){
switch($params[0]){
case"group":	if(!isset($params[1])||!isset($params[2])){
return("[PermissionPro] Usage: /premovecmd group <groupname> <command>");
}else{
$groupname=$params[1];
$acmd=$params[2];
if($this->ghasex($groupname)){
$this->dtgroup($acmd,$groupname);
return("[PermissionPro]
Removed cmd /$acmd to group *$groupname successfully.");}else{
return("[PermissionPro] Group *$groupname doesn't exist.");}}break;
case"playercan":
if(!isset($params[1])||!isset($params[2])){
return("[PermissionPro] Usage: /premovecmd playercan <player> <command>");
}else{
$playername=$params[1];
$acmd=$params[2];
if($this->userex($playername)){
$this->dtcan($acmd,$playername);
return("[PermissionPro]
Removed can cmd /$acmd to player *$playername successfully.");}else{
return("[PermissionPro] Player *$playername never plays in the server.");}}break;
case"playerno":
if(!isset($params[1])||!isset($params[2])){
return("[PermissionPro] Usage: /premovecmd playerno <player> <command>");
}else{
$playername=$params[1];
$acmd=$params[2];
if($this->userex($playername)){
$this->dtno($acmd,$playername);
return("[PermissionPro]
Removed no cmd /$acmd to player *$playername successfully.");}else{
return("[PermissionPro] Player *$playername never plays in the server.");}}break;
case"allcan":
if(!isset($params[1])){
return("[PermissionPro] Usage: /premovecmd allcan <command>");
}else{
$acmd=$params[1];
$this->dtcanuse($acmd);
return("[PermissionPro]
Removed allcan cmd /$acmd to all player.");
break;
}
case"allno":
if(!isset($params[1])){
return("[PermissionPro] Usage: /premovecmd allno <command>");
}else{
$acmd=$params[1];
$this->dtnouse($acmd);
return("[PermissionPro]
Removed allno cmd /$acmd to all player.");
break;
}
}
}else{
return("[PermissionPro] Usage: /premovecmd <group|playercan|playerno|allcan|allno> [groupname|player] <command>");
}}
break;
case"pnotice":
	if(!isset($params[0])){
return("[PermissionPro] Usage: /pcmdnotice <on|off>");
}else{
if($params[0]=="on"||$params[0]=="off"){
switch($params[0]){
case"on":
unlink($this->api->plugin->configPath($this) . "notice.yml");
$this->noticee = new Config($this->api->plugin->configPath($this)."notice.yml", CONFIG_YAML, array(
        "use-cmd-notice" => true
                ));
return("[PermissionPro] User Cmd Notice is turn on");
break;
case"off":
unlink($this->api->plugin->configPath($this) . "notice.yml");
$this->noticee = new Config($this->api->plugin->configPath($this)."notice.yml", CONFIG_YAML, array(
        "use-cmd-notice" => false
                ));
return("[PermissionPro] User Cmd Notice is turn off");
break;
}}else{
return("[PermissionPro] Usage: /pcmdnotice <on|off>");
}}
break;
case"pseeplayer":
	if(!isset($params[0])){
return("[PermissionPro] Usage: /pseeplayer <player>");
}else{
$user=$params[0];
if($this->userex($user)){
					$this->pg = $this->api->plugin->readYAML($this->players . "$user.yml");
$usergroup=$this->pg["permission"];
if($usergroup!=false){
return("[PermissionPro] Player *$user is in group *$usergroup.");
}else{
return("[PermissionPro] Player *$user is not in any group.");}}else{
return("[PermissionPro] Player *$user never plays in the server.");
}}
break;
}}

	public function __destruct(){}


    public function tno($pcmd,$user) 
    {
        $this->pnouse = new Config($this->playernouse . "$user.yml", CONFIG_YAML, array(
        "command" => array()
                ));
        if (!in_array($pcmd, $this->pnouse->get("command"))) 
        {
            $c = $this->pnouse->get("command");
            $c[] = $pcmd;
            $this->pnouse->set("command", $c);
            $this->pnouse->save();
            return;
        } 

    }

    public function dtno($pcmd,$user) 
    {
        $this->pnouse = new Config($this->playernouse . "$user.yml", CONFIG_YAML, array(
        "command" => array()
                ));
        $c = $this->pnouse->get("command");
        $key = array_search($pcmd, $c);
        unset($c[$key]);
        $this->pnouse->set("command", $c);
        $this->pnouse->save();
    }

    public function noex($pcmd,$user)
    {
        $this->pnouse = new Config($this->playernouse . "$user.yml", CONFIG_YAML, array(
        "command" => array()
                ));
        return in_array($pcmd, $this->pnouse->get("command"));
    }

    public function tcan($pcmd,$user) 
    {
        $this->pcanuse = new Config($this->playercanuse . "$user.yml", CONFIG_YAML, array(
        "command" => array()
                ));
        if (!in_array($pcmd, $this->pcanuse->get("command"))) 
        {
            $c = $this->pcanuse->get("command");
            $c[] = $pcmd;
            $this->pcanuse->set("command", $c);
            $this->pcanuse->save();
            return;
        } 
    }

    public function dtcan($pcmd,$user) 
    {
        $this->pcanuse = new Config($this->playercanuse . "$user.yml", CONFIG_YAML, array(
        "command" => array()
                ));
        $c = $this->pcanuse->get("command");
        $key = array_search($pcmd, $c);
        unset($c[$key]);
        $this->pcanuse->set("command", $c);
        $this->pcanuse->save();
    }

    public function canex($pcmd,$user)
    {
        $this->pcanuse = new Config($this->playercanuse . "$user.yml", CONFIG_YAML, array(
        "command" => array()
                ));
        return in_array($pcmd, $this->pcanuse->get("command"));
    }


    public function tgroup($pcmd,$group) 
    {
        $this->group = new Config($this->groups . "$group.yml", CONFIG_YAML, array(
        "permission" => array()
                ));
					    if (!in_array($pcmd, $this->group->get("permission"))) 
        {
            $c = $this->group->get("permission");
            $c[] = $pcmd;
            $this->group->set("permission", $c);
            $this->group->save();
            return;
        } 
    }

    public function dtgroup($pcmd,$group) 
    {
        $this->group = new Config($this->groups . "$group.yml", CONFIG_YAML, array(
        "permission" => array()
                ));
        $c = $this->group->get("permission");
        $key = array_search($pcmd, $c);
        unset($c[$key]);
        $this->group->set("permission", $c);
        $this->group->save();
    }

    public function groupex($pcmd,$group)
    {
        $this->group = new Config($this->groups . "$group.yml", CONFIG_YAML, array(
        "permission" => array()
                ));
        return in_array($pcmd, $this->group->get("permission"));
    }



    public function tghas($group) 
    {
        $this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array());
        if (!in_array($group, $this->config->get("group"))) 
        {
            $c = $this->config->get("group");
            $c[] = $group;
            $this->config->set("group", $c);
            $this->config->save();
            return;
        } 
    }

    public function dtghas($group) 
    {
        $this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array());
        $c = $this->config->get("group");
        $key = array_search($group, $c);
        unset($c[$key]);
        $this->config->set("group", $c);
        $this->config->save();
    }

    public function ghasex($group)
    {
        $this->c = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array());
        return in_array($group, $this->c->get("group"));
    }


    public function towner($user) 
    {
        if (!in_array($user, $this->owner->get("owner"))) 
        {
            $c = $this->owner->get("owner");
            $c[] = $user;
            $this->owner->set("owner", $c);
            $this->owner->save();
            return;
        } 
    }

    public function dtowner($user) 
    {
        $c = $this->owner->get("owner");
        $key = array_search($user, $c);
        unset($c[$key]);
        $this->owner->set("owner", $c);
        $this->owner->save();
    }

    public function ownerex($user)
    {
        return in_array($user, $this->owner->get("owner"));
    }


    public function tcanuse($user) 
    {
        if (!in_array($user, $this->canuse->get("command"))) 
        {
            $c = $this->canuse->get("command");
            $c[] = $user;
            $this->canuse->set("command", $c);
            $this->canuse->save();
            return;
        } 
    }

    public function dtcanuse($user) 
    {
        $c = $this->canuse->get("command");
        $key = array_search($user, $c);
        unset($c[$key]);
        $this->canuse->set("command", $c);
        $this->canuse->save();
    }

    public function canuseex($user)
    {
        return in_array($user, $this->canuse->get("command"));
    }



    public function tnouse($user) 
    {
        if (!in_array($user, $this->nouse->get("command"))) 
        {
            $c = $this->nouse->get("command");
            $c[] = $user;
            $this->nouse->set("command", $c);
            $this->nouse->save();
            return;
        } 
    }

    public function dtnouse($user) 
    {
        $c = $this->nouse->get("command");
        $key = array_search($user, $c);
        unset($c[$key]);
        $this->nouse->set("command", $c);
        $this->nouse->save();
    }

    public function nouseex($user)
    {
        return in_array($user, $this->nouse->get("command"));
    }


    public function tuser($user) 
    {
        $this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array());
        if (!in_array($user, $this->config->get("player"))) 
        {
            $c = $this->config->get("player");
            $c[] = $user;
            $this->config->set("player", $c);
            $this->config->save();
            return;
        } 
    }

    public function dtuser($user) 
    {
        $this->config = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array());
        $c = $this->config->get("player");
        $key = array_search($user, $c);
        unset($c[$key]);
        $this->config->set("player", $c);
        $this->config->save();
    }

    public function userex($user)
    {
        $this->c = new Config($this->api->plugin->configPath($this)."config.yml", CONFIG_YAML, array());
        return in_array($user, $this->c->get("player"));
    }

	public function makead($path){
		if (!file_exists($path) and !is_dir($path)){
			mkdir($path);
		} 
	}


//	public function __destruct(){}

}
?>